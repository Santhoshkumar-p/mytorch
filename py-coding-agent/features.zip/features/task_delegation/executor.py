"""
TaskDelegator — runs delegated tasks as sub-processes.

Each task is executed by spawning a child Python process that runs
``coding_agent.main`` with the appropriate flags.  Tasks can be run in
parallel (default) or sequentially.
"""
from __future__ import annotations

import asyncio
import sys
import time
from typing import Sequence

from .types import DelegationResult, ExecutionMode, TaskItem, TaskParams, TaskResult


def get_task_command(agent: str, assignment: str, cwd: str) -> list[str]:
    """
    Build the subprocess command list for a single task.

    Uses the same Python interpreter that is running the parent process so
    that the sub-agent inherits the same virtual environment.
    """
    return [
        sys.executable,
        "-m",
        "coding_agent.main",
        "--agent",
        agent,
        "--task",
        assignment,
        "--cwd",
        cwd,
    ]


class TaskDelegator:
    """
    Delegates a batch of tasks to sub-agent processes.

    Supports parallel execution (all tasks started simultaneously, up to
    ``max_parallel`` at once) and sequential execution (one at a time, abort
    on first failure).
    """

    def __init__(self, cwd: str, max_parallel: int = 4) -> None:
        self.cwd = cwd
        self.max_parallel = max_parallel

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    async def execute(self, params: TaskParams) -> DelegationResult:
        """
        Run all tasks in *params* according to *params.mode*.

        Returns a :class:`DelegationResult` with individual TaskResults plus
        aggregate counts.
        """
        wall_start = time.monotonic()

        if params.mode == "sequential":
            results = await self._run_sequential(params)
        else:
            results = await self._run_parallel(params)

        total_ms = (time.monotonic() - wall_start) * 1000
        succeeded = sum(1 for r in results if r.exit_code == 0)
        failed = len(results) - succeeded

        return DelegationResult(
            results=results,
            total_duration_ms=total_ms,
            succeeded=succeeded,
            failed=failed,
        )

    # ------------------------------------------------------------------
    # Execution strategies
    # ------------------------------------------------------------------

    async def _run_parallel(self, params: TaskParams) -> list[TaskResult]:
        """Run all tasks concurrently, honouring *max_parallel*."""
        semaphore = asyncio.Semaphore(self.max_parallel)

        async def bounded(task: TaskItem) -> TaskResult:
            async with semaphore:
                return await self._run_task(task, params)

        raw = await asyncio.gather(
            *[bounded(t) for t in params.tasks],
            return_exceptions=True,
        )
        results: list[TaskResult] = []
        for task, outcome in zip(params.tasks, raw):
            if isinstance(outcome, BaseException):
                results.append(
                    TaskResult(
                        task_id=task.id,
                        output="",
                        exit_code=1,
                        duration_ms=0.0,
                        error=str(outcome),
                    )
                )
            else:
                results.append(outcome)
        return results

    async def _run_sequential(self, params: TaskParams) -> list[TaskResult]:
        """Run tasks one by one; stop on the first non-zero exit code."""
        results: list[TaskResult] = []
        for task in params.tasks:
            result = await self._run_task(task, params)
            results.append(result)
            if result.exit_code != 0:
                break
        return results

    # ------------------------------------------------------------------
    # Single task runner
    # ------------------------------------------------------------------

    async def _run_task(self, task: TaskItem, params: TaskParams) -> TaskResult:
        """
        Spawn a sub-process for *task* and collect its output.

        If *params.context* is provided it is prepended to the assignment
        string, separated by a newline, before being passed to the child.
        """
        assignment = task.assignment
        if params.context:
            assignment = f"{params.context}\n\n{assignment}"

        cmd = get_task_command(
            agent=params.agent,
            assignment=assignment,
            cwd=self.cwd,
        )

        start = time.monotonic()
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout_bytes, stderr_bytes = await proc.communicate()
            exit_code = proc.returncode or 0
        except Exception as exc:  # noqa: BLE001
            duration_ms = (time.monotonic() - start) * 1000
            return TaskResult(
                task_id=task.id,
                output="",
                exit_code=1,
                duration_ms=duration_ms,
                error=str(exc),
            )

        duration_ms = (time.monotonic() - start) * 1000
        output = stdout_bytes.decode("utf-8", errors="replace")
        stderr_text = stderr_bytes.decode("utf-8", errors="replace")

        error: str | None = None
        if exit_code != 0 and stderr_text:
            error = stderr_text.strip()

        return TaskResult(
            task_id=task.id,
            output=output,
            exit_code=exit_code,
            duration_ms=duration_ms,
            error=error,
        )
