# Task Delegation Feature

## Plan

Allow the agent to delegate multiple independent tasks to sub-agent processes,
collect their results, and return a structured summary.  Supports parallel
(default) and sequential execution modes.

## Integration Architecture

`TaskDelegator` is exposed as the built-in `"task"` tool in the tool registry.

**Tool registration:**

```python
from coding_agent.features.task_delegation import TaskDelegator, TaskParams, TaskItem

delegator = TaskDelegator(cwd=session.cwd, max_parallel=4)
```

**Tool call handler:**

```python
async def handle_task_tool(params: dict) -> str:
    task_params = TaskParams(
        agent=params["agent"],
        tasks=[TaskItem(**t) for t in params["tasks"]],
        context=params.get("context"),
        mode=params.get("mode", "parallel"),
    )
    result = await delegator.execute(task_params)
    return format_as_markdown_table(result)
```

**SubAgents integration:**

Before `delegator.execute()`, register each task's agent in `AgentRegistry`:

```python
for task in task_params.tasks:
    agent_id = registry.register(agent_def, owner_id=session.id)
```

After `execute()` completes, call `registry.mark_completed(agent_id)` or
`registry.mark_failed(agent_id, error)` for each.

## What Was Implemented

| File | Purpose |
|------|---------|
| `types.py` | `TaskItem`, `TaskParams`, `ExecutionMode`, `TaskResult`, `DelegationResult` |
| `executor.py` | `TaskDelegator` — parallel/sequential execution, subprocess management; `get_task_command()` |

## Usage Example

```python
import asyncio
from coding_agent.features.task_delegation import (
    TaskDelegator, TaskParams, TaskItem
)

delegator = TaskDelegator(cwd="/tmp/project", max_parallel=2)

params = TaskParams(
    agent="task",
    tasks=[
        TaskItem(id="t1", description="Lint files", assignment="Run the linter on src/"),
        TaskItem(id="t2", description="Run tests", assignment="Run the test suite"),
    ],
    mode="parallel",
)

async def main():
    result = await delegator.execute(params)
    print(f"Succeeded: {result.succeeded}, Failed: {result.failed}")
    for r in result.results:
        print(f"  {r.task_id}: exit={r.exit_code}, {r.duration_ms:.0f}ms")

asyncio.run(main())
```
