"""
Task delegation feature package.

Provides a TaskDelegator that runs batches of tasks as sub-agent processes,
collecting results in parallel or sequentially.
"""
from __future__ import annotations

from .executor import TaskDelegator, get_task_command
from .types import DelegationResult, ExecutionMode, TaskItem, TaskParams, TaskResult

__all__ = [
    "TaskDelegator",
    "TaskParams",
    "TaskItem",
    "ExecutionMode",
    "DelegationResult",
    "TaskResult",
    "get_task_command",
]
