"""
Task delegation type definitions.

Describes the input parameters and output results for delegating tasks to
sub-agent processes.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

ExecutionMode = Literal["parallel", "sequential"]


@dataclass
class TaskItem:
    """A single delegated task unit."""

    id: str
    description: str
    assignment: str


@dataclass
class TaskParams:
    """
    Parameters for a task delegation call.

    ``agent`` names the agent definition to use for each task.
    ``tasks`` is the list of work items.
    ``context`` is optional extra context passed to each sub-agent.
    ``isolated`` controls whether each sub-agent gets a clean working directory.
    ``mode`` controls whether tasks run in parallel or one at a time.
    """

    agent: str
    tasks: list[TaskItem]
    context: str | None = None
    isolated: bool = False
    mode: ExecutionMode = "parallel"


@dataclass
class TaskResult:
    """Result from a single completed (or failed) task."""

    task_id: str
    output: str
    exit_code: int
    duration_ms: float
    error: str | None = None
    tokens: int = 0


@dataclass
class DelegationResult:
    """Aggregate result from a :meth:`TaskDelegator.execute` call."""

    results: list[TaskResult]
    total_duration_ms: float
    succeeded: int
    failed: int
