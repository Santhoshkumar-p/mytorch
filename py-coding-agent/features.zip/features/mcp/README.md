# MCP Integration

Python port of the TypeScript MCP (Model Context Protocol) implementation
from `packages/oh-my-pi/packages/coding-agent/src/mcp/`.

---

## Plan

Port the TypeScript MCP feature module to a self-contained, liftable Python
package with:

- Zero external dependencies beyond Python stdlib and the `anthropic` package
  already in the project's requirements.
- Full async/await via `asyncio` throughout (no threading).
- The same two transports: **stdio** (subprocess) and **HTTP/SSE**.
- A single `MCPManager` class that discovers `.mcp.json` files, connects to
  servers in parallel, and exposes tools to the agent's tool registry.

---

## Integration Architecture

### 1. Add `mcp_manager` to `AgentSessionServices`

```python
# coding_agent/core/agent_session_services.py

from coding_agent.features.mcp import MCPManager

@dataclass
class AgentSessionServices:
    cwd: str
    agent_dir: str
    settings_manager: SettingsManager
    resource_loader: ResourceLoader
    mcp_manager: MCPManager | None = None   # <-- add this
```

### 2. Initialise `MCPManager` during session startup

```python
# coding_agent/core/agent_session_runtime.py  (or wherever sessions start)

manager = MCPManager(cwd=services.cwd)
result = await manager.discover_and_connect()
services.mcp_manager = manager
```

### 3. Inject MCP tools into the tool registry before the first turn

```python
# coding_agent/core/tools/registry.py  (inside build_tools or equivalent)

if services.mcp_manager:
    mcp_tools = services.mcp_manager.get_tools()
    for mcp_tool in mcp_tools:
        tools.append(_to_agent_tool_from_mcp(mcp_tool))
```

`_to_agent_tool_from_mcp` wraps `MCPTool.execute` in the same
`AgentToolResult / TextContent` shim used by `_wrap_execute` in
`registry.py`.

### 4. Tear down on session close

```python
if services.mcp_manager:
    await services.mcp_manager.disconnect_all()
```

---

## What Was Implemented

| File | Purpose |
|---|---|
| `types.py` | All dataclasses: server configs, JSON-RPC messages, tool definitions, content types, connection state |
| `transports/base.py` | `MCPTransport` abstract base class |
| `transports/stdio.py` | `StdioTransport` — JSON-RPC over subprocess stdin/stdout via `asyncio.create_subprocess_exec` |
| `transports/http.py` | `HttpTransport` — JSON-RPC over HTTP POST using `urllib.request` (no aiohttp); handles SSE response bodies |
| `client.py` | Stateless async functions: `connect_to_server`, `list_tools`, `call_tool`, `disconnect_server` |
| `config.py` | `load_mcp_config_file`, `find_mcp_config_files` (walks cwd → root → `~/.config`), `load_all_mcp_configs`, `validate_server_config` |
| `tool_bridge.py` | `MCPTool` class with `mcp__{server}__{tool}` naming, `execute()`, `from_server_tools()` factory |
| `manager.py` | `MCPManager` — parallel connect with 250 ms startup window, reconnect with exponential backoff, tool list refresh on `notifications/tools/list_changed` |
| `__init__.py` | Re-exports of all public types and functions |

---

## Usage Example

```python
import asyncio
from coding_agent.features.mcp import MCPManager

async def main() -> None:
    # 1. Create a manager for the current project directory
    manager = MCPManager(cwd="/path/to/project")

    # 2. Discover .mcp.json files and connect to all enabled servers
    result = await manager.discover_and_connect()
    print(f"Connected: {result.connected_servers}")
    print(f"Errors:    {result.errors}")

    # 3. Retrieve MCP tools (ready for injection into the agent registry)
    tools = manager.get_tools()
    for tool in tools:
        print(f"  {tool.name}: {tool.description}")

    # 4. Call a tool directly (the agent does this internally)
    if tools:
        output = await tools[0].execute({"query": "hello"})
        print(output)

    # 5. Clean up
    await manager.disconnect_all()

asyncio.run(main())
```
