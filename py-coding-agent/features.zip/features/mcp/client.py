"""
MCP client functions.

Handles connection initialization, tool listing, and tool calling.
These are plain async functions (not a class) that operate on
``MCPServerConnection`` objects.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Callable, Optional
from urllib.request import pathname2url

from .transports.base import MCPTransport
from .transports.http import create_http_transport
from .transports.stdio import create_stdio_transport
from .types import (
    MCPHttpServerConfig,
    MCPImplementation,
    MCPInitializeResult,
    MCPServerCapabilities,
    MCPServerConfig,
    MCPServerConnection,
    MCPSseServerConfig,
    MCPStdioServerConfig,
    MCPToolCallResult,
    MCPToolDefinition,
)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

PROTOCOL_VERSION = "2025-03-26"
CONNECTION_TIMEOUT_MS = 30_000
CLIENT_INFO = MCPImplementation(name="py-coding-agent", version="1.0.0")


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

async def _create_transport(config: MCPServerConfig) -> MCPTransport:
    """Pick the right transport class for the given config."""
    server_type = config.type or "stdio"
    if server_type == "stdio":
        return await create_stdio_transport(config)  # type: ignore[arg-type]
    if server_type in ("http", "sse"):
        return await create_http_transport(config)  # type: ignore[arg-type]
    raise ValueError(f"Unknown server type: {server_type!r}")


async def _default_request_handler(method: str, _params: Any) -> Any:
    """
    Handle standard server-to-client requests (ping, roots/list).
    Unknown methods raise with code -32601.
    """
    if method == "ping":
        return {}
    if method == "roots/list":
        cwd = os.getcwd()
        uri = Path(cwd).as_uri()
        return {"roots": [{"uri": uri, "name": Path(cwd).name}]}
    exc = RuntimeError(f"Unsupported server request: {method}")
    exc.code = -32601  # type: ignore[attr-defined]
    raise exc


def _parse_initialize_result(raw: Any) -> MCPInitializeResult:
    """Convert the raw dict from the server into an MCPInitializeResult."""
    caps_raw = raw.get("capabilities", {})
    capabilities = MCPServerCapabilities(
        tools=caps_raw.get("tools"),
        resources=caps_raw.get("resources"),
        prompts=caps_raw.get("prompts"),
        logging=caps_raw.get("logging"),
        experimental=caps_raw.get("experimental"),
    )
    info_raw = raw.get("serverInfo", {})
    server_info = MCPImplementation(
        name=info_raw.get("name", "unknown"),
        version=info_raw.get("version", "0.0.0"),
    )
    return MCPInitializeResult(
        protocol_version=raw.get("protocolVersion", PROTOCOL_VERSION),
        capabilities=capabilities,
        server_info=server_info,
        instructions=raw.get("instructions"),
    )


async def _initialize_connection(transport: MCPTransport) -> MCPInitializeResult:
    """Run the MCP initialize handshake."""
    params = {
        "protocolVersion": PROTOCOL_VERSION,
        "capabilities": {"roots": {"listChanged": False}},
        "clientInfo": {"name": CLIENT_INFO.name, "version": CLIENT_INFO.version},
    }
    raw = await transport.request("initialize", params)
    init_result = _parse_initialize_result(raw)
    await transport.notify("notifications/initialized")
    return init_result


# ---------------------------------------------------------------------------
# Public functions
# ---------------------------------------------------------------------------

async def connect_to_server(
    name: str,
    config: MCPServerConfig,
    on_notification: Optional[Callable[[str, Any], None]] = None,
    on_request: Optional[Callable[[str, Any], Any]] = None,
) -> MCPServerConnection:
    """
    Connect to an MCP server and run the initialize handshake.

    :param name: Logical name for the server (from .mcp.json).
    :param config: Server config (MCPStdioServerConfig, MCPHttpServerConfig, etc.).
    :param on_notification: Optional callback for server notifications.
    :param on_request: Optional handler for server-to-client requests.
    :returns: A connected MCPServerConnection.
    :raises: RuntimeError or asyncio.TimeoutError on connection failure.
    """
    import asyncio

    timeout_ms = config.timeout or CONNECTION_TIMEOUT_MS
    timeout_s = timeout_ms / 1000.0

    transport = await _create_transport(config)

    if on_notification:
        transport.on_notification = on_notification
    transport.on_request = on_request or _default_request_handler

    try:
        init_result = await asyncio.wait_for(
            _initialize_connection(transport),
            timeout=timeout_s,
        )
    except Exception:
        await transport.close()
        raise

    return MCPServerConnection(
        name=name,
        config=config,
        transport=transport,
        server_info=init_result.server_info,
        capabilities=init_result.capabilities,
        instructions=init_result.instructions,
    )


async def list_tools(conn: MCPServerConnection) -> list[MCPToolDefinition]:
    """
    List tools available on the connected server.

    Results are cached on the connection object after the first call.
    Returns an empty list if the server does not advertise tools capability.
    """
    if not conn.capabilities.tools:
        return []

    if conn.tools is not None:
        return conn.tools

    all_tools: list[MCPToolDefinition] = []
    cursor: Optional[str] = None

    while True:
        params: dict[str, Any] = {}
        if cursor:
            params["cursor"] = cursor

        raw = await conn.transport.request("tools/list", params)
        for t in raw.get("tools", []):
            all_tools.append(
                MCPToolDefinition(
                    name=t["name"],
                    description=t.get("description"),
                    input_schema=t.get("inputSchema", {"type": "object"}),
                )
            )
        cursor = raw.get("nextCursor")
        if not cursor:
            break

    conn.tools = all_tools
    return all_tools


async def call_tool(
    conn: MCPServerConnection,
    name: str,
    arguments: Optional[dict[str, Any]] = None,
    signal: Optional[Any] = None,
) -> MCPToolCallResult:
    """
    Call a tool on the connected server.

    :param conn: Active server connection.
    :param name: MCP tool name (as returned by list_tools).
    :param arguments: Tool arguments dict.
    :param signal: Unused placeholder (kept for API compatibility).
    :returns: MCPToolCallResult with content and isError flag.
    """
    params = {"name": name, "arguments": arguments or {}}
    raw = await conn.transport.request("tools/call", params)

    content = _parse_content(raw.get("content", []))
    return MCPToolCallResult(
        content=content,
        is_error=bool(raw.get("isError", False)),
    )


def _parse_content(raw_content: list[dict[str, Any]]) -> list[Any]:
    """Convert raw content dicts to typed MCPContent objects."""
    from .types import MCPImageContent, MCPResourceContent, MCPTextContent

    result = []
    for item in raw_content:
        t = item.get("type", "text")
        if t == "text":
            result.append(MCPTextContent(text=item.get("text", "")))
        elif t == "image":
            result.append(MCPImageContent(data=item.get("data", ""), mime_type=item.get("mimeType", "")))
        elif t == "resource":
            result.append(MCPResourceContent(resource=item.get("resource", {})))
        else:
            result.append(MCPTextContent(text=str(item)))
    return result


async def disconnect_server(conn: MCPServerConnection) -> None:
    """Close the transport for the given connection."""
    if conn.transport is not None:
        await conn.transport.close()
