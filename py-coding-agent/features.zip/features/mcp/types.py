"""
MCP (Model Context Protocol) type definitions.

Python port of the TypeScript types.ts.
Based on MCP specification 2025-03-26: https://modelcontextprotocol.io/specification/2025-03-26/
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional, Union


# =============================================================================
# JSON-RPC 2.0 Types
# =============================================================================

@dataclass
class JsonRpcRequest:
    """A JSON-RPC 2.0 request (client -> server)."""

    method: str
    id: Union[str, int]
    params: Optional[dict[str, Any]] = None
    jsonrpc: str = "2.0"


@dataclass
class JsonRpcNotification:
    """A JSON-RPC 2.0 notification (no response expected)."""

    method: str
    params: Optional[dict[str, Any]] = None
    jsonrpc: str = "2.0"


@dataclass
class JsonRpcError:
    """A JSON-RPC 2.0 error object."""

    code: int
    message: str
    data: Optional[Any] = None


@dataclass
class JsonRpcResponse:
    """A JSON-RPC 2.0 response (server -> client)."""

    id: Union[str, int]
    result: Optional[Any] = None
    error: Optional[JsonRpcError] = None
    jsonrpc: str = "2.0"


# =============================================================================
# MCP Server Configuration (.mcp.json format)
# =============================================================================

@dataclass
class MCPAuthConfig:
    """Authentication configuration for an MCP server."""

    type: str  # "oauth" | "apikey"
    credential_id: Optional[str] = None
    token_url: Optional[str] = None
    client_id: Optional[str] = None
    client_secret: Optional[str] = None


@dataclass
class MCPStdioServerConfig:
    """Configuration for an MCP server started as a subprocess (stdio)."""

    command: str
    type: str = "stdio"
    args: list[str] = field(default_factory=list)
    env: dict[str, str] = field(default_factory=dict)
    cwd: Optional[str] = None
    enabled: Optional[bool] = None
    timeout: Optional[int] = None
    auth: Optional[MCPAuthConfig] = None


@dataclass
class MCPHttpServerConfig:
    """Configuration for an MCP server reached via HTTP (Streamable HTTP transport)."""

    url: str
    type: str = "http"
    headers: dict[str, str] = field(default_factory=dict)
    enabled: Optional[bool] = None
    timeout: Optional[int] = None
    auth: Optional[MCPAuthConfig] = None


@dataclass
class MCPSseServerConfig:
    """Configuration for an MCP server reached via SSE (deprecated; use HTTP)."""

    url: str
    type: str = "sse"
    headers: dict[str, str] = field(default_factory=dict)
    enabled: Optional[bool] = None
    timeout: Optional[int] = None
    auth: Optional[MCPAuthConfig] = None


MCPServerConfig = Union[MCPStdioServerConfig, MCPHttpServerConfig, MCPSseServerConfig]


# =============================================================================
# MCP Protocol Types
# =============================================================================

@dataclass
class MCPImplementation:
    """Name + version of an MCP implementation (client or server)."""

    name: str
    version: str


@dataclass
class MCPClientCapabilities:
    """Capabilities advertised by the MCP client during initialize."""

    roots: Optional[dict[str, Any]] = None
    sampling: Optional[dict[str, Any]] = None
    experimental: Optional[dict[str, Any]] = None


@dataclass
class MCPServerCapabilities:
    """Capabilities reported by the MCP server in the initialize response."""

    tools: Optional[dict[str, Any]] = None
    resources: Optional[dict[str, Any]] = None
    prompts: Optional[dict[str, Any]] = None
    logging: Optional[dict[str, Any]] = None
    experimental: Optional[dict[str, Any]] = None


@dataclass
class MCPInitializeResult:
    """Result returned by the server for the ``initialize`` request."""

    protocol_version: str
    capabilities: MCPServerCapabilities
    server_info: MCPImplementation
    instructions: Optional[str] = None


# =============================================================================
# MCP Tool Types
# =============================================================================

@dataclass
class MCPToolDefinition:
    """A tool exposed by an MCP server."""

    name: str
    input_schema: dict[str, Any]
    description: Optional[str] = None


# =============================================================================
# MCP Content Types
# =============================================================================

@dataclass
class MCPTextContent:
    """Plain-text content item in a tool result."""

    text: str
    type: str = "text"


@dataclass
class MCPImageContent:
    """Base64-encoded image content item in a tool result."""

    data: str      # base64
    mime_type: str
    type: str = "image"


@dataclass
class MCPResourceContent:
    """Resource reference content item in a tool result."""

    resource: dict[str, Any]   # {uri, mimeType?, text?, blob?}
    type: str = "resource"


MCPContent = Union[MCPTextContent, MCPImageContent, MCPResourceContent]


@dataclass
class MCPToolCallResult:
    """Result returned by the server for a ``tools/call`` request."""

    content: list[MCPContent] = field(default_factory=list)
    is_error: bool = False


# =============================================================================
# MCP Server Connection State
# =============================================================================

@dataclass
class MCPServerConnection:
    """Runtime state of a connected MCP server."""

    name: str
    config: MCPServerConfig
    server_info: MCPImplementation
    capabilities: MCPServerCapabilities
    transport: Any = None          # MCPTransport — avoids circular import
    tools: Optional[list[MCPToolDefinition]] = None
    instructions: Optional[str] = None


# =============================================================================
# MCP Notification Method Names
# =============================================================================

class MCPNotificationMethods:
    """Standard MCP server notification method names."""

    TOOLS_LIST_CHANGED = "notifications/tools/list_changed"
    RESOURCES_LIST_CHANGED = "notifications/resources/list_changed"
    RESOURCES_UPDATED = "notifications/resources/updated"
    PROMPTS_LIST_CHANGED = "notifications/prompts/list_changed"


# =============================================================================
# Helpers
# =============================================================================

def to_json_rpc_error(exc: BaseException) -> JsonRpcError:
    """Convert any exception to a JsonRpcError, preserving code when available."""
    code = getattr(exc, "code", -32603)
    if not isinstance(code, int):
        code = -32603
    return JsonRpcError(code=code, message=str(exc))
