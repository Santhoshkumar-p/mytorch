"""
Abstract base class for MCP transports.

All transports must implement the MCPTransport interface so that
client.py can work without knowing the underlying protocol.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Callable, Optional


class MCPTransport(ABC):
    """
    Abstract MCP transport.

    Subclasses implement JSON-RPC 2.0 communication over a specific channel
    (stdio subprocess, HTTP, etc.).
    """

    # Event callbacks — set by the caller before/after connect().
    on_close: Optional[Callable[[], None]] = None
    on_error: Optional[Callable[[Exception], None]] = None
    on_notification: Optional[Callable[[str, Any], None]] = None
    # Called when the server sends a request to the client (e.g. roots/list, ping).
    # Should return the result or raise an exception with a .code attribute.
    on_request: Optional[Callable[[str, Any], Any]] = None

    @property
    @abstractmethod
    def connected(self) -> bool:
        """Return True if the transport is currently connected."""

    @abstractmethod
    async def request(
        self,
        method: str,
        params: Optional[dict[str, Any]] = None,
        timeout: Optional[float] = None,
        signal: Optional[Any] = None,
    ) -> Any:
        """
        Send a JSON-RPC request and await the response.

        :param method: RPC method name.
        :param params: Optional parameters dict.
        :param timeout: Per-request timeout in seconds (overrides config default).
        :param signal: Optional asyncio.Event to abort the request.
        :raises asyncio.TimeoutError: If the request times out.
        :raises RuntimeError: If the transport is not connected.
        """

    @abstractmethod
    async def notify(
        self,
        method: str,
        params: Optional[dict[str, Any]] = None,
    ) -> None:
        """
        Send a fire-and-forget JSON-RPC notification (no response expected).

        :param method: Notification method name.
        :param params: Optional parameters dict.
        """

    @abstractmethod
    async def close(self) -> None:
        """
        Close the transport and release resources.

        Pending request futures are rejected with a ``RuntimeError``.
        The ``on_close`` callback is invoked once after cleanup.
        """
