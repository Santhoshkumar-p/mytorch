"""
MCP stdio transport.

Implements JSON-RPC 2.0 over subprocess stdin/stdout.
Messages are newline-delimited JSON (NDJSON).
"""

from __future__ import annotations

import asyncio
import itertools
import json
import os
import sys
from typing import Any, Optional

from .base import MCPTransport
from ..types import (
    JsonRpcError,
    MCPStdioServerConfig,
    to_json_rpc_error,
)

_id_counter = itertools.count(1)


def _next_id() -> int:
    return next(_id_counter)


class StdioTransport(MCPTransport):
    """
    MCP transport that communicates with a subprocess over stdin/stdout.

    Protocol: one JSON object per line (NDJSON / JSON-RPC 2.0).
    """

    def __init__(self, config: MCPStdioServerConfig) -> None:
        self._config = config
        self._process: Optional[asyncio.subprocess.Process] = None
        self._pending: dict[int | str, asyncio.Future[Any]] = {}
        self._connected = False
        self._read_task: Optional[asyncio.Task[None]] = None

        # Callbacks (set by caller)
        self.on_close = None
        self.on_error = None
        self.on_notification = None
        self.on_request = None

    @property
    def connected(self) -> bool:
        return self._connected

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    async def connect(self) -> None:
        """Spawn the subprocess and start the read loop."""
        if self._connected:
            return

        cmd = [self._config.command] + list(self._config.args or [])
        env = {**os.environ, **(self._config.env or {})}
        cwd = self._config.cwd or os.getcwd()

        self._process = await asyncio.create_subprocess_exec(
            *cmd,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL,
            env=env,
            cwd=cwd,
        )
        self._connected = True
        self._read_task = asyncio.get_event_loop().create_task(self._read_loop())

    async def request(
        self,
        method: str,
        params: Optional[dict[str, Any]] = None,
        timeout: Optional[float] = None,
        signal: Optional[Any] = None,
    ) -> Any:
        """Send a JSON-RPC request; return its result or raise on error."""
        if not self._connected or self._process is None:
            raise RuntimeError("Transport not connected")

        req_id = _next_id()
        message = {
            "jsonrpc": "2.0",
            "id": req_id,
            "method": method,
            "params": params or {},
        }

        loop = asyncio.get_event_loop()
        future: asyncio.Future[Any] = loop.create_future()
        self._pending[req_id] = future

        timeout_s = timeout if timeout is not None else (self._config.timeout or 30_000) / 1000.0

        try:
            self._write_line(json.dumps(message))
        except Exception as exc:
            self._pending.pop(req_id, None)
            raise

        try:
            return await asyncio.wait_for(asyncio.shield(future), timeout=timeout_s)
        except asyncio.TimeoutError:
            self._pending.pop(req_id, None)
            if not future.done():
                future.cancel()
            raise asyncio.TimeoutError(f"Request '{method}' timed out after {timeout_s}s")

    async def notify(
        self,
        method: str,
        params: Optional[dict[str, Any]] = None,
    ) -> None:
        """Send a fire-and-forget JSON-RPC notification."""
        if not self._connected:
            raise RuntimeError("Transport not connected")
        message = {"jsonrpc": "2.0", "method": method, "params": params or {}}
        self._write_line(json.dumps(message))

    async def close(self) -> None:
        """Terminate the subprocess and reject all pending requests."""
        if not self._connected:
            return
        self._connected = False

        # Reject pending futures
        for future in self._pending.values():
            if not future.done():
                future.set_exception(RuntimeError("Transport closed"))
        self._pending.clear()

        # Kill subprocess
        if self._process is not None:
            try:
                self._process.kill()
            except ProcessLookupError:
                pass
            self._process = None

        # Wait for read loop to finish
        if self._read_task is not None:
            self._read_task.cancel()
            try:
                await self._read_task
            except (asyncio.CancelledError, Exception):
                pass
            self._read_task = None

        if self.on_close:
            self.on_close()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _write_line(self, line: str) -> None:
        """Write a newline-terminated JSON line to subprocess stdin."""
        if self._process is None or self._process.stdin is None:
            raise RuntimeError("Transport not connected")
        data = (line + "\n").encode()
        self._process.stdin.write(data)

    async def _read_loop(self) -> None:
        """Read stdout line by line, dispatch JSON-RPC messages."""
        assert self._process is not None
        assert self._process.stdout is not None
        try:
            async for raw in self._process.stdout:
                if not self._connected:
                    break
                line = raw.decode().strip()
                if not line:
                    continue
                try:
                    msg = json.loads(line)
                except json.JSONDecodeError:
                    continue
                try:
                    self._dispatch(msg)
                except Exception:
                    pass
        except Exception as exc:
            if self._connected and self.on_error:
                self.on_error(exc if isinstance(exc, Exception) else RuntimeError(str(exc)))
        finally:
            self._handle_close()

    def _dispatch(self, msg: Any) -> None:
        """Route a parsed JSON-RPC message to the correct handler."""
        if isinstance(msg, list):
            for m in msg:
                self._dispatch(m)
            return

        has_method = "method" in msg
        has_id = "id" in msg and msg["id"] is not None

        if has_method and has_id:
            # Server-to-client request
            asyncio.get_event_loop().create_task(self._handle_server_request(msg))
            return

        if has_id and not has_method:
            # Response to our request
            req_id = msg["id"]
            future = self._pending.pop(req_id, None)
            if future and not future.done():
                if "error" in msg and msg["error"]:
                    err = msg["error"]
                    future.set_exception(
                        RuntimeError(f"MCP error {err.get('code', -1)}: {err.get('message', 'unknown')}")
                    )
                else:
                    future.set_result(msg.get("result"))
            return

        if has_method and not has_id:
            # Notification
            if self.on_notification:
                self.on_notification(msg["method"], msg.get("params"))

    async def _handle_server_request(self, msg: dict[str, Any]) -> None:
        """Handle a server-to-client JSON-RPC request and send a response."""
        req_id = msg["id"]
        method = msg["method"]
        params = msg.get("params")
        try:
            if self.on_request is None:
                raise _method_not_found(method)
            result = self.on_request(method, params)
            if asyncio.iscoroutine(result):
                result = await result
            self._send_response(req_id, result=result)
        except Exception as exc:
            rpc_err = to_json_rpc_error(exc)
            self._send_response(req_id, error=rpc_err)

    def _send_response(
        self,
        req_id: Any,
        result: Any = None,
        error: Optional[JsonRpcError] = None,
    ) -> None:
        """Write a JSON-RPC response back to the subprocess."""
        if not self._connected:
            return
        if error:
            body = {"jsonrpc": "2.0", "id": req_id, "error": {"code": error.code, "message": error.message}}
        else:
            body = {"jsonrpc": "2.0", "id": req_id, "result": result if result is not None else {}}
        try:
            self._write_line(json.dumps(body))
        except Exception:
            pass

    def _handle_close(self) -> None:
        if not self._connected:
            return
        self._connected = False
        for future in self._pending.values():
            if not future.done():
                future.set_exception(RuntimeError("Transport closed"))
        self._pending.clear()
        if self.on_close:
            self.on_close()


def _method_not_found(method: str) -> Exception:
    exc = RuntimeError(f"Method not found: {method}")
    exc.code = -32601  # type: ignore[attr-defined]
    return exc


async def create_stdio_transport(config: MCPStdioServerConfig) -> StdioTransport:
    """Create and connect a stdio transport."""
    transport = StdioTransport(config)
    await transport.connect()
    return transport
