"""
MCP HTTP transport (Streamable HTTP / SSE).

Implements JSON-RPC 2.0 over HTTP POST.  Responses may be plain JSON or
SSE-wrapped JSON.  Uses only ``urllib.request`` — no aiohttp dependency.

Note: SSE streaming for server-to-client notifications is read in a
background asyncio task using ``asyncio.to_thread``.
"""

from __future__ import annotations

import asyncio
import itertools
import json
import urllib.error
import urllib.request
from typing import Any, Callable, Optional, Union

from .base import MCPTransport
from ..types import (
    JsonRpcError,
    MCPHttpServerConfig,
    MCPSseServerConfig,
    to_json_rpc_error,
)

_id_counter = itertools.count(1)


def _next_id() -> int:
    return next(_id_counter)


class HttpTransport(MCPTransport):
    """
    MCP transport that sends JSON-RPC 2.0 messages over HTTP POST.

    Supports:
    - Plain ``application/json`` responses.
    - ``text/event-stream`` (SSE) responses where the result arrives as an
      SSE event with ``data: <json>``.
    - Bearer-token auth via config headers.
    - A single retry on 401 / 403 if ``on_auth_error`` is set.
    """

    def __init__(self, config: Union[MCPHttpServerConfig, MCPSseServerConfig]) -> None:
        self._config = config
        self._connected = False
        self._session_id: Optional[str] = None

        # Callbacks
        self.on_close: Optional[Callable[[], None]] = None
        self.on_error: Optional[Callable[[Exception], None]] = None
        self.on_notification: Optional[Callable[[str, Any], None]] = None
        self.on_request: Optional[Callable[[str, Any], Any]] = None
        # Called on 401/403; return updated headers dict or None
        self.on_auth_error: Optional[Callable[[], Any]] = None

    @property
    def connected(self) -> bool:
        return self._connected

    @property
    def url(self) -> str:
        return self._config.url

    async def connect(self) -> None:
        """Mark the transport as connected (HTTP is connectionless)."""
        if self._connected:
            return
        self._connected = True

    async def request(
        self,
        method: str,
        params: Optional[dict[str, Any]] = None,
        timeout: Optional[float] = None,
        signal: Optional[Any] = None,
    ) -> Any:
        """POST a JSON-RPC request; return the result or raise on error."""
        try:
            return await self._execute_request(method, params, timeout)
        except Exception as exc:
            # Retry once on auth failure if on_auth_error is wired
            if self.on_auth_error and _is_auth_error(exc):
                new_headers = self.on_auth_error()
                if asyncio.iscoroutine(new_headers):
                    new_headers = await new_headers
                if new_headers:
                    self._config = _replace_headers(self._config, new_headers)
                    return await self._execute_request(method, params, timeout)
            raise

    async def notify(
        self,
        method: str,
        params: Optional[dict[str, Any]] = None,
    ) -> None:
        """POST a JSON-RPC notification (no response body expected)."""
        if not self._connected:
            raise RuntimeError("Transport not connected")
        body = {"jsonrpc": "2.0", "method": method, "params": params or {}}
        timeout_s = (self._config.timeout or 30_000) / 1000.0
        await asyncio.to_thread(self._post_raw, json.dumps(body).encode(), timeout_s)

    async def close(self) -> None:
        """Mark transport as disconnected; send DELETE if a session exists."""
        if not self._connected:
            return
        self._connected = False

        if self._session_id:
            try:
                timeout_s = (self._config.timeout or 30_000) / 1000.0
                await asyncio.to_thread(self._send_delete, self._session_id, timeout_s)
            except Exception:
                pass
            self._session_id = None

        if self.on_close:
            self.on_close()
            self.on_close = None

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _execute_request(
        self,
        method: str,
        params: Optional[dict[str, Any]],
        timeout: Optional[float],
    ) -> Any:
        if not self._connected:
            raise RuntimeError("Transport not connected")

        req_id = _next_id()
        body = {"jsonrpc": "2.0", "id": req_id, "method": method, "params": params or {}}
        timeout_s = timeout if timeout is not None else (self._config.timeout or 30_000) / 1000.0
        raw_body = json.dumps(body).encode()

        status_code, content_type, response_headers, response_body = await asyncio.to_thread(
            self._post_with_response, raw_body, timeout_s
        )

        # Capture session ID
        new_sid = response_headers.get("mcp-session-id") or response_headers.get("Mcp-Session-Id")
        if new_sid:
            self._session_id = new_sid

        if content_type and "text/event-stream" in content_type:
            return self._parse_sse_body(response_body, req_id)

        # Plain JSON
        parsed = json.loads(response_body)
        if parsed.get("error"):
            err = parsed["error"]
            raise RuntimeError(f"MCP error {err.get('code', -1)}: {err.get('message', 'unknown')}")
        return parsed.get("result")

    def _build_headers(self, extra: Optional[dict[str, str]] = None) -> dict[str, str]:
        headers: dict[str, str] = {
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
        }
        headers.update(self._config.headers or {})
        if self._session_id:
            headers["Mcp-Session-Id"] = self._session_id
        if extra:
            headers.update(extra)
        return headers

    def _post_raw(self, body: bytes, timeout: float) -> None:
        """Fire-and-forget POST (for notifications)."""
        headers = self._build_headers()
        req = urllib.request.Request(self._config.url, data=body, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                resp.read()  # drain
        except urllib.error.HTTPError as exc:
            if exc.code not in (200, 202):
                raise RuntimeError(f"HTTP {exc.code}: {exc.reason}") from exc

    def _post_with_response(
        self, body: bytes, timeout: float
    ) -> tuple[int, str, dict[str, str], bytes]:
        """POST and return (status, content_type, headers, body)."""
        headers = self._build_headers()
        req = urllib.request.Request(self._config.url, data=body, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                status = resp.status
                ct = resp.headers.get("Content-Type", "")
                resp_headers = {k.lower(): v for k, v in resp.headers.items()}
                data = resp.read()
                return status, ct, resp_headers, data
        except urllib.error.HTTPError as exc:
            raise RuntimeError(f"HTTP {exc.code}: {exc.reason}") from exc

    def _send_delete(self, session_id: str, timeout: float) -> None:
        headers = {**(self._config.headers or {}), "Mcp-Session-Id": session_id}
        req = urllib.request.Request(self._config.url, headers=headers, method="DELETE")
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                resp.read()
        except Exception:
            pass

    def _parse_sse_body(self, body: bytes, expected_id: Any) -> Any:
        """
        Parse an SSE response body looking for the JSON-RPC result matching
        ``expected_id``.  Also dispatches notifications encountered inline.
        """
        text = body.decode()
        data_lines: list[str] = []
        for line in text.splitlines():
            if line.startswith("data:"):
                data_lines.append(line[5:].strip())

        for data in data_lines:
            if not data:
                continue
            try:
                msg = json.loads(data)
            except json.JSONDecodeError:
                continue

            messages = msg if isinstance(msg, list) else [msg]
            for m in messages:
                mid = m.get("id")
                if mid == expected_id and ("result" in m or "error" in m):
                    if m.get("error"):
                        err = m["error"]
                        raise RuntimeError(f"MCP error {err.get('code', -1)}: {err.get('message', 'unknown')}")
                    return m.get("result")
                # Dispatch notification if encountered inline
                if "method" in m and "id" not in m and self.on_notification:
                    self.on_notification(m["method"], m.get("params"))

        raise RuntimeError(f"No response found in SSE body for request id={expected_id}")


def _is_auth_error(exc: Exception) -> bool:
    msg = str(exc)
    return "HTTP 401" in msg or "HTTP 403" in msg


def _replace_headers(
    config: Union[MCPHttpServerConfig, MCPSseServerConfig],
    new_headers: dict[str, str],
) -> Union[MCPHttpServerConfig, MCPSseServerConfig]:
    """Return a shallow copy of config with headers replaced."""
    import dataclasses
    return dataclasses.replace(config, headers=new_headers)


async def create_http_transport(
    config: Union[MCPHttpServerConfig, MCPSseServerConfig]
) -> HttpTransport:
    """Create and connect an HTTP transport."""
    transport = HttpTransport(config)
    await transport.connect()
    return transport
