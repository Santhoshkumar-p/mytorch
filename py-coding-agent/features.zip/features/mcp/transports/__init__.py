"""
MCP transport implementations.

Each transport implements the MCPTransport ABC from ``base.py``.
Available transports:

- ``StdioTransport`` — JSON-RPC over subprocess stdin/stdout.
- ``HttpTransport``  — JSON-RPC over HTTP POST (supports SSE responses).
"""
