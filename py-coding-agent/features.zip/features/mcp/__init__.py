"""
MCP (Model Context Protocol) integration for py-coding-agent.

Public surface:

- ``MCPManager`` — discover, connect, and manage MCP servers.
- ``MCPLoadResult`` — result of a connect/discover call.
- ``MCPTool`` — bridge wrapping an MCP server tool for the agent registry.
- Config types: ``MCPStdioServerConfig``, ``MCPHttpServerConfig``, ``MCPSseServerConfig``.
- ``load_all_mcp_configs(cwd)`` — load and merge all .mcp.json files.
"""

from __future__ import annotations

from .config import (
    MCPConfigFile,
    find_mcp_config_files,
    load_all_mcp_configs,
    load_mcp_config_file,
    validate_server_config,
)
from .manager import MCPLoadResult, MCPManager
from .tool_bridge import MCPTool, create_mcp_tool_name
from .types import (
    MCPContent,
    MCPHttpServerConfig,
    MCPImageContent,
    MCPImplementation,
    MCPInitializeResult,
    MCPResourceContent,
    MCPServerCapabilities,
    MCPServerConfig,
    MCPServerConnection,
    MCPSseServerConfig,
    MCPStdioServerConfig,
    MCPTextContent,
    MCPToolCallResult,
    MCPToolDefinition,
)

__all__ = [
    # Manager
    "MCPManager",
    "MCPLoadResult",
    # Tool bridge
    "MCPTool",
    "create_mcp_tool_name",
    # Config
    "MCPConfigFile",
    "find_mcp_config_files",
    "load_all_mcp_configs",
    "load_mcp_config_file",
    "validate_server_config",
    # Config types
    "MCPServerConfig",
    "MCPStdioServerConfig",
    "MCPHttpServerConfig",
    "MCPSseServerConfig",
    # Protocol types
    "MCPToolDefinition",
    "MCPToolCallResult",
    "MCPServerConnection",
    "MCPServerCapabilities",
    "MCPImplementation",
    "MCPInitializeResult",
    # Content types
    "MCPContent",
    "MCPTextContent",
    "MCPImageContent",
    "MCPResourceContent",
]
