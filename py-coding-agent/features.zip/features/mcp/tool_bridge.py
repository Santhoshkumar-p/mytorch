"""
MCP tool bridge.

Wraps MCPToolDefinition + MCPServerConnection into MCPTool objects whose
interface matches the dict-based tool format used by
``coding_agent/core/tools/registry.py``.

Naming convention: ``mcp__{server}__{tool}``
(double underscore separates namespace segments).
"""

from __future__ import annotations

import json
import re
from typing import Any, Callable, Optional

from .client import call_tool
from .types import (
    MCPContent,
    MCPImageContent,
    MCPResourceContent,
    MCPServerConnection,
    MCPTextContent,
    MCPToolDefinition,
)

# ---------------------------------------------------------------------------
# Retriable error detection (mirrors TS tool-bridge)
# ---------------------------------------------------------------------------

_RETRIABLE_PATTERNS = [
    "econnrefused",
    "econnreset",
    "epipe",
    "enetunreach",
    "ehostunreach",
    "fetch failed",
    "transport not connected",
    "transport closed",
    "network error",
]

_RETRIABLE_HTTP_RE = re.compile(r"^http (404|502|503):", re.IGNORECASE)


def is_retriable_connection_error(exc: BaseException) -> bool:
    """Return True if the error warrants a reconnect + single retry."""
    if not isinstance(exc, Exception):
        return False
    msg = str(exc).lower()
    if _RETRIABLE_HTTP_RE.match(msg):
        return True
    return any(p in msg for p in _RETRIABLE_PATTERNS)


# ---------------------------------------------------------------------------
# Tool-name helpers
# ---------------------------------------------------------------------------

def _sanitize_part(value: str, fallback: str) -> str:
    """Lowercase, collapse non-[a-z_] runs to underscores, strip leading/trailing."""
    sanitized = re.sub(r"[^a-z_]+", "_", value.lower())
    sanitized = re.sub(r"_+", "_", sanitized).strip("_")
    return sanitized if sanitized else fallback


def create_mcp_tool_name(server_name: str, tool_name: str) -> str:
    """
    Build the canonical tool name: ``mcp__{server}__{tool}``.

    If the tool name already starts with the server name prefix (e.g.
    server="puppeteer", tool="puppeteer_screenshot"), the redundant prefix is
    stripped to avoid ``mcp__puppeteer__puppeteer_screenshot``.
    """
    s = _sanitize_part(server_name, "server")
    t = _sanitize_part(tool_name, "tool")
    # Strip redundant server prefix from tool name
    prefix = f"{s}_"
    if t.startswith(prefix):
        t = t[len(prefix):]
    return f"mcp__{s}__{t}"


# ---------------------------------------------------------------------------
# Content formatting
# ---------------------------------------------------------------------------

def format_mcp_content(content: list[MCPContent]) -> str:
    """Render MCP content list to a plain string for LLM consumption."""
    parts: list[str] = []
    for item in content:
        if isinstance(item, MCPTextContent):
            parts.append(item.text)
        elif isinstance(item, MCPImageContent):
            parts.append(f"[Image: {item.mime_type}]")
        elif isinstance(item, MCPResourceContent):
            res = item.resource
            uri = res.get("uri", "")
            text = res.get("text")
            if text:
                parts.append(f"[Resource: {uri}]\n{text}")
            else:
                parts.append(f"[Resource: {uri}]")
        else:
            parts.append(str(item))
    return "\n\n".join(parts)


# ---------------------------------------------------------------------------
# MCPTool
# ---------------------------------------------------------------------------

class MCPTool:
    """
    A tool that wraps an MCP server tool and exposes the same interface as
    the dict-based tools in ``coding_agent/core/tools/registry.py``.

    The ``name`` uses the ``mcp__{server}__{tool}`` pattern so it is unique
    across all loaded MCP servers.
    """

    def __init__(
        self,
        connection: MCPServerConnection,
        tool_def: MCPToolDefinition,
        reconnect_fn: Optional[Callable[[], Any]] = None,
    ) -> None:
        self._connection = connection
        self._tool_def = tool_def
        self._reconnect_fn = reconnect_fn

        self.name: str = create_mcp_tool_name(connection.name, tool_def.name)
        self.description: str = tool_def.description or f"MCP tool from {connection.name}"
        self.input_schema: dict[str, Any] = tool_def.input_schema
        self.label: str = f"{connection.name}/{tool_def.name}"

        # Original MCP tool name (before normalization)
        self.mcp_tool_name: str = tool_def.name
        self.mcp_server_name: str = connection.name

    # ------------------------------------------------------------------
    # Registry-compatible descriptor (for pi_agent.AgentTool)
    # ------------------------------------------------------------------

    @property
    def parameters(self) -> dict[str, Any]:
        """Alias used by registry.py / pi_agent tooling."""
        return self.input_schema

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------

    async def execute(
        self,
        params: dict[str, Any],
        signal: Optional[Any] = None,
    ) -> str:
        """
        Call the MCP tool and return a plain-string result.

        Retries once after reconnecting if a retriable connection error occurs.
        """
        args = _normalize_args(params)

        try:
            result = await call_tool(self._connection, self._tool_def.name, args, signal=signal)
        except Exception as exc:
            if self._reconnect_fn and is_retriable_connection_error(exc):
                new_conn = await _safe_reconnect(self._reconnect_fn)
                if new_conn is not None:
                    self._connection = new_conn
                    try:
                        result = await call_tool(new_conn, self._tool_def.name, args, signal=signal)
                    except Exception as retry_exc:
                        return f"MCP error: {retry_exc}"
                else:
                    return f"MCP error: {exc}"
            else:
                return f"MCP error: {exc}"

        text = format_mcp_content(result.content)
        if result.is_error:
            return f"Error: {text}"
        return text

    # ------------------------------------------------------------------
    # Factory
    # ------------------------------------------------------------------

    @classmethod
    def from_server_tools(
        cls,
        conn: MCPServerConnection,
        tools: list[MCPToolDefinition],
        reconnect_fn: Optional[Callable[[], Any]] = None,
    ) -> list[MCPTool]:
        """Create MCPTool wrappers for all tools from a connected server."""
        return [cls(conn, t, reconnect_fn) for t in tools]

    # ------------------------------------------------------------------
    # Representation
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return f"<MCPTool name={self.name!r} server={self.mcp_server_name!r}>"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _normalize_args(value: Any) -> dict[str, Any]:
    """Ensure tool arguments are a plain dict (coerce if needed)."""
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
            if isinstance(parsed, dict):
                return parsed
        except json.JSONDecodeError:
            pass
    return {}


async def _safe_reconnect(reconnect_fn: Callable[[], Any]) -> Optional[MCPServerConnection]:
    """Call reconnect_fn; return the new connection or None on failure."""
    try:
        result = reconnect_fn()
        if hasattr(result, "__await__") or hasattr(result, "send"):
            import asyncio
            result = await result
        return result
    except Exception:
        return None
