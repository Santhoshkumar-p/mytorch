"""
MCP configuration loader.

Reads ``.mcp.json`` / ``mcp.json`` files from the project directory tree
and ``~/.config/`` and merges them into a single map of server configs.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from .types import (
    MCPAuthConfig,
    MCPHttpServerConfig,
    MCPServerConfig,
    MCPSseServerConfig,
    MCPStdioServerConfig,
)


# ---------------------------------------------------------------------------
# Config file schema
# ---------------------------------------------------------------------------

@dataclass
class MCPConfigFile:
    """Root structure of an ``.mcp.json`` / ``mcp.json`` file."""

    mcp_servers: dict[str, MCPServerConfig] = field(default_factory=dict)
    disabled_servers: list[str] = field(default_factory=list)
    schema: Optional[str] = None


# ---------------------------------------------------------------------------
# Parsing helpers
# ---------------------------------------------------------------------------

def _parse_auth(raw: dict) -> Optional[MCPAuthConfig]:
    if not raw:
        return None
    return MCPAuthConfig(
        type=raw.get("type", "apikey"),
        credential_id=raw.get("credentialId"),
        token_url=raw.get("tokenUrl"),
        client_id=raw.get("clientId"),
        client_secret=raw.get("clientSecret"),
    )


def _parse_server_config(raw: dict) -> MCPServerConfig:
    """Convert a raw dict (from JSON) into a typed MCPServerConfig."""
    server_type = raw.get("type", "stdio")
    auth = _parse_auth(raw.get("auth") or {})
    enabled = raw.get("enabled")
    timeout = raw.get("timeout")

    if server_type == "http":
        return MCPHttpServerConfig(
            url=raw.get("url", ""),
            type="http",
            headers=raw.get("headers") or {},
            enabled=enabled,
            timeout=timeout,
            auth=auth,
        )
    if server_type == "sse":
        return MCPSseServerConfig(
            url=raw.get("url", ""),
            type="sse",
            headers=raw.get("headers") or {},
            enabled=enabled,
            timeout=timeout,
            auth=auth,
        )
    # Default: stdio
    return MCPStdioServerConfig(
        command=raw.get("command", ""),
        type="stdio",
        args=raw.get("args") or [],
        env=raw.get("env") or {},
        cwd=raw.get("cwd"),
        enabled=enabled,
        timeout=timeout,
        auth=auth,
    )


def load_mcp_config_file(path: str) -> MCPConfigFile:
    """
    Parse a single ``.mcp.json`` or ``mcp.json`` file.

    :param path: Absolute path to the JSON config file.
    :returns: Parsed MCPConfigFile (empty defaults if file is unreadable).
    """
    try:
        with open(path, encoding="utf-8") as fh:
            raw = json.load(fh)
    except (OSError, json.JSONDecodeError):
        return MCPConfigFile()

    servers: dict[str, MCPServerConfig] = {}
    for name, srv_raw in (raw.get("mcpServers") or {}).items():
        if not isinstance(srv_raw, dict):
            continue
        try:
            servers[name] = _parse_server_config(srv_raw)
        except Exception:
            pass  # Skip malformed entries

    return MCPConfigFile(
        mcp_servers=servers,
        disabled_servers=raw.get("disabledServers") or [],
        schema=raw.get("$schema"),
    )


# ---------------------------------------------------------------------------
# Discovery
# ---------------------------------------------------------------------------

_CONFIG_NAMES = (".mcp.json", "mcp.json")


def find_mcp_config_files(cwd: str) -> list[str]:
    """
    Search for MCP config files starting from *cwd* up to the filesystem root,
    then check ``~/.config/``.

    :param cwd: Starting directory (project root).
    :returns: List of absolute paths to discovered config files, closest first.
    """
    found: list[str] = []

    # Walk upwards from cwd
    current = Path(cwd).resolve()
    while True:
        for name in _CONFIG_NAMES:
            candidate = current / name
            if candidate.is_file():
                found.append(str(candidate))
                break  # Only one per directory level
        parent = current.parent
        if parent == current:
            break
        current = parent

    # User global config
    user_config_dir = Path.home() / ".config"
    for name in _CONFIG_NAMES:
        candidate = user_config_dir / name
        if candidate.is_file() and str(candidate) not in found:
            found.append(str(candidate))
            break

    return found


# ---------------------------------------------------------------------------
# Merge + load
# ---------------------------------------------------------------------------

def load_all_mcp_configs(cwd: str) -> dict[str, MCPServerConfig]:
    """
    Discover all MCP config files for *cwd*, merge them, and return the
    effective server map (disabled servers excluded).

    Files discovered closer to *cwd* take precedence over files found higher
    in the directory tree.

    :param cwd: Project root directory.
    :returns: Mapping of server name -> MCPServerConfig.
    """
    paths = find_mcp_config_files(cwd)
    merged: dict[str, MCPServerConfig] = {}
    all_disabled: set[str] = set()

    # Process from global -> local so that local (first in list) wins on merge
    for path in reversed(paths):
        cfg = load_mcp_config_file(path)
        all_disabled.update(cfg.disabled_servers)
        merged.update(cfg.mcp_servers)

    # Filter disabled and explicitly disabled entries
    result: dict[str, MCPServerConfig] = {}
    for name, config in merged.items():
        if name in all_disabled:
            continue
        if config.enabled is False:
            continue
        result[name] = config

    return result


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

def validate_server_config(name: str, config: MCPServerConfig) -> list[str]:
    """
    Check that a server config has all required fields.

    :param name: Server name (for error messages).
    :param config: Config to validate.
    :returns: List of human-readable error strings (empty = valid).
    """
    errors: list[str] = []
    server_type = getattr(config, "type", "stdio") or "stdio"

    has_command = isinstance(config, MCPStdioServerConfig) and bool(config.command)
    has_url = isinstance(config, (MCPHttpServerConfig, MCPSseServerConfig)) and bool(config.url)

    if has_command and has_url:
        errors.append(
            f'Server "{name}": both "command" and "url" are set — must be either stdio or http/sse'
        )

    if server_type == "stdio":
        if not isinstance(config, MCPStdioServerConfig) or not config.command:
            errors.append(f'Server "{name}": stdio server requires "command" field')
    elif server_type in ("http", "sse"):
        if not isinstance(config, (MCPHttpServerConfig, MCPSseServerConfig)) or not config.url:
            errors.append(f'Server "{name}": {server_type} server requires "url" field')
    else:
        errors.append(f'Server "{name}": unknown server type "{server_type}"')

    return errors
