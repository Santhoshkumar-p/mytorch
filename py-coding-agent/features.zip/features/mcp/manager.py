"""
MCP Server Manager.

Discovers, connects to, and manages the lifecycle of MCP servers.
Connections run in parallel; there is a 250 ms startup window after which
tools from still-connecting servers are omitted from the initial result
(they appear once the background connection finishes).
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from .client import connect_to_server, disconnect_server, list_tools
from .config import find_mcp_config_files, load_all_mcp_configs, validate_server_config
from .tool_bridge import MCPTool
from .types import (
    MCPNotificationMethods,
    MCPServerConfig,
    MCPServerConnection,
    MCPToolDefinition,
)

STARTUP_TIMEOUT_MS = 250


# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------

@dataclass
class MCPLoadResult:
    """Outcome of a connect_servers / discover_and_connect call."""

    tools: list[MCPTool] = field(default_factory=list)
    errors: dict[str, str] = field(default_factory=dict)
    connected_servers: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Stable sort
# ---------------------------------------------------------------------------

def _sort_tools(tools: list[MCPTool]) -> list[MCPTool]:
    """
    Sort tools by name.

    Anthropic prompt caching keys on byte-identical tool definitions.
    Sorting after every mutation keeps the array stable regardless of
    connection completion order.
    """
    tools.sort(key=lambda t: t.name)
    return tools


# ---------------------------------------------------------------------------
# Manager
# ---------------------------------------------------------------------------

class MCPManager:
    """
    Manages connections to MCP servers and provides tools to the agent.

    Usage::

        manager = MCPManager(cwd="/path/to/project")
        result = await manager.discover_and_connect()
        tools = manager.get_tools()
        # ... inject tools into agent session ...
        await manager.disconnect_all()
    """

    def __init__(self, cwd: str) -> None:
        self._cwd = cwd
        self._connections: dict[str, MCPServerConnection] = {}
        self._tools: list[MCPTool] = []
        self._server_configs: dict[str, MCPServerConfig] = {}
        self._pending_reconnections: dict[str, asyncio.Task[Optional[MCPServerConnection]]] = {}
        # Optional callbacks
        self._on_tools_changed: Optional[Callable[[list[MCPTool]], None]] = None
        self._on_notification: Optional[Callable[[str, str, Any], None]] = None
        self._epoch = 0

    # ------------------------------------------------------------------
    # Callback registration
    # ------------------------------------------------------------------

    def set_on_tools_changed(self, handler: Callable[[list[MCPTool]], None]) -> None:
        """Register a callback invoked whenever the tool list changes."""
        self._on_tools_changed = handler

    def set_on_notification(self, handler: Callable[[str, str, Any], None]) -> None:
        """Register a callback for server notifications (name, method, params)."""
        self._on_notification = handler

    # ------------------------------------------------------------------
    # Discovery + connection
    # ------------------------------------------------------------------

    async def discover_and_connect(self) -> MCPLoadResult:
        """
        Load all MCP configs from ``.mcp.json`` files and connect to servers.

        :returns: MCPLoadResult with tools, per-server errors, and server names.
        """
        configs = load_all_mcp_configs(self._cwd)
        return await self.connect_servers(configs)

    async def connect_servers(
        self,
        configs: dict[str, MCPServerConfig],
    ) -> MCPLoadResult:
        """
        Connect to specific MCP servers in parallel.

        :param configs: Mapping of server name -> config.
        :returns: MCPLoadResult.
        """
        errors: dict[str, str] = {}
        connected_servers: list[str] = []
        all_tools: list[MCPTool] = []

        tasks: dict[str, asyncio.Task[tuple[MCPServerConnection, list[MCPToolDefinition]]]] = {}

        for name, config in configs.items():
            if name in self._connections:
                connected_servers.append(name)
                continue

            validation_errors = validate_server_config(name, config)
            if validation_errors:
                errors[name] = "; ".join(validation_errors)
                continue

            self._server_configs[name] = config
            tasks[name] = asyncio.get_event_loop().create_task(
                self._connect_and_list(name, config)
            )

        if not tasks:
            return MCPLoadResult(tools=all_tools, errors=errors, connected_servers=connected_servers)

        # Wait up to STARTUP_TIMEOUT_MS for all tasks to finish
        startup_timeout = STARTUP_TIMEOUT_MS / 1000.0
        done, pending = await asyncio.wait(
            tasks.values(),
            timeout=startup_timeout,
        )

        # Wait for remaining tasks (they'll continue in background)
        if pending:
            remaining_done, _ = await asyncio.wait(pending, timeout=None)
            done = done | remaining_done

        for name, task in tasks.items():
            if task.done():
                exc = task.exception()
                if exc:
                    errors[name] = str(exc)
                else:
                    conn, server_tools = task.result()
                    self._connections[name] = conn
                    connected_servers.append(name)
                    reconnect_fn = lambda n=name: self.reconnect_server(n)
                    mcp_tools = MCPTool.from_server_tools(conn, server_tools, reconnect_fn)
                    all_tools.extend(mcp_tools)
                    self._replace_server_tools(name, mcp_tools)
                    # Wire transport close -> reconnect
                    self._wire_transport(name, conn)
            else:
                # Still pending after timeout — task runs in background
                task.add_done_callback(
                    lambda t, n=name, cfg=configs[name]: self._on_background_connect(n, cfg, t)
                )

        _sort_tools(all_tools)
        self._tools = all_tools

        return MCPLoadResult(
            tools=list(self._tools),
            errors=errors,
            connected_servers=connected_servers,
        )

    # ------------------------------------------------------------------
    # Accessors
    # ------------------------------------------------------------------

    def get_tools(self) -> list[MCPTool]:
        """Return all currently loaded MCP tools (stable-sorted by name)."""
        return list(self._tools)

    def get_connection(self, name: str) -> Optional[MCPServerConnection]:
        """Return the active connection for *name*, or None."""
        return self._connections.get(name)

    def get_connected_servers(self) -> list[str]:
        """Return names of currently connected servers."""
        return list(self._connections.keys())

    # ------------------------------------------------------------------
    # Disconnect
    # ------------------------------------------------------------------

    async def disconnect_all(self) -> None:
        """Disconnect from all servers and clear all state."""
        self._epoch += 1
        # Detach onClose to prevent reconnect storms
        for conn in self._connections.values():
            if conn.transport:
                conn.transport.on_close = None

        await asyncio.gather(
            *(disconnect_server(conn) for conn in self._connections.values()),
            return_exceptions=True,
        )

        # Cancel pending reconnections
        for task in self._pending_reconnections.values():
            task.cancel()

        self._connections.clear()
        self._tools.clear()
        self._server_configs.clear()
        self._pending_reconnections.clear()

    async def disconnect_server(self, name: str) -> None:
        """Disconnect a single server and remove its tools."""
        conn = self._connections.pop(name, None)
        if conn:
            if conn.transport:
                conn.transport.on_close = None
            await disconnect_server(conn)

        self._server_configs.pop(name, None)
        task = self._pending_reconnections.pop(name, None)
        if task:
            task.cancel()

        prev_count = len(self._tools)
        self._tools = [t for t in self._tools if t.mcp_server_name != name]
        if len(self._tools) != prev_count and self._on_tools_changed:
            self._on_tools_changed(self._tools)

    # ------------------------------------------------------------------
    # Reconnection
    # ------------------------------------------------------------------

    async def reconnect_server(self, name: str) -> Optional[MCPServerConnection]:
        """
        Reconnect to a named server.

        Concurrent calls share a single in-flight reconnection task.
        Returns the new connection, or None if reconnection failed.
        """
        existing_task = self._pending_reconnections.get(name)
        if existing_task and not existing_task.done():
            try:
                return await existing_task
            except Exception:
                return None

        task = asyncio.get_event_loop().create_task(self._do_reconnect(name))
        self._pending_reconnections[name] = task
        try:
            return await task
        except Exception:
            return None
        finally:
            self._pending_reconnections.pop(name, None)

    async def _do_reconnect(self, name: str) -> Optional[MCPServerConnection]:
        """Internal reconnect with exponential backoff (up to 4 retries)."""
        config = self._server_configs.get(name)
        if not config:
            return None

        old_conn = self._connections.pop(name, None)
        if old_conn and old_conn.transport:
            old_conn.transport.on_close = None
            asyncio.get_event_loop().create_task(
                _safe_close(old_conn.transport)
            )

        epoch = self._epoch
        delays = [0.5, 1.0, 2.0, 4.0]
        for attempt in range(len(delays) + 1):
            if self._epoch != epoch:
                return None
            try:
                conn, server_tools = await self._connect_and_list(name, config)
                self._connections[name] = conn
                self._wire_transport(name, conn)
                reconnect_fn = lambda n=name: self.reconnect_server(n)
                mcp_tools = MCPTool.from_server_tools(conn, server_tools, reconnect_fn)
                self._replace_server_tools(name, mcp_tools)
                return conn
            except Exception:
                if attempt < len(delays):
                    await asyncio.sleep(delays[attempt])
        return None

    # ------------------------------------------------------------------
    # Tool refresh
    # ------------------------------------------------------------------

    async def refresh_server_tools(self, name: str) -> None:
        """Re-fetch the tool list from a connected server."""
        conn = self._connections.get(name)
        if not conn:
            return
        conn.tools = None  # clear cache
        server_tools = await list_tools(conn)
        reconnect_fn = lambda n=name: self.reconnect_server(n)
        mcp_tools = MCPTool.from_server_tools(conn, server_tools, reconnect_fn)
        self._replace_server_tools(name, mcp_tools)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _connect_and_list(
        self,
        name: str,
        config: MCPServerConfig,
    ) -> tuple[MCPServerConnection, list[MCPToolDefinition]]:
        """Connect to server and fetch its tool list."""
        conn = await connect_to_server(
            name,
            config,
            on_notification=lambda method, params: self._handle_notification(name, method, params),
        )
        tools = await list_tools(conn)
        return conn, tools

    def _wire_transport(self, name: str, conn: MCPServerConnection) -> None:
        """Attach on_close handler to trigger reconnection on transport loss."""
        if conn.transport:
            def _on_close(n: str = name) -> None:
                asyncio.get_event_loop().create_task(self.reconnect_server(n))
            conn.transport.on_close = _on_close

    def _replace_server_tools(self, name: str, new_tools: list[MCPTool]) -> None:
        """Replace the tool entries for *name* and keep the list sorted."""
        self._tools = [t for t in self._tools if t.mcp_server_name != name]
        self._tools.extend(new_tools)
        _sort_tools(self._tools)
        if self._on_tools_changed:
            self._on_tools_changed(self._tools)

    def _handle_notification(self, server_name: str, method: str, params: Any) -> None:
        """Dispatch server notifications to callbacks and handle list-changed."""
        if method == MCPNotificationMethods.TOOLS_LIST_CHANGED:
            asyncio.get_event_loop().create_task(self.refresh_server_tools(server_name))

        if self._on_notification:
            self._on_notification(server_name, method, params)

    def _on_background_connect(
        self,
        name: str,
        config: MCPServerConfig,
        task: asyncio.Task[tuple[MCPServerConnection, list[MCPToolDefinition]]],
    ) -> None:
        """Called when a background connection task finishes after startup timeout."""
        if task.cancelled() or task.exception():
            return
        conn, server_tools = task.result()
        self._connections[name] = conn
        self._wire_transport(name, conn)
        reconnect_fn = lambda n=name: self.reconnect_server(n)
        mcp_tools = MCPTool.from_server_tools(conn, server_tools, reconnect_fn)
        self._replace_server_tools(name, mcp_tools)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

async def _safe_close(transport: Any) -> None:
    """Close a transport, ignoring errors."""
    try:
        await transport.close()
    except Exception:
        pass
