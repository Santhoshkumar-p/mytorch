"""
Approved plan persistence.

An ApprovedPlan is created when the user runs ``/plan approve``.  It is
persisted as JSON so the agent can resume from a checkpoint if the session
is restarted.
"""
from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass

_CHECKPOINT_FILENAME = "approved_plan.json"


@dataclass
class ApprovedPlan:
    """
    A plan text that has been explicitly approved by the user.

    ``checkpoint_path`` points to the JSON file on disk, if the plan was
    persisted.
    """

    plan_text: str
    approved_at: float
    checkpoint_path: str | None = None


# ---------------------------------------------------------------------------
# Persistence helpers
# ---------------------------------------------------------------------------


def save_approved_plan(plan: ApprovedPlan, path: str) -> None:
    """
    Write *plan* to *path* as JSON.

    Creates parent directories as needed.
    """
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    data = {
        "plan_text": plan.plan_text,
        "approved_at": plan.approved_at,
        "checkpoint_path": path,
    }
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2)


def load_approved_plan(path: str) -> ApprovedPlan | None:
    """
    Read a previously saved ApprovedPlan from *path*.

    Returns None if the file does not exist or cannot be parsed.
    """
    if not os.path.isfile(path):
        return None
    try:
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
        return ApprovedPlan(
            plan_text=str(data["plan_text"]),
            approved_at=float(data["approved_at"]),
            checkpoint_path=data.get("checkpoint_path"),
        )
    except (OSError, KeyError, ValueError, TypeError):
        return None
