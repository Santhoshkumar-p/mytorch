# Plan Mode Feature

## Plan

Provide a restricted execution mode where the agent is blocked from making
file changes and must instead produce a structured plan.  The user reviews
the plan and explicitly approves it before the agent is allowed to execute.

## Integration Architecture

**Construction:**

```python
state = PlanModeState(
    enabled=settings.plan_mode,
    plan_file_path=settings.plan_file or "PLAN.md",
    workflow=settings.plan_workflow,
)
plan_manager = PlanModeManager(state)
```

**System prompt injection (system_prompt.py):**

```python
if plan_manager.is_enabled():
    system_prompt = plan_manager.get_system_prompt_injection() + "\n\n" + system_prompt
```

**Agent loop — blocking write/edit/bash tools:**

```python
if plan_manager.is_enabled() and tool_name in WRITE_TOOLS:
    return "Plan mode is active. Write your plan to the plan file instead of making changes."
```

**`/plan approve` slash command:**

```python
plan_text = plan_manager.read_current_plan()
approved = plan_manager.approve_plan(plan_text, checkpoint_dir=session.agent_dir)
# Disable plan mode for the rest of the session:
plan_manager._state.enabled = False
```

**On next session (reentry):**

```python
checkpoint = plan_manager.load_checkpoint(session.agent_dir)
if checkpoint:
    # Prepend the approved plan to the opening user message
    initial_prompt = checkpoint.plan_text + "\n\n" + initial_prompt
    plan_manager.clear_checkpoint(session.agent_dir)
```

## What Was Implemented

| File | Purpose |
|------|---------|
| `types.py` | `PlanModeState`, `PlanWorkflow` |
| `approved_plan.py` | `ApprovedPlan` dataclass + `save_approved_plan` / `load_approved_plan` |
| `manager.py` | `PlanModeManager` — is_enabled, read/write plan, approve, checkpoint, system prompt |

## Usage Example

```python
from coding_agent.features.plan_mode import PlanModeManager, PlanModeState

state = PlanModeState(enabled=True, plan_file_path="/tmp/PLAN.md")
manager = PlanModeManager(state)

print(manager.is_enabled())  # True
print(manager.get_system_prompt_injection())

manager.write_plan("# Plan\n1. Do X\n2. Do Y")
plan_text = manager.read_current_plan()

approved = manager.approve_plan(plan_text, checkpoint_dir="/tmp")
print(approved.checkpoint_path)  # /tmp/approved_plan.json

reloaded = manager.load_checkpoint("/tmp")
print(reloaded.plan_text)

manager.clear_checkpoint("/tmp")
```
