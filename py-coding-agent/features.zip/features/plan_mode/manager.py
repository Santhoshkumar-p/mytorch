"""
PlanModeManager — high-level controller for plan mode.

Manages reading/writing the plan file, approving plans, and generating the
system prompt injection that restricts the agent to planning only.
"""
from __future__ import annotations

import os
import time

from .approved_plan import ApprovedPlan, load_approved_plan, save_approved_plan
from .types import PlanModeState

_CHECKPOINT_FILENAME = "approved_plan.json"


class PlanModeManager:
    """
    Encapsulates all plan-mode behaviour for a single agent session.

    Constructed from a :class:`PlanModeState` which is derived from the
    session's settings / CLI flags.
    """

    def __init__(self, state: PlanModeState) -> None:
        self._state = state

    # ------------------------------------------------------------------
    # State queries
    # ------------------------------------------------------------------

    def is_enabled(self) -> bool:
        """Return True if plan mode is active for this session."""
        return self._state.enabled

    def get_plan_file(self) -> str:
        """Return the path to the plan file."""
        return self._state.plan_file_path

    # ------------------------------------------------------------------
    # Plan file I/O
    # ------------------------------------------------------------------

    def read_current_plan(self) -> str | None:
        """
        Read the plan file and return its contents.

        Returns None if the file does not exist or cannot be read.
        """
        path = self._state.plan_file_path
        if not os.path.isfile(path):
            return None
        try:
            with open(path, encoding="utf-8") as fh:
                return fh.read()
        except OSError:
            return None

    def write_plan(self, content: str) -> None:
        """
        Write *content* to the plan file, creating parent directories as needed.
        """
        path = self._state.plan_file_path
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(content)

    # ------------------------------------------------------------------
    # Approval & checkpointing
    # ------------------------------------------------------------------

    def approve_plan(self, plan_text: str, checkpoint_dir: str) -> ApprovedPlan:
        """
        Approve *plan_text* and persist it as a checkpoint in *checkpoint_dir*.

        Returns the ApprovedPlan with ``checkpoint_path`` set.
        """
        checkpoint_path = os.path.join(checkpoint_dir, _CHECKPOINT_FILENAME)
        plan = ApprovedPlan(
            plan_text=plan_text,
            approved_at=time.time(),
            checkpoint_path=checkpoint_path,
        )
        save_approved_plan(plan, checkpoint_path)
        return plan

    def load_checkpoint(self, checkpoint_dir: str) -> ApprovedPlan | None:
        """
        Load a previously approved plan from *checkpoint_dir*.

        Returns None if no checkpoint exists.
        """
        checkpoint_path = os.path.join(checkpoint_dir, _CHECKPOINT_FILENAME)
        return load_approved_plan(checkpoint_path)

    def clear_checkpoint(self, checkpoint_dir: str) -> None:
        """Delete the checkpoint file from *checkpoint_dir* if it exists."""
        checkpoint_path = os.path.join(checkpoint_dir, _CHECKPOINT_FILENAME)
        try:
            os.remove(checkpoint_path)
        except FileNotFoundError:
            pass

    # ------------------------------------------------------------------
    # System prompt
    # ------------------------------------------------------------------

    def get_system_prompt_injection(self) -> str:
        """
        Return a Markdown block to prepend to the system prompt when plan
        mode is active.

        The block instructs the agent to write a plan rather than execute
        changes.
        """
        plan_file = self._state.plan_file_path
        return (
            "<!-- PLAN MODE -->\n"
            "## Plan Mode Active\n\n"
            f"You are in **plan mode**. Do NOT make any file changes. "
            f"Instead, write a detailed plan to `{plan_file}`.\n\n"
            "Your plan must include:\n"
            "1. A summary of the approach.\n"
            "2. Numbered steps with clear descriptions.\n"
            "3. Any risks or open questions.\n\n"
            "When you have finished writing the plan, stop and wait for approval.\n"
            "<!-- END PLAN MODE -->"
        )
