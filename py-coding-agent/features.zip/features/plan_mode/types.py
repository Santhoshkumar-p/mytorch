"""
Plan Mode type definitions.

Describes the configuration state that activates plan mode for an agent
session.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

PlanWorkflow = Literal["parallel", "iterative"]


@dataclass
class PlanModeState:
    """
    Configuration snapshot that describes whether plan mode is active and
    how the agent should behave while it is.
    """

    enabled: bool
    plan_file_path: str
    workflow: PlanWorkflow | None = None
    reentry: bool = False
