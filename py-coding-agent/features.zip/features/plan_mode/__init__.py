"""
Plan Mode feature package.

Provides state management and system-prompt injection for plan mode —
a restricted execution mode where the agent writes a plan instead of
making changes.
"""
from __future__ import annotations

from .approved_plan import ApprovedPlan, load_approved_plan, save_approved_plan
from .manager import PlanModeManager
from .types import PlanModeState, PlanWorkflow

__all__ = [
    "PlanModeState",
    "PlanWorkflow",
    "ApprovedPlan",
    "save_approved_plan",
    "load_approved_plan",
    "PlanModeManager",
]
