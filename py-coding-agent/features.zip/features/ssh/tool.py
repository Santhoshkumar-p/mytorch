"""
SSHTool — agent tool wrapper around the SSH executor.

Registered as ``ssh`` in the tool registry.  Agents call it to execute
commands on remote hosts discovered from ``~/.ssh/config`` or YAML.

Parameters
----------
host : str
    Name of an SSH host (must be in the registry).
command : str
    Shell command to run on the remote host.
cwd : str, optional
    Remote working directory.
timeout : int, optional
    Timeout in seconds (default 60, clamped 1–3600).
"""

from __future__ import annotations

import json
from typing import Any

from .executor import execute_ssh
from .registry import SSHHostRegistry


class SSHTool:
    """
    Agent tool for executing commands on remote SSH hosts.

    Instantiate once per session with a populated :class:`~.registry.SSHHostRegistry`.
    """

    name = "ssh"

    def __init__(self, registry: SSHHostRegistry) -> None:
        self._registry = registry

    @property
    def description(self) -> str:
        host_names = self._registry.host_names
        base = (
            "Execute a shell command on a remote host over SSH. "
            "Returns stdout+stderr combined."
        )
        if host_names:
            return f"{base}\n\nAvailable hosts: {', '.join(host_names)}"
        return base

    async def execute(self, params: dict[str, Any]) -> str:
        host_name = params.get("host", "")
        command = params.get("command", "")
        cwd = params.get("cwd")
        timeout_raw = params.get("timeout", 60)

        if not host_name:
            return json.dumps({"error": "Missing required parameter: host"})
        if not command:
            return json.dumps({"error": "Missing required parameter: command"})

        host = self._registry.get(host_name)
        if host is None:
            available = self._registry.host_names
            return json.dumps({
                "error": f"Unknown SSH host: {host_name!r}",
                "available": available,
            })

        # Clamp timeout: 1–3600 seconds
        timeout = max(1, min(int(timeout_raw or 60), 3600))

        try:
            result = await execute_ssh(
                host,
                command,
                cwd=cwd or None,
                timeout=float(timeout),
            )
        except RuntimeError as exc:
            return json.dumps({"error": str(exc)})

        if result.cancelled:
            return json.dumps({
                "error": f"Command timed out after {timeout}s",
                "partial_output": result.output,
            })

        if result.exit_code is not None and result.exit_code != 0:
            return json.dumps({
                "error": f"Command exited with code {result.exit_code}",
                "output": result.output,
                "truncated": result.truncated,
            })

        return result.output or "(no output)"

    @property
    def schema(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "input_schema": {
                "type": "object",
                "properties": {
                    "host": {
                        "type": "string",
                        "description": "SSH host name (as defined in ~/.ssh/config or ssh-hosts.yaml)",
                    },
                    "command": {
                        "type": "string",
                        "description": "Shell command to execute on the remote host",
                    },
                    "cwd": {
                        "type": "string",
                        "description": "Remote working directory (optional)",
                    },
                    "timeout": {
                        "type": "integer",
                        "description": "Timeout in seconds, 1–3600 (default: 60)",
                        "default": 60,
                    },
                },
                "required": ["host", "command"],
            },
        }
