# SSH — Remote Command Execution

Provides `SSHTool` — an agent tool for running shell commands on remote hosts via the system `ssh` binary.

## Host Discovery

Hosts are discovered from:
1. `~/.ssh/config` — standard OpenSSH config (parsed by `SSHHostRegistry.load_ssh_config()`)
2. `.pi/ssh-hosts.yaml` — optional YAML file (loaded by `SSHHostRegistry.load_yaml()`)
3. Manual registration via `SSHHostRegistry.register(SSHHost(...))`

## Usage

```python
import asyncio
from coding_agent.features.ssh import SSHHostRegistry, SSHTool

registry = SSHHostRegistry()
registry.load_ssh_config()                  # reads ~/.ssh/config
registry.load_yaml(".pi/ssh-hosts.yaml")    # optional YAML overrides

tool = SSHTool(registry)

# Execute a command
result = await tool.execute({
    "host": "myserver",
    "command": "df -h /",
    "timeout": 30,
})
print(result)

# With remote working directory
result = await tool.execute({
    "host": "myserver",
    "command": "ls -la",
    "cwd": "/var/log",
})
```

## YAML Format

```yaml
hosts:
  myserver:
    host: 192.168.1.10
    username: admin
    port: 22
    key_path: ~/.ssh/id_ed25519
    description: Home server

  prod-web:
    host: web.example.com
    username: deploy
    description: Production web server
```

## Tool Schema

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `host` | string | yes | SSH host name from registry |
| `command` | string | yes | Shell command to run remotely |
| `cwd` | string | no | Remote working directory |
| `timeout` | integer | no | Timeout seconds, 1–3600 (default: 60) |

## Requirements

- `ssh` binary must be on `PATH` (OpenSSH client)
- Host must be reachable and your key must be accepted (`BatchMode=yes` — no password prompts)
