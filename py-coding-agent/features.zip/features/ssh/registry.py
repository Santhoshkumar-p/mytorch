"""
SSH host registry.

Discovers hosts from:
1. ``~/.ssh/config`` (standard OpenSSH format)
2. ``.pi/ssh-hosts.yaml`` / any YAML file passed to :meth:`SSHHostRegistry.load_yaml`

Hosts are deduplicated by name (first-seen wins).
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class SSHHost:
    """A discovered SSH host entry."""

    name: str
    """Logical name (config key or YAML key)."""

    host: str
    """Hostname or IP address."""

    username: str | None = None
    """Username override (``User`` directive)."""

    port: int | None = None
    """Port override (``Port`` directive)."""

    key_path: str | None = None
    """Identity file path (``IdentityFile`` directive)."""

    description: str | None = None
    """Optional human-readable description (YAML only)."""

    # ------------------------------------------------------------------
    # SSH command-line helpers
    # ------------------------------------------------------------------

    def build_ssh_args(self) -> list[str]:
        """Return ssh CLI arguments for connecting to this host (no command)."""
        args: list[str] = []
        if self.port is not None:
            args += ["-p", str(self.port)]
        if self.key_path:
            args += ["-i", self.key_path]
        # batch mode: no password prompts
        args += ["-o", "BatchMode=yes", "-o", "StrictHostKeyChecking=accept-new"]
        user_host = f"{self.username}@{self.host}" if self.username else self.host
        args.append(user_host)
        return args


class SSHHostRegistry:
    """
    Discovers and stores SSH host definitions.

    ::

        registry = SSHHostRegistry()
        registry.load_ssh_config()             # ~/.ssh/config
        registry.load_yaml(".pi/ssh-hosts.yaml")

        host = registry.get("myserver")
    """

    def __init__(self) -> None:
        self._hosts: dict[str, SSHHost] = {}

    # ------------------------------------------------------------------
    # Discovery
    # ------------------------------------------------------------------

    def load_ssh_config(self, path: str | None = None) -> int:
        """
        Parse an OpenSSH config file and register ``Host`` entries.

        :param path: Path to the config file.  Defaults to ``~/.ssh/config``.
        :returns:    Number of new hosts added.
        """
        config_path = Path(path or "~/.ssh/config").expanduser()
        if not config_path.exists():
            return 0

        text = config_path.read_text(encoding="utf-8", errors="replace")
        added = 0
        current: dict[str, str] = {}

        def _flush(current: dict[str, str]) -> None:
            nonlocal added
            name = current.get("_name", "")
            # Skip wildcards
            if not name or "*" in name or "?" in name:
                return
            if name in self._hosts:
                return
            self._hosts[name] = SSHHost(
                name=name,
                host=current.get("hostname", name),
                username=current.get("user"),
                port=int(current["port"]) if "port" in current else None,
                key_path=_expand(current.get("identityfile")),
            )
            added += 1

        for raw_line in text.splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            m = re.match(r"^(\w+)\s+(.+)$", line)
            if not m:
                continue
            key, value = m.group(1).lower(), m.group(2).strip()
            if key == "host":
                _flush(current)
                current = {"_name": value}
            else:
                current[key] = value

        _flush(current)
        return added

    def load_yaml(self, path: str) -> int:
        """
        Load hosts from a YAML file.

        Expected format::

            hosts:
              myserver:
                host: 192.168.1.10
                username: admin
                port: 22
                key_path: ~/.ssh/id_ed25519
                description: My home server

        :param path: Path to the YAML file.
        :returns:    Number of new hosts added.
        :raises ImportError: If PyYAML is not installed.
        """
        try:
            import yaml  # type: ignore
        except ImportError as exc:
            raise ImportError(
                "PyYAML is required to load SSH hosts from YAML. "
                "Install it with: pip install pyyaml"
            ) from exc

        with open(path, encoding="utf-8") as fh:
            data = yaml.safe_load(fh)

        added = 0
        for name, cfg in (data or {}).get("hosts", {}).items():
            if name in self._hosts:
                continue
            self._hosts[name] = SSHHost(
                name=name,
                host=cfg.get("host", name),
                username=cfg.get("username") or cfg.get("user"),
                port=cfg.get("port"),
                key_path=_expand(cfg.get("key_path") or cfg.get("identity_file")),
                description=cfg.get("description"),
            )
            added += 1
        return added

    def register(self, host: SSHHost) -> None:
        """Manually add a host (first-seen wins; duplicate names are silently ignored)."""
        if host.name not in self._hosts:
            self._hosts[host.name] = host

    # ------------------------------------------------------------------
    # Lookup
    # ------------------------------------------------------------------

    def get(self, name: str) -> SSHHost | None:
        return self._hosts.get(name)

    def list_hosts(self) -> list[SSHHost]:
        return sorted(self._hosts.values(), key=lambda h: h.name)

    @property
    def host_names(self) -> list[str]:
        return sorted(self._hosts.keys())

    def __len__(self) -> int:
        return len(self._hosts)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _expand(value: str | None) -> str | None:
    if value is None:
        return None
    return str(Path(value).expanduser()) if value.startswith("~") else value
