"""
SSH — remote command execution over SSH.

Discovers hosts from ``~/.ssh/config`` and/or ``.pi/ssh-hosts.yaml``,
then executes commands on them via the system ``ssh`` binary.

Quick start::

    from coding_agent.features.ssh import SSHHostRegistry, SSHTool

    registry = SSHHostRegistry()
    registry.load_ssh_config()          # reads ~/.ssh/config
    registry.load_yaml("ssh-hosts.yaml")  # optional extra hosts

    tool = SSHTool(registry)
    result = await tool.execute({
        "host": "myserver",
        "command": "ls -la /tmp",
        "timeout": 30,
    })
    print(result)
"""

from .registry import SSHHost, SSHHostRegistry
from .executor import SSHResult, execute_ssh
from .tool import SSHTool

__all__ = [
    "SSHHost",
    "SSHHostRegistry",
    "SSHResult",
    "execute_ssh",
    "SSHTool",
]
