"""
SSH command executor.

Runs commands on remote hosts via the system ``ssh`` binary using
``asyncio.create_subprocess_exec``.  Streams stdout+stderr and enforces
a configurable timeout.
"""

from __future__ import annotations

import asyncio
import shutil
import time
from dataclasses import dataclass

from .registry import SSHHost


@dataclass
class SSHResult:
    """Outcome of a remote SSH command execution."""

    host: str
    """Host name the command ran on."""

    command: str
    """Command that was executed (possibly prefixed with ``cd`` for cwd)."""

    output: str
    """Combined stdout + stderr (possibly truncated)."""

    exit_code: int | None
    """Process exit code.  ``None`` if killed by timeout or signal."""

    duration_ms: int
    """Wall-clock time in milliseconds."""

    truncated: bool = False
    """True if output exceeded :attr:`max_bytes`."""

    cancelled: bool = False
    """True if the command was aborted via ``signal``."""


async def execute_ssh(
    host: SSHHost,
    command: str,
    *,
    cwd: str | None = None,
    timeout: float = 60.0,
    max_bytes: int = 512 * 1024,
    signal: asyncio.Event | None = None,
) -> SSHResult:
    """
    Execute *command* on *host* via the system ``ssh`` binary.

    :param host:      SSH host definition from :class:`~.registry.SSHHostRegistry`.
    :param command:   Shell command to run on the remote host.
    :param cwd:       Remote working directory (prepended as ``cd -- ... && command``).
    :param timeout:   Max seconds to wait.  Process is killed on expiry.
    :param max_bytes: Maximum output bytes to keep (older output is discarded).
    :param signal:    If set, the coroutine polls this :class:`asyncio.Event` and
                      aborts when it fires.
    :returns:         :class:`SSHResult`.
    :raises RuntimeError: If the ``ssh`` binary is not found on ``PATH``.
    """
    if shutil.which("ssh") is None:
        raise RuntimeError(
            "ssh binary not found on PATH. Install OpenSSH to use the SSH tool."
        )

    remote_cmd = _build_remote_command(command, cwd, host)
    ssh_args = host.build_ssh_args() + [remote_cmd]

    start = time.monotonic()
    proc = await asyncio.create_subprocess_exec(
        "ssh",
        *ssh_args,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
    )

    chunks: list[bytes] = []
    total_bytes = 0
    truncated = False

    async def _read_output() -> None:
        nonlocal total_bytes, truncated
        assert proc.stdout is not None
        while True:
            chunk = await proc.stdout.read(4096)
            if not chunk:
                break
            total_bytes += len(chunk)
            if total_bytes <= max_bytes:
                chunks.append(chunk)
            else:
                truncated = True

    try:
        await asyncio.wait_for(_read_output(), timeout=timeout)
        await asyncio.wait_for(proc.wait(), timeout=5.0)
        exit_code = proc.returncode
        cancelled = False
    except asyncio.TimeoutError:
        try:
            proc.kill()
        except ProcessLookupError:
            pass
        exit_code = None
        cancelled = True
    finally:
        duration_ms = int((time.monotonic() - start) * 1000)

    raw = b"".join(chunks)
    output = raw.decode("utf-8", errors="replace")

    return SSHResult(
        host=host.name,
        command=remote_cmd,
        output=output,
        exit_code=exit_code,
        duration_ms=duration_ms,
        truncated=truncated,
        cancelled=cancelled,
    )


# ---------------------------------------------------------------------------
# Internal
# ---------------------------------------------------------------------------

def _build_remote_command(command: str, cwd: str | None, host: SSHHost) -> str:
    """Prepend ``cd`` if *cwd* is specified; quote path safely."""
    if not cwd:
        return command
    # POSIX single-quote escaping
    escaped = cwd.replace("'", "'\\''")
    return f"cd -- '{escaped}' && {command}"
