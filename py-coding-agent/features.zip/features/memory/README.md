# Memory Management Feature

## Plan

Provide a pluggable memory backend system that lets the agent persist knowledge
across sessions.  The backend abstraction keeps the agent loop clean — it calls
three integration points and never touches the storage layer directly.

## Integration Architecture

**system_prompt.py** — memory injection:

```python
instructions = await backend.build_developer_instructions(agent_dir)
if instructions:
    system_prompt += "\n\n" + instructions
```

**Agent session init** — start backend:

```python
await backend.start(session_id=session.id, agent_dir=session.agent_dir)
```

**`/memory clear` slash command**:

```python
await backend.clear(agent_dir=session.agent_dir)
```

**End of session** — optional summarisation enqueue:

```python
await backend.enqueue(agent_dir=session.agent_dir)
```

The backend is resolved once at startup via `resolve_memory_backend(settings.memory_backend)` and injected into `AgentSessionServices`.

## What Was Implemented

| File | Purpose |
|------|---------|
| `types.py` | `MemoryBackend` ABC, `MemoryBackendId` literal |
| `local_backend.py` | `LocalMemoryBackend` — stores memory in `{agent_dir}/.memory.md` |
| `off_backend.py` | `OffMemoryBackend` — no-op, no persistence |
| `resolve.py` | `resolve_memory_backend(backend_id)` factory |

## Usage Example

```python
import asyncio
from coding_agent.features.memory import resolve_memory_backend

backend = resolve_memory_backend("local")

async def run():
    await backend.start(session_id="session-1", agent_dir="/tmp/agent-work")

    # Inject into system prompt
    instructions = await backend.build_developer_instructions("/tmp/agent-work")
    if instructions:
        print("Injecting memory into system prompt:")
        print(instructions)

    # Agent writes .memory.md during its run...

    # Clear on demand
    await backend.clear("/tmp/agent-work")

asyncio.run(run())
```
