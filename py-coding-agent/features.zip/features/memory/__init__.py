"""
Memory management feature package.

Provides pluggable memory backends for persisting agent state across sessions
and injecting it into system prompts.
"""
from __future__ import annotations

from .local_backend import LocalMemoryBackend
from .off_backend import OffMemoryBackend
from .resolve import resolve_memory_backend
from .types import MemoryBackend, MemoryBackendId

__all__ = [
    "MemoryBackend",
    "MemoryBackendId",
    "LocalMemoryBackend",
    "OffMemoryBackend",
    "resolve_memory_backend",
]
