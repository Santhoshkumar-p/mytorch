"""
Off memory backend.

A no-op backend used when memory persistence is disabled.  All operations
are silent no-ops and the backend never injects anything into the system
prompt.
"""
from __future__ import annotations

from .types import MemoryBackend, MemoryBackendId


class OffMemoryBackend(MemoryBackend):
    """
    Memory backend that discards all data immediately.

    Use this when the user does not want cross-session memory.
    """

    @property
    def id(self) -> MemoryBackendId:
        return "off"

    async def start(self, session_id: str, agent_dir: str) -> None:
        """No-op."""

    async def build_developer_instructions(self, agent_dir: str) -> str | None:
        """Always returns None — no memory to inject."""
        return None

    async def clear(self, agent_dir: str) -> None:
        """No-op."""

    async def enqueue(self, agent_dir: str) -> None:
        """No-op."""
