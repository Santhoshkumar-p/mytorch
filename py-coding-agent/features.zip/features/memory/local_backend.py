"""
Local filesystem memory backend.

Persists agent memory to a `.memory.md` file inside the agent's working
directory.  The file is plain Markdown so the agent can read and update it
directly using its standard file tools.
"""
from __future__ import annotations

import os
from typing import Literal

from .types import MemoryBackend, MemoryBackendId

_MEMORY_FILENAME = ".memory.md"
_SECTION_HEADER = "## Agent Memory\n\n"
_SECTION_FOOTER = "\n"


class LocalMemoryBackend(MemoryBackend):
    """
    Memory backend that stores data in ``{agent_dir}/.memory.md``.

    The agent can update its memory by writing to this file.  At the start
    of each session the file contents are injected into the system prompt so
    the agent can recall information from previous sessions.
    """

    @property
    def id(self) -> MemoryBackendId:
        return "local"

    # ------------------------------------------------------------------
    # MemoryBackend interface
    # ------------------------------------------------------------------

    async def start(self, session_id: str, agent_dir: str) -> None:
        """Create *agent_dir* if it does not already exist."""
        os.makedirs(agent_dir, exist_ok=True)

    async def build_developer_instructions(self, agent_dir: str) -> str | None:
        """
        Return the contents of ``.memory.md`` wrapped in a section block.

        Returns None if the file does not exist or is empty.
        """
        memory_path = os.path.join(agent_dir, _MEMORY_FILENAME)
        if not os.path.isfile(memory_path):
            return None

        try:
            with open(memory_path, encoding="utf-8") as fh:
                content = fh.read().strip()
        except OSError:
            return None

        if not content:
            return None

        return (
            "<!-- BEGIN AGENT MEMORY -->\n"
            f"{_SECTION_HEADER}"
            f"{content}"
            f"{_SECTION_FOOTER}"
            "<!-- END AGENT MEMORY -->\n"
        )

    async def clear(self, agent_dir: str) -> None:
        """Delete ``.memory.md`` from *agent_dir* if it exists."""
        memory_path = os.path.join(agent_dir, _MEMORY_FILENAME)
        try:
            os.remove(memory_path)
        except FileNotFoundError:
            pass

    async def enqueue(self, agent_dir: str) -> None:
        """No-op — the local backend does not perform background summarisation."""
