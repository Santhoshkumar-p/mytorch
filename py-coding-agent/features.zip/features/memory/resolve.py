"""
Memory backend resolver.

Maps a backend identifier string to the concrete MemoryBackend implementation.
"""
from __future__ import annotations

from .local_backend import LocalMemoryBackend
from .off_backend import OffMemoryBackend
from .types import MemoryBackend


def resolve_memory_backend(backend_id: str) -> MemoryBackend:
    """
    Return a MemoryBackend instance for *backend_id*.

    - ``"local"`` → :class:`LocalMemoryBackend`
    - anything else → :class:`OffMemoryBackend`
    """
    if backend_id == "local":
        return LocalMemoryBackend()
    return OffMemoryBackend()
