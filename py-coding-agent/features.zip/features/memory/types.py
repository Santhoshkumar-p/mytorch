"""
Memory backend type definitions.

Defines the abstract base class that all memory backends must implement,
plus the backend identifier literal.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Literal

MemoryBackendId = Literal["off", "local"]


class MemoryBackend(ABC):
    """
    Abstract base class for memory persistence backends.

    A memory backend is responsible for persisting agent memory across
    sessions and injecting it into the system prompt at the start of each
    session.
    """

    @property
    @abstractmethod
    def id(self) -> MemoryBackendId:
        """Unique identifier for this backend."""

    @abstractmethod
    async def start(self, session_id: str, agent_dir: str) -> None:
        """
        Called once when a new agent session begins.

        Implementations should ensure any required directories or files
        exist and initialise internal state.
        """

    @abstractmethod
    async def build_developer_instructions(self, agent_dir: str) -> str | None:
        """
        Return a string to inject into the system prompt, or None.

        The returned string typically wraps saved memory in a labelled block
        so the agent can read and update it.
        """

    @abstractmethod
    async def clear(self, agent_dir: str) -> None:
        """Delete all stored memory for the given agent directory."""

    @abstractmethod
    async def enqueue(self, agent_dir: str) -> None:
        """
        Schedule any background work the backend needs (e.g. summarisation).

        Backends that do not require background work should implement this
        as a no-op.
        """

    async def before_agent_start_prompt(self, prompt_text: str) -> str | None:
        """
        Optionally transform or annotate the user's opening prompt.

        Default implementation returns None (no transformation).
        Backends may override this to prepend context summaries, etc.
        """
        return None
