"""
AsyncJobManager — schedules and tracks background asyncio coroutines.

Each submitted coroutine becomes a BackgroundJob.  Jobs are keyed by a
monotonically increasing hex ID and can be queried or cancelled at any time.
"""
from __future__ import annotations

import asyncio
import itertools
import time
from collections.abc import Coroutine
from typing import Any

from .types import BackgroundJob, JobState


class AsyncJobManager:
    """
    Manages a pool of background asyncio tasks.

    Jobs are owned by a string ``owner_id`` (typically a session ID) so the
    caller can list or cancel only its own jobs.
    """

    _counter = itertools.count()

    def __init__(self) -> None:
        self._jobs: dict[str, BackgroundJob] = {}

    # ------------------------------------------------------------------
    # Submission
    # ------------------------------------------------------------------

    def submit(
        self,
        description: str,
        coro: Coroutine[Any, Any, Any],
        owner_id: str,
    ) -> BackgroundJob:
        """
        Schedule *coro* as a background asyncio task.

        Returns the BackgroundJob immediately (before the coroutine starts).
        """
        job_id = format(next(self._counter), "x")
        now = time.monotonic()

        job = BackgroundJob(
            id=job_id,
            owner_id=owner_id,
            description=description,
            state="pending",
            created_at=now,
        )
        self._jobs[job_id] = job

        task = asyncio.create_task(coro, name=f"bg-job-{job_id}")
        job.task = task
        job.state = "running"
        job.started_at = time.monotonic()

        task.add_done_callback(lambda t: self._on_task_done(job_id, t))
        return job

    # ------------------------------------------------------------------
    # Lookup
    # ------------------------------------------------------------------

    def get_job(self, job_id: str) -> BackgroundJob | None:
        """Return the job for *job_id*, or None if unknown."""
        return self._jobs.get(job_id)

    def list_jobs(self, owner_id: str | None = None) -> list[BackgroundJob]:
        """
        List jobs, optionally filtered by *owner_id*.

        Returns jobs ordered by creation time (oldest first).
        """
        jobs = list(self._jobs.values())
        if owner_id is not None:
            jobs = [j for j in jobs if j.owner_id == owner_id]
        return sorted(jobs, key=lambda j: j.created_at)

    # ------------------------------------------------------------------
    # Control
    # ------------------------------------------------------------------

    def cancel_job(self, job_id: str) -> bool:
        """
        Cancel a running job.

        Returns True if the task was cancelled, False if the job was not found
        or was already in a terminal state.
        """
        job = self._jobs.get(job_id)
        if job is None or job.task is None or job.task.done():
            return False
        job.task.cancel()
        job.state = "aborted"
        job.completed_at = time.monotonic()
        return True

    async def wait_for_job(
        self,
        job_id: str,
        timeout: float | None = None,
    ) -> BackgroundJob:
        """
        Await the completion of *job_id*.

        Raises ``KeyError`` if the job is not found.
        Raises ``asyncio.TimeoutError`` if *timeout* expires.
        """
        job = self._jobs.get(job_id)
        if job is None:
            raise KeyError(f"Job {job_id!r} not found")
        if job.task is not None and not job.task.done():
            await asyncio.wait_for(asyncio.shield(job.task), timeout=timeout)
        return job

    def cancel_all(self, owner_id: str | None = None) -> int:
        """
        Cancel all running jobs, optionally filtered by *owner_id*.

        Returns the count of jobs actually cancelled.
        """
        count = 0
        for job in list(self._jobs.values()):
            if owner_id is not None and job.owner_id != owner_id:
                continue
            if self.cancel_job(job.id):
                count += 1
        return count

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _on_task_done(self, job_id: str, task: asyncio.Task) -> None:
        """Callback fired by asyncio when the task finishes."""
        job = self._jobs.get(job_id)
        if job is None:
            return

        job.completed_at = time.monotonic()

        if task.cancelled():
            job.state = "aborted"
            return

        exc = task.exception()
        if exc is not None:
            job.state = "failed"
            job.error = str(exc)
        else:
            job.state = "completed"
            job.result = task.result()
