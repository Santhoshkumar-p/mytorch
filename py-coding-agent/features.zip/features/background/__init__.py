"""
Background execution feature package.

Provides an asyncio-based job manager for running coroutines in the background
and querying their state or results from the agent loop.
"""
from __future__ import annotations

from .manager import AsyncJobManager
from .types import BackgroundJob, JobState

__all__ = [
    "AsyncJobManager",
    "BackgroundJob",
    "JobState",
]
