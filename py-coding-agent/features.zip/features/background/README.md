# Background Execution Feature

## Plan

Provide a lightweight asyncio-native job manager so the agent can fire
long-running coroutines in the background, check their status later, and
retrieve results — without blocking the main agent loop.

## Integration Architecture

`AsyncJobManager` lives on `AgentSessionServices`.

**Submitting background work (tool call handler):**

```python
job = services.job_manager.submit(
    description="run linter on changed files",
    coro=run_linter(files),
    owner_id=session.id,
)
return f"Background job started: {job.id}"
```

**Delivering results via EventBus:**

When the coroutine finishes, `_on_task_done` updates the job state.  A watcher
coroutine (or the next tool call) can poll `job_manager.get_job(id)` and fire
an EventBus notification when the state transitions to `"completed"` or
`"failed"`.

**`/jobs` slash command:**

```python
jobs = services.job_manager.list_jobs(owner_id=session.id)
for job in jobs:
    print(f"{job.id}: {job.state} — {job.description}")
```

## What Was Implemented

| File | Purpose |
|------|---------|
| `types.py` | `JobState` literal, `BackgroundJob` dataclass |
| `manager.py` | `AsyncJobManager` — submit / get / list / cancel / wait / cancel_all |

## Usage Example

```python
import asyncio
from coding_agent.features.background import AsyncJobManager

manager = AsyncJobManager()

async def slow_task():
    await asyncio.sleep(2)
    return "done"

async def main():
    job = manager.submit("slow task", slow_task(), owner_id="session-1")
    print(job.state)  # "running"

    finished = await manager.wait_for_job(job.id, timeout=5.0)
    print(finished.state)   # "completed"
    print(finished.result)  # "done"

    print(manager.list_jobs(owner_id="session-1"))

asyncio.run(main())
```
