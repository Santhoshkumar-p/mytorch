"""
Background execution type definitions.

Defines the job state machine and the BackgroundJob data container.
"""
from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import Any, Literal

JobState = Literal["pending", "running", "completed", "failed", "aborted"]


@dataclass
class BackgroundJob:
    """
    Represents a single background coroutine tracked by AsyncJobManager.

    The ``task`` field holds the live asyncio.Task while the job is running.
    It is excluded from repr to avoid noise in logs.
    """

    id: str
    owner_id: str
    description: str
    state: JobState
    created_at: float
    started_at: float | None = None
    completed_at: float | None = None
    result: Any | None = None
    error: str | None = None
    task: asyncio.Task | None = field(default=None, repr=False)
