"""
Extension API — the object passed to extension factory functions.

ExtensionAPI and HookAPI provide the registration surface for extensions.
Registration methods write to the Extension object the API was created for.
"""
from __future__ import annotations

import asyncio
import subprocess
from typing import Any, Callable

from .types import Extension, RegisteredCommand, ToolDefinition


class HookAPI:
    """
    API object given to hook/extension factories.

    Handles event subscription, messaging primitives, and command registration.
    Action methods (send_message, append_entry, exec) delegate to the runtime.
    """

    def __init__(self, extension: Extension, cwd: str) -> None:
        self._extension = extension
        self._cwd = cwd

    # ------------------------------------------------------------------
    # Event subscription
    # ------------------------------------------------------------------

    def on(self, event: str, handler: Callable) -> None:
        """Subscribe *handler* to *event*.  Multiple handlers per event allowed."""
        self._extension.handlers.setdefault(event, []).append(handler)

    # ------------------------------------------------------------------
    # Messaging primitives
    # ------------------------------------------------------------------

    def send_message(self, message: dict, options: dict | None = None) -> None:
        """Inject a custom message into the session (runtime-delegated at init time)."""
        # Replaced by the runner after loading; no-op during setup phase.

    def append_entry(self, custom_type: str, data: Any = None) -> None:
        """Append a custom entry to the session for state persistence."""

    def register_message_renderer(self, custom_type: str, renderer: Callable) -> None:
        """Register a custom TUI renderer for a given message customType."""
        # Stored for use by UI layer; no persistent dict needed at this level.

    # ------------------------------------------------------------------
    # Command registration
    # ------------------------------------------------------------------

    def register_command(
        self,
        name: str,
        *,
        description: str = "",
        handler: Callable,
    ) -> None:
        """Register a slash command available to the user."""
        self._extension.commands[name] = RegisteredCommand(
            name=name,
            description=description,
            handler=handler,
        )

    # ------------------------------------------------------------------
    # Shell execution
    # ------------------------------------------------------------------

    def exec(
        self,
        command: str,
        args: list[str],
        **opts: Any,
    ) -> subprocess.CompletedProcess:
        """
        Execute a shell command synchronously and return the completed process.

        Keyword arguments are forwarded to subprocess.run.
        """
        cwd = opts.pop("cwd", self._cwd)
        return subprocess.run(
            [command, *args],
            cwd=cwd,
            capture_output=True,
            text=True,
            **opts,
        )


class ExtensionAPI(HookAPI):
    """
    Full extension API — superset of HookAPI.

    Adds tool registration, shortcut/flag management, and active-tools control.
    """

    def __init__(
        self,
        extension: Extension,
        cwd: str,
        *,
        get_active_tools: Callable[[], list[str]] | None = None,
        set_active_tools: Callable[[list[str]], None] | None = None,
    ) -> None:
        super().__init__(extension, cwd)
        self._flag_values: dict[str, bool | str | None] = {}
        self._get_active_tools = get_active_tools or (lambda: [])
        self._set_active_tools = set_active_tools or (lambda _: None)

    # ------------------------------------------------------------------
    # Tool registration
    # ------------------------------------------------------------------

    def register_tool(self, tool: ToolDefinition) -> None:
        """Register a tool that the LLM can call."""
        self._extension.tools[tool.name] = tool

    # ------------------------------------------------------------------
    # Shortcuts & flags
    # ------------------------------------------------------------------

    def register_shortcut(
        self,
        shortcut: str,
        *,
        description: str = "",
        handler: Callable,
    ) -> None:
        """Register a keyboard shortcut (TUI mode only)."""
        # Stored for future TUI integration; no-op in headless mode.

    def register_flag(
        self,
        name: str,
        *,
        type: str = "boolean",
        description: str = "",
        default: bool | str | None = None,
    ) -> None:
        """Register a CLI flag that can be read with get_flag()."""
        if default is not None:
            self._flag_values[name] = default

    def get_flag(self, name: str) -> bool | str | None:
        """Return the current value of a registered flag."""
        return self._flag_values.get(name)

    # ------------------------------------------------------------------
    # Active tools
    # ------------------------------------------------------------------

    def get_active_tools(self) -> list[str]:
        """Return the names of tools currently active in the session."""
        return self._get_active_tools()

    def set_active_tools(self, tool_names: list[str]) -> None:
        """Replace the active tool set for the session."""
        self._set_active_tools(tool_names)
