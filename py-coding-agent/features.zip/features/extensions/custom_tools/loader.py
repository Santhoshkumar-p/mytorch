"""
Custom tool loader.

Discovers ``.tools.json`` / ``tools.json`` files by walking *cwd* upward,
parses them, and provides a factory that wraps each tool config as a
:class:`~coding_agent.features.extensions.types.ToolDefinition`.
"""
from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path

from ..types import ToolDefinition
from .types import CustomToolConfig, CustomToolsFile

logger = logging.getLogger(__name__)

_FILENAMES = (".tools.json", "tools.json")


# ---------------------------------------------------------------------------
# File parsing
# ---------------------------------------------------------------------------


def _load_file(path: Path) -> list[CustomToolConfig]:
    """Parse a single tools JSON file."""
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed to read custom tools config %s: %s", path, exc)
        return []

    if isinstance(raw, list):
        entries = raw
    elif isinstance(raw, dict):
        entries = raw.get("tools", [])
    else:
        logger.warning("Unexpected custom tools format in %s", path)
        return []

    configs: list[CustomToolConfig] = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        name = entry.get("name", "")
        command = entry.get("command", "")
        if not name or not command:
            continue
        configs.append(
            CustomToolConfig(
                name=name,
                description=entry.get("description", ""),
                command=command,
                schema=entry.get("schema", {}),
                timeout_ms=int(entry.get("timeout_ms", 30_000)),
            )
        )
    return configs


# ---------------------------------------------------------------------------
# Discovery
# ---------------------------------------------------------------------------


def load_custom_tools(cwd: str) -> list[CustomToolConfig]:
    """
    Walk *cwd* upward and collect all custom tool configurations found.

    All discovered files are merged; duplicates (same ``name``) from closer
    directories shadow those from parent directories.
    """
    seen_names: set[str] = set()
    result: list[CustomToolConfig] = []
    current = Path(cwd).resolve()

    while True:
        for filename in _FILENAMES:
            candidate = current / filename
            if candidate.is_file():
                for cfg in _load_file(candidate):
                    if cfg.name not in seen_names:
                        seen_names.add(cfg.name)
                        result.append(cfg)
        parent = current.parent
        if parent == current:
            break
        current = parent

    return result


# ---------------------------------------------------------------------------
# Wrapping as ToolDefinition
# ---------------------------------------------------------------------------


def custom_tool_to_tool_definition(config: CustomToolConfig) -> ToolDefinition:
    """
    Wrap a :class:`CustomToolConfig` as a :class:`ToolDefinition`.

    The generated ``execute`` callable runs the configured shell command via
    ``asyncio.create_subprocess_shell``, passing the serialised *params* dict
    as JSON on stdin.  stdout is returned as the tool result text.
    """
    import asyncio as _asyncio
    import json as _json

    timeout_s = config.timeout_ms / 1000.0
    command = config.command

    async def _execute(params: dict) -> str:
        payload = _json.dumps(params).encode()
        proc = await _asyncio.create_subprocess_shell(
            command,
            stdin=_asyncio.subprocess.PIPE,
            stdout=_asyncio.subprocess.PIPE,
            stderr=_asyncio.subprocess.PIPE,
        )
        try:
            raw_out, raw_err = await _asyncio.wait_for(
                proc.communicate(payload), timeout=timeout_s
            )
        except _asyncio.TimeoutError:
            proc.kill()
            await proc.communicate()
            return f"[Tool timed out after {config.timeout_ms}ms]"

        if proc.returncode != 0:
            stderr = raw_err.decode(errors="replace").strip()
            return f"[Tool error (exit {proc.returncode})]: {stderr}"

        return raw_out.decode(errors="replace")

    return ToolDefinition(
        name=config.name,
        description=config.description,
        parameters=config.schema,
        execute=_execute,
    )
