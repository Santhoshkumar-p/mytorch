"""
Custom tool configuration types.

Custom tools are defined in ``.tools.json`` / ``tools.json`` files and
describe shell commands that the LLM can invoke as tools.
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class CustomToolConfig:
    """Configuration for a single file-based custom tool."""

    name: str
    description: str
    command: str  # Shell command to run when the tool is invoked
    schema: dict = field(default_factory=dict)  # JSON Schema for parameters
    timeout_ms: int = 30_000


@dataclass
class CustomToolsFile:
    """Contents of a parsed ``.tools.json`` / ``tools.json`` file."""

    tools: list[CustomToolConfig] = field(default_factory=list)
