"""
Extension runner — fires lifecycle events and aggregates tool/command registrations.

``ExtensionRunner`` is the single point through which the agent session
interacts with all loaded extensions.  It iterates over every
:class:`~coding_agent.features.extensions.types.Extension`, invokes their
registered handlers for the given event type, and collects results.
"""
from __future__ import annotations

import asyncio
import inspect
import logging
from typing import Any, Callable

from .types import (
    ConcreteHookContext,
    Extension,
    HookContext,
    RegisteredCommand,
    ToolCallEvent,
    ToolCallEventResult,
    ToolDefinition,
    ToolResultEvent,
    ToolResultEventResult,
)

logger = logging.getLogger(__name__)


class ExtensionRunner:
    """
    Executes registered extension handlers and aggregates tool/command lists.

    Parameters
    ----------
    extensions:
        All successfully loaded extensions.
    context_factory:
        Zero-argument callable that returns a fresh :class:`HookContext` for
        each event dispatch.
    """

    def __init__(
        self,
        extensions: list[Extension],
        context_factory: Callable[[], HookContext] | None = None,
    ) -> None:
        self._extensions = extensions
        self._context_factory = context_factory or self._default_context

    # ------------------------------------------------------------------
    # Default context
    # ------------------------------------------------------------------

    @staticmethod
    def _default_context() -> ConcreteHookContext:
        return ConcreteHookContext(cwd=".", has_ui=False)

    # ------------------------------------------------------------------
    # Generic fire
    # ------------------------------------------------------------------

    async def fire(self, event_type: str, event: Any) -> list[Any]:
        """
        Call every handler registered for *event_type* across all extensions.

        Per-handler exceptions are swallowed and logged; they never abort the
        loop.  Returns the list of non-``None`` results from all handlers.
        """
        ctx = self._context_factory()
        results: list[Any] = []

        for ext in self._extensions:
            handlers = ext.handlers.get(event_type, [])
            for handler in handlers:
                try:
                    result = handler(event, ctx)
                    if inspect.isawaitable(result):
                        result = await result
                    if result is not None:
                        results.append(result)
                except Exception:  # noqa: BLE001
                    logger.exception(
                        "Extension handler error [ext=%s event=%s]",
                        ext.path,
                        event_type,
                    )

        return results

    # ------------------------------------------------------------------
    # Typed fire helpers
    # ------------------------------------------------------------------

    async def fire_tool_call(
        self, event: ToolCallEvent
    ) -> ToolCallEventResult | None:
        """
        Fire ``tool_call`` handlers.

        If any handler returns a result with ``block=True`` the result is
        returned immediately (short-circuit).  Otherwise the last non-``None``
        result wins.
        """
        ctx = self._context_factory()
        final: ToolCallEventResult | None = None

        for ext in self._extensions:
            handlers = ext.handlers.get("tool_call", [])
            for handler in handlers:
                try:
                    result = handler(event, ctx)
                    if inspect.isawaitable(result):
                        result = await result
                    if result is not None:
                        assert isinstance(result, ToolCallEventResult)  # noqa: S101
                        if result.block:
                            return result
                        final = result
                except Exception:  # noqa: BLE001
                    logger.exception(
                        "tool_call handler error [ext=%s tool=%s]",
                        ext.path,
                        event.tool_name,
                    )
                    return ToolCallEventResult(
                        block=True,
                        reason=f"Extension {ext.path} tool_call handler failed",
                    )

        return final

    async def fire_tool_result(
        self, event: ToolResultEvent
    ) -> ToolResultEventResult | None:
        """
        Fire ``tool_result`` handlers.

        Handlers may modify ``content`` and ``is_error`` incrementally;
        changes accumulate across all handlers.
        """
        ctx = self._context_factory()
        current = ToolResultEvent(
            tool_call_id=event.tool_call_id,
            tool_name=event.tool_name,
            input=event.input,
            content=list(event.content),
            is_error=event.is_error,
        )
        modified = False

        for ext in self._extensions:
            handlers = ext.handlers.get("tool_result", [])
            for handler in handlers:
                try:
                    result = handler(current, ctx)
                    if inspect.isawaitable(result):
                        result = await result
                    if result is not None:
                        assert isinstance(result, ToolResultEventResult)  # noqa: S101
                        if result.content is not None:
                            current.content = result.content
                            modified = True
                        if result.is_error is not None:
                            current.is_error = result.is_error
                            modified = True
                except Exception:  # noqa: BLE001
                    logger.exception(
                        "tool_result handler error [ext=%s tool=%s]",
                        ext.path,
                        event.tool_name,
                    )

        if not modified:
            return None
        return ToolResultEventResult(
            content=current.content,
            is_error=current.is_error,
        )

    # ------------------------------------------------------------------
    # Registration accessors
    # ------------------------------------------------------------------

    def get_tools(self) -> list[ToolDefinition]:
        """Return all tools registered across every loaded extension."""
        tools: list[ToolDefinition] = []
        seen: set[str] = set()
        for ext in self._extensions:
            for name, tool in ext.tools.items():
                if name not in seen:
                    seen.add(name)
                    tools.append(tool)
        return tools

    def get_commands(self) -> list[RegisteredCommand]:
        """Return all commands registered across every loaded extension."""
        commands: list[RegisteredCommand] = []
        seen: set[str] = set()
        for ext in self._extensions:
            for name, cmd in ext.commands.items():
                if name not in seen:
                    seen.add(name)
                    commands.append(cmd)
        return commands
