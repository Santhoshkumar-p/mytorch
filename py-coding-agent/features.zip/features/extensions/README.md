# Extension System

Python port of the TypeScript extensibility system from
`packages/oh-my-pi/packages/coding-agent/src/extensibility/`.

---

## Plan

We set out to build a **self-contained, liftable** extension module that allows
external Python files (and JSON configs) to:

- Subscribe to agent lifecycle events (session start/end, tool calls, turns, …)
- Register LLM-callable tools at runtime
- Register user-facing slash commands
- Block or modify tool calls and results via hook handlers
- Configure shell-level pre/post hooks via `.hooks.json`
- Define extra tools and commands via `.tools.json` / `.commands.json`

The design mirrors the TypeScript original but uses Python idioms:
`dataclass` instead of TypeScript interfaces, `asyncio` for async work,
and `importlib` instead of native Bun imports.

---

## Integration Architecture

Wire the extension system into `agent_session_services.py` (or wherever the
agent session is assembled):

### 1 — Add `extension_runner` to the session services dataclass

```python
from coding_agent.features.extensions import ExtensionLoader, ExtensionRunner

@dataclass
class AgentSessionServices:
    ...
    extension_runner: ExtensionRunner | None = None
```

### 2 — Load extensions at session startup

```python
loader = ExtensionLoader(
    extensions_dirs=settings.extension_dirs,   # list[str] from config
    cwd=cwd,
)
result = loader.load_all()
for err in result.errors:
    logger.warning("Extension load error: %s — %s", err["path"], err["error"])

runner = ExtensionRunner(
    extensions=result.extensions,
    context_factory=lambda: build_hook_context(session),
)
services.extension_runner = runner
```

### 3 — Fire `before_agent_start` before the loop

```python
from coding_agent.features.extensions.types import BeforeAgentStartEvent

if services.extension_runner:
    await services.extension_runner.fire(
        "before_agent_start",
        BeforeAgentStartEvent(prompt=user_prompt),
    )
```

### 4 — Fire `tool_call` / `tool_result` in the tool registry

In the tool registry's pre-execution hook:

```python
from coding_agent.features.extensions.types import ToolCallEvent

if runner:
    result = await runner.fire_tool_call(
        ToolCallEvent(
            tool_name=tool_name,
            tool_call_id=call_id,
            input=params,
        )
    )
    if result and result.block:
        raise ToolBlockedError(result.reason)
```

In the post-execution hook:

```python
from coding_agent.features.extensions.types import ToolResultEvent

if runner:
    modified = await runner.fire_tool_result(
        ToolResultEvent(
            tool_call_id=call_id,
            tool_name=tool_name,
            input=params,
            content=tool_output_content,
            is_error=is_error,
        )
    )
    if modified and modified.content is not None:
        tool_output_content = modified.content
```

### 5 — Shell hooks (optional)

```python
from coding_agent.features.extensions.hooks.loader import load_hooks_config
from coding_agent.features.extensions.hooks.runner import ShellHookRunner

hooks_cfg = load_hooks_config(cwd)
shell_runner = ShellHookRunner(hooks_cfg)

# Before tool execution:
hook_result = await shell_runner.run_pre_tool(tool_name, params)
if hook_result.blocked:
    raise ToolBlockedError("Blocked by shell hook")

# After tool execution:
hook_result = await shell_runner.run_post_tool(tool_name, tool_output_str)
if hook_result.replacement_content:
    tool_output_str = hook_result.replacement_content
```

---

## What was implemented

- `types.py` — core dataclasses: `ToolDefinition`, `RegisteredCommand`,
  `Extension`, `ConcreteHookContext`, and all event dataclasses
  (`ToolCallEvent`, `ToolResultEvent`, `BeforeAgentStartEvent`,
  `SessionStartEvent`, `AgentStartEvent`, `AgentEndEvent`,
  `TurnStartEvent`, `TurnEndEvent`) plus `ToolCallEventResult` /
  `ToolResultEventResult`.

- `api.py` — `HookAPI` (event subscription, messaging, command registration,
  exec) and `ExtensionAPI` (adds tool registration, flag and shortcut
  management, active-tools control).

- `loader.py` — `ExtensionLoader` (discovers `*.py` files in configured
  directories, imports each with `importlib`, calls `setup(pi)` /
  `default(pi)`) and `load_extension_file` (single-file helper).

- `runner.py` — `ExtensionRunner` (fires events to all handlers, with
  per-handler error isolation; `fire_tool_call` short-circuits on block,
  `fire_tool_result` accumulates mutations; `get_tools` and `get_commands`
  aggregate registrations across all extensions).

- `hooks/__init__.py` — package marker.

- `hooks/types.py` — `HookConfig`, `HookResult`, `HooksConfig`.

- `hooks/runner.py` — `ShellHookRunner` (`run_pre_tool` / `run_post_tool`
  using `asyncio.create_subprocess_shell` with timeout enforcement and
  JSON stdin/stdout protocol).

- `hooks/loader.py` — `load_hooks_config` (walks cwd upward, merges all
  `.hooks.json` / `hooks.json` files).

- `custom_tools/__init__.py` — package marker.

- `custom_tools/types.py` — `CustomToolConfig`, `CustomToolsFile`.

- `custom_tools/loader.py` — `load_custom_tools` (walks cwd upward, merges
  `.tools.json` / `tools.json`) and `custom_tool_to_tool_definition` (wraps
  a shell command as a `ToolDefinition` with async subprocess execution).

- `custom_commands/__init__.py` — package marker.

- `custom_commands/types.py` — `CustomCommandConfig`.

- `custom_commands/loader.py` — `load_custom_commands` (walks cwd upward,
  merges `.commands.json` / `commands.json`).

---

## Usage example — writing a simple extension

Create a file, e.g. `.pi/extensions/bash_logger.py`:

```python
"""Log every bash tool call to stderr."""
from __future__ import annotations

import sys
from coding_agent.features.extensions.api import ExtensionAPI
from coding_agent.features.extensions.types import ToolCallEvent, HookContext


def setup(pi: ExtensionAPI) -> None:
    @pi.on("tool_call")
    def on_tool_call(event: ToolCallEvent, ctx: HookContext) -> None:
        if event.tool_name == "bash":
            cmd = event.input.get("command", "")
            print(f"[bash_logger] {cmd!r}", file=sys.stderr)
```

Then wire it in:

```python
from coding_agent.features.extensions import ExtensionLoader, ExtensionRunner

loader = ExtensionLoader(extensions_dirs=[".pi/extensions"], cwd=".")
result = loader.load_all()
runner = ExtensionRunner(extensions=result.extensions)

# In the tool pre-execution hook:
await runner.fire_tool_call(ToolCallEvent(
    tool_name="bash",
    tool_call_id="abc123",
    input={"command": "ls -la"},
))
```

Every bash call will now be logged to stderr by the extension.
