"""
Shell-hook types.

Shell hooks are external processes configured via ``.hooks.json`` / ``hooks.json``
that are invoked before or after tool calls and at agent lifecycle boundaries.
They are separate from the Python extension event system.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

HookEventLiteral = Literal[
    "pre_tool_call",
    "post_tool_result",
    "pre_agent_start",
    "post_agent_end",
]


@dataclass
class HookConfig:
    """Configuration for a single shell hook."""

    command: str
    event: HookEventLiteral
    timeout_ms: int = 30_000


@dataclass
class HooksConfig:
    """Aggregated shell-hook configuration (merged from all discovered files)."""

    hooks: list[HookConfig] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Runtime result
# ---------------------------------------------------------------------------


@dataclass
class HookResult:
    """Result of running a shell hook process."""

    stdout: str = ""
    stderr: str = ""
    exit_code: int = 0
    blocked: bool = False
    replacement_content: str | None = None
