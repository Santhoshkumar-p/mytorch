"""
Shell hook runner.

Runs matching ``HookConfig`` entries as subprocesses via
``asyncio.create_subprocess_shell``, passes event data as JSON over stdin,
and interprets stdout to detect blocking or content replacement.
"""
from __future__ import annotations

import asyncio
import json
import logging

from .types import HookConfig, HookResult, HooksConfig

logger = logging.getLogger(__name__)

_BLOCK_PREFIX = "BLOCK:"


async def _run_hook(
    config: HookConfig, stdin_payload: str
) -> HookResult:
    """
    Spawn a single hook subprocess and return its result.

    The event data is delivered as a JSON string on stdin.
    stdout / stderr are captured.  If the process exceeds *timeout_ms* it is
    killed and the result is treated as non-blocking with empty output.
    """
    timeout_s = config.timeout_ms / 1000.0
    try:
        proc = await asyncio.create_subprocess_shell(
            config.command,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        encoded = stdin_payload.encode()
        try:
            raw_out, raw_err = await asyncio.wait_for(
                proc.communicate(encoded), timeout=timeout_s
            )
        except asyncio.TimeoutError:
            proc.kill()
            await proc.communicate()
            logger.warning(
                "Shell hook timed out after %sms: %s", config.timeout_ms, config.command
            )
            return HookResult(exit_code=-1)

        stdout = raw_out.decode(errors="replace")
        stderr = raw_err.decode(errors="replace")
        exit_code = proc.returncode or 0
        return HookResult(stdout=stdout, stderr=stderr, exit_code=exit_code)
    except Exception as exc:  # noqa: BLE001
        logger.exception("Shell hook error [cmd=%s]: %s", config.command, exc)
        return HookResult(exit_code=1, stderr=str(exc))


class ShellHookRunner:
    """
    Runs shell hooks for agent lifecycle events.

    Parameters
    ----------
    config:
        Aggregated hook configuration loaded from disk.
    """

    def __init__(self, config: HooksConfig) -> None:
        self._config = config

    # ------------------------------------------------------------------
    # Pre-tool
    # ------------------------------------------------------------------

    async def run_pre_tool(self, tool_name: str, input: dict) -> HookResult:
        """
        Run all ``pre_tool_call`` hooks for *tool_name*.

        The hook receives the event as JSON on stdin::

            {"event": "pre_tool_call", "tool_name": "...", "input": {...}}

        Blocking semantics:

        - Exit code != 0 → blocked, reason taken from stderr or stdout.
        - stdout starts with ``"BLOCK:"`` → blocked, reason is the remainder
          of the first line.
        """
        payload = json.dumps(
            {"event": "pre_tool_call", "tool_name": tool_name, "input": input}
        )
        combined = HookResult()

        for hook in self._matching("pre_tool_call"):
            result = await _run_hook(hook, payload)
            combined.stdout += result.stdout
            combined.stderr += result.stderr
            combined.exit_code = result.exit_code

            if result.exit_code != 0:
                combined.blocked = True
                break

            if result.stdout.startswith(_BLOCK_PREFIX):
                combined.blocked = True
                break

        return combined

    # ------------------------------------------------------------------
    # Post-tool
    # ------------------------------------------------------------------

    async def run_post_tool(self, tool_name: str, result: str) -> HookResult:
        """
        Run all ``post_tool_result`` hooks for *tool_name*.

        The hook receives::

            {"event": "post_tool_result", "tool_name": "...", "result": "..."}

        If the hook writes non-empty stdout it is used as
        ``replacement_content`` for the tool result.
        """
        payload = json.dumps(
            {"event": "post_tool_result", "tool_name": tool_name, "result": result}
        )
        combined = HookResult()

        for hook in self._matching("post_tool_result"):
            r = await _run_hook(hook, payload)
            combined.stdout += r.stdout
            combined.stderr += r.stderr
            combined.exit_code = r.exit_code

        if combined.stdout.strip():
            combined.replacement_content = combined.stdout.strip()

        return combined

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _matching(self, event: str) -> list[HookConfig]:
        return [h for h in self._config.hooks if h.event == event]
