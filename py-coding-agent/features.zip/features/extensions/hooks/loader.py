"""
Shell hook configuration loader.

Searches *cwd* and its parent directories for ``.hooks.json`` or
``hooks.json``, parses each file, and merges all found entries into a single
:class:`~coding_agent.features.extensions.hooks.types.HooksConfig`.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path

from .types import HookConfig, HooksConfig

logger = logging.getLogger(__name__)

_FILENAMES = (".hooks.json", "hooks.json")


def _load_file(path: Path) -> list[HookConfig]:
    """Parse a single hooks JSON file and return the list of HookConfig."""
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed to read hooks config %s: %s", path, exc)
        return []

    # Accept either a bare list or {"hooks": [...]}
    if isinstance(raw, list):
        entries = raw
    elif isinstance(raw, dict):
        entries = raw.get("hooks", [])
    else:
        logger.warning("Unexpected hooks config format in %s", path)
        return []

    configs: list[HookConfig] = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        command = entry.get("command", "")
        event = entry.get("event", "")
        if not command or not event:
            continue
        configs.append(
            HookConfig(
                command=command,
                event=event,  # type: ignore[arg-type]
                timeout_ms=int(entry.get("timeout_ms", 30_000)),
            )
        )
    return configs


def load_hooks_config(cwd: str) -> HooksConfig:
    """
    Walk *cwd* upward and merge every hooks config file found.

    Files closer to *cwd* take lower precedence (they are appended last,
    but all are included).  Duplicate entries are preserved — the shell hook
    runner runs every matching hook.
    """
    all_hooks: list[HookConfig] = []
    current = Path(cwd).resolve()

    while True:
        for name in _FILENAMES:
            candidate = current / name
            if candidate.is_file():
                all_hooks.extend(_load_file(candidate))
        parent = current.parent
        if parent == current:
            break
        current = parent

    return HooksConfig(hooks=all_hooks)
