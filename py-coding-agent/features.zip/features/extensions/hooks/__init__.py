"""
Shell-hook sub-package.

Shell hooks are external processes (scripts) triggered by agent lifecycle
events — distinct from the Python extension event system.
"""
from __future__ import annotations
