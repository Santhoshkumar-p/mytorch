"""
Extension system types.

Extensions are Python modules that can:
- Subscribe to agent lifecycle events
- Register LLM-callable tools
- Register commands and CLI flags
- Interact with the user via UI primitives
"""
from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import Any, Callable, Literal, Protocol, Union


# ---------------------------------------------------------------------------
# Tool + Command definitions
# ---------------------------------------------------------------------------


@dataclass
class ToolDefinition:
    """A tool that extensions can register for the LLM to call."""

    name: str
    description: str
    parameters: dict  # JSON Schema object
    execute: Callable[..., Any]
    hidden: bool = False


@dataclass
class RegisteredCommand:
    """A slash command registered by an extension."""

    name: str
    description: str = ""
    handler: Callable[..., Any] = field(default=lambda *_: None)


# ---------------------------------------------------------------------------
# Extension container
# ---------------------------------------------------------------------------


@dataclass
class Extension:
    """Holds all registrations made by a single extension module."""

    path: str
    label: str = ""
    handlers: dict[str, list[Callable]] = field(default_factory=dict)
    tools: dict[str, ToolDefinition] = field(default_factory=dict)
    commands: dict[str, RegisteredCommand] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Contexts
# ---------------------------------------------------------------------------


class ExtensionContext(Protocol):
    """Context passed to extension event handlers."""

    cwd: str
    has_ui: bool

    def is_idle(self) -> bool: ...
    def abort(self) -> None: ...


class HookContext(Protocol):
    """Narrower context for hook handlers."""

    cwd: str
    has_ui: bool

    def is_idle(self) -> bool: ...
    def abort(self) -> None: ...


@dataclass
class ConcreteHookContext:
    """Concrete implementation of HookContext."""

    cwd: str
    has_ui: bool
    _is_idle: Callable[[], bool] = field(default=lambda: True)
    _abort: Callable[[], None] = field(default=lambda: None)

    def is_idle(self) -> bool:
        return self._is_idle()

    def abort(self) -> None:
        self._abort()


# ---------------------------------------------------------------------------
# Events
# ---------------------------------------------------------------------------

HookEventType = Literal[
    "session_start",
    "tool_call",
    "tool_result",
    "before_agent_start",
    "agent_start",
    "agent_end",
    "turn_start",
    "turn_end",
]


@dataclass
class SessionStartEvent:
    type: Literal["session_start"] = "session_start"
    reason: str = "start"


@dataclass
class ToolCallEvent:
    tool_name: str
    tool_call_id: str
    input: dict
    type: Literal["tool_call"] = "tool_call"


@dataclass
class ToolResultEvent:
    tool_call_id: str
    tool_name: str
    input: dict
    content: list
    is_error: bool = False
    type: Literal["tool_result"] = "tool_result"


@dataclass
class BeforeAgentStartEvent:
    prompt: str
    type: Literal["before_agent_start"] = "before_agent_start"


@dataclass
class AgentStartEvent:
    type: Literal["agent_start"] = "agent_start"


@dataclass
class AgentEndEvent:
    type: Literal["agent_end"] = "agent_end"


@dataclass
class TurnStartEvent:
    type: Literal["turn_start"] = "turn_start"


@dataclass
class TurnEndEvent:
    type: Literal["turn_end"] = "turn_end"


# Union of all hook events
HookEvent = Union[
    SessionStartEvent,
    ToolCallEvent,
    ToolResultEvent,
    BeforeAgentStartEvent,
    AgentStartEvent,
    AgentEndEvent,
    TurnStartEvent,
    TurnEndEvent,
]

# ---------------------------------------------------------------------------
# Event results
# ---------------------------------------------------------------------------


@dataclass
class ToolCallEventResult:
    block: bool = False
    reason: str = ""


@dataclass
class ToolResultEventResult:
    content: list | None = None
    is_error: bool | None = None
