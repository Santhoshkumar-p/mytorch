"""
Extension system for the coding agent.

Re-exports the public surface of the extensions feature module.
"""
from __future__ import annotations

from .api import ExtensionAPI, HookAPI
from .loader import ExtensionLoader
from .runner import ExtensionRunner
from .types import Extension, ToolDefinition

__all__ = [
    "ExtensionAPI",
    "ExtensionLoader",
    "ExtensionRunner",
    "HookAPI",
    "Extension",
    "ToolDefinition",
]
