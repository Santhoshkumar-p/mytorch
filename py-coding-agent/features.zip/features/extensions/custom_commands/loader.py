"""
Custom command loader.

Discovers ``.commands.json`` / ``commands.json`` files by walking *cwd*
upward and merges all found entries into a flat list of
:class:`~coding_agent.features.extensions.custom_commands.types.CustomCommandConfig`.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path

from .types import CustomCommandConfig

logger = logging.getLogger(__name__)

_FILENAMES = (".commands.json", "commands.json")


def _load_file(path: Path) -> list[CustomCommandConfig]:
    """Parse a single commands JSON file."""
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed to read custom commands config %s: %s", path, exc)
        return []

    if isinstance(raw, list):
        entries = raw
    elif isinstance(raw, dict):
        entries = raw.get("commands", [])
    else:
        logger.warning("Unexpected custom commands format in %s", path)
        return []

    configs: list[CustomCommandConfig] = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        name = entry.get("name", "")
        if not name:
            continue
        configs.append(
            CustomCommandConfig(
                name=name,
                description=entry.get("description", ""),
                command=entry.get("command", ""),
                allowed_tools=entry.get("allowed_tools"),
            )
        )
    return configs


def load_custom_commands(cwd: str) -> list[CustomCommandConfig]:
    """
    Walk *cwd* upward and collect all custom command configurations.

    Commands with the same ``name`` from closer directories shadow those
    from parent directories.
    """
    seen_names: set[str] = set()
    result: list[CustomCommandConfig] = []
    current = Path(cwd).resolve()

    while True:
        for filename in _FILENAMES:
            candidate = current / filename
            if candidate.is_file():
                for cfg in _load_file(candidate):
                    if cfg.name not in seen_names:
                        seen_names.add(cfg.name)
                        result.append(cfg)
        parent = current.parent
        if parent == current:
            break
        current = parent

    return result
