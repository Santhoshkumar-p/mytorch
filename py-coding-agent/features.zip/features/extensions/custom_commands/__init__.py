"""Custom commands sub-package — file-based slash command definitions."""
from __future__ import annotations
