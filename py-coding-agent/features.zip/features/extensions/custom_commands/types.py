"""
Custom command configuration types.

Custom commands are defined in ``.commands.json`` / ``commands.json`` files.
Each entry maps a slash-command name to a shell command the agent will run.
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class CustomCommandConfig:
    """Configuration for a single file-based custom slash command."""

    name: str
    description: str = ""
    command: str = ""  # Shell command to execute
    allowed_tools: list[str] | None = None  # Tool allowlist (None = all)
