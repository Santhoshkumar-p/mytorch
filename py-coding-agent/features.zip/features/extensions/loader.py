"""
Extension loader — discovers and imports Python extension files.

Discovery: searches each configured directory for ``*.py`` files whose name
does not start with ``__``.  Each file is imported with ``importlib`` and its
``setup(pi)`` or ``default(pi)`` entry-point is called with an
``ExtensionAPI`` instance.
"""
from __future__ import annotations

import importlib.util
import logging
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .api import ExtensionAPI
from .types import Extension

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Result type
# ---------------------------------------------------------------------------


@dataclass
class LoadExtensionsResult:
    extensions: list[Extension] = field(default_factory=list)
    errors: list[dict] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _is_extension_file(path: Path) -> bool:
    """Return True for ``*.py`` files that are not dunder modules."""
    return path.suffix == ".py" and not path.name.startswith("__")


def _call_entry_point(module: Any, api: ExtensionAPI) -> bool:
    """
    Locate and call the extension entry-point.

    Tries ``setup`` first, then ``default``.  Returns True on success.
    """
    for attr in ("setup", "default"):
        fn = getattr(module, attr, None)
        if callable(fn):
            fn(api)
            return True
    return False


# ---------------------------------------------------------------------------
# Single-file loader
# ---------------------------------------------------------------------------


def load_extension_file(path: str, api: ExtensionAPI) -> Extension | None:
    """
    Load a single Python extension file and invoke its entry-point.

    Returns the populated :class:`Extension` on success, or ``None`` if the
    file provides no recognised entry-point.  Propagates import errors to the
    caller.
    """
    spec = importlib.util.spec_from_file_location(
        f"_pi_ext_{Path(path).stem}", path
    )
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot create module spec for {path!r}")

    module = importlib.util.module_from_spec(spec)
    # Make the module importable under its generated name
    sys.modules[spec.name] = module  # type: ignore[arg-type]
    spec.loader.exec_module(module)  # type: ignore[union-attr]

    called = _call_entry_point(module, api)
    if not called:
        logger.debug("Extension %r exports no setup/default entry-point — skipped", path)
        return None

    return api._extension


# ---------------------------------------------------------------------------
# Loader class
# ---------------------------------------------------------------------------


class ExtensionLoader:
    """
    Discovers and loads Python extension files from a set of directories.

    Usage::

        loader = ExtensionLoader(["/project/.pi/extensions"])
        result = loader.load_all()
        extensions = result.extensions
        errors = result.errors
    """

    def __init__(self, extensions_dirs: list[str], cwd: str = ".") -> None:
        self._dirs = extensions_dirs
        self._cwd = cwd
        self._extensions: list[Extension] = []
        self._errors: list[dict] = []
        self._loaded = False

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def load_all(self) -> LoadExtensionsResult:
        """
        Discover and load all ``*.py`` extension files found in the configured
        directories.  Errors are captured per-file and do not abort loading.
        """
        self._extensions = []
        self._errors = []
        self._loaded = True

        for dir_str in self._dirs:
            dir_path = Path(dir_str)
            if not dir_path.is_dir():
                logger.debug("Extension dir does not exist: %s", dir_str)
                continue

            for file_path in sorted(dir_path.glob("*.py")):
                if not _is_extension_file(file_path):
                    continue
                self._load_file(str(file_path))

        return LoadExtensionsResult(
            extensions=list(self._extensions),
            errors=list(self._errors),
        )

    def get_extensions(self) -> list[Extension]:
        """Return the extensions loaded by the most recent :meth:`load_all` call."""
        return list(self._extensions)

    def get_errors(self) -> list[dict]:
        """Return the per-file errors from the most recent :meth:`load_all` call."""
        return list(self._errors)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _load_file(self, path: str) -> None:
        ext = Extension(path=path)
        api = ExtensionAPI(ext, self._cwd)
        try:
            result = load_extension_file(path, api)
            if result is not None:
                self._extensions.append(result)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Failed to load extension %r: %s", path, exc)
            self._errors.append({"path": path, "error": str(exc)})
