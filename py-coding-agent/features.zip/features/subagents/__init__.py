"""
SubAgents feature package.

Provides agent registration, definition loading, and session tracking for
spawned sub-agents.
"""
from __future__ import annotations

from .loader import get_bundled_agents, load_agent_definitions
from .registry import AgentRegistry
from .types import AgentDefinition, AgentProgress, SingleResult, SubAgentRegistration

__all__ = [
    "AgentRegistry",
    "AgentDefinition",
    "AgentProgress",
    "SingleResult",
    "SubAgentRegistration",
    "load_agent_definitions",
    "get_bundled_agents",
]

# Convenience alias used in some integration call-sites
SubAgentSession = SubAgentRegistration
