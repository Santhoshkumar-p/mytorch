"""
AgentRegistry — runtime store for sub-agent registrations.

Tracks which sub-agents are active, who owns them, and their lifecycle state.
"""
from __future__ import annotations

import itertools
import time
from typing import Iterator

from .types import AgentDefinition, SubAgentRegistration


class AgentRegistry:
    """
    Central registry for sub-agent lifecycle management.

    Each parent agent gets an ``owner_id``; sub-agents are filed under that
    owner so the parent can query its own children without scanning everything.
    """

    _counter: Iterator[int] = itertools.count()

    def __init__(self) -> None:
        self._registrations: dict[str, SubAgentRegistration] = {}

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def register(self, agent_def: AgentDefinition, owner_id: str) -> str:
        """
        Register a new sub-agent and return its unique ID.

        The ID is a hex string derived from a monotonically increasing counter.
        """
        agent_id = format(next(self._counter), "x")
        registration = SubAgentRegistration(
            agent_def=agent_def,
            owner_id=owner_id,
            started_at=time.monotonic(),
            status="pending",
        )
        self._registrations[agent_id] = registration
        return agent_id

    # ------------------------------------------------------------------
    # Lookup
    # ------------------------------------------------------------------

    def get(self, agent_id: str) -> SubAgentRegistration | None:
        """Return the registration for *agent_id*, or None if unknown."""
        return self._registrations.get(agent_id)

    def list_by_owner(self, owner_id: str) -> list[SubAgentRegistration]:
        """Return all registrations whose owner matches *owner_id*."""
        return [r for r in self._registrations.values() if r.owner_id == owner_id]

    # ------------------------------------------------------------------
    # Lifecycle updates
    # ------------------------------------------------------------------

    def mark_completed(self, agent_id: str) -> None:
        """Transition an agent to the *completed* state."""
        reg = self._registrations.get(agent_id)
        if reg is not None:
            reg.status = "completed"
            reg.completed_at = time.monotonic()

    def mark_failed(self, agent_id: str, error: str) -> None:
        """Transition an agent to the *failed* state and record the error."""
        reg = self._registrations.get(agent_id)
        if reg is not None:
            reg.status = "failed"
            reg.error = error
            reg.completed_at = time.monotonic()

    # ------------------------------------------------------------------
    # Counts
    # ------------------------------------------------------------------

    def active_count(self, owner_id: str | None = None) -> int:
        """
        Return the number of agents in a non-terminal state.

        If *owner_id* is given, count only that owner's agents; otherwise
        count across all owners.
        """
        terminal = {"completed", "failed", "aborted"}
        regs = (
            self.list_by_owner(owner_id)
            if owner_id is not None
            else list(self._registrations.values())
        )
        return sum(1 for r in regs if r.status not in terminal)
