# SubAgents Feature

## Plan

Provide isolated sub-agent execution tracking so the parent agent can spawn
child agents, observe their lifecycle, and collect their results — all without
coupling the parent to the child's runtime details.

## Integration Architecture

`AgentRegistry` lives on `AgentSessionServices` (the shared service container
for a session).

**Spawn flow:**

1. Parent agent calls the `task` built-in tool with a task assignment.
2. Before launching the subprocess, call `registry.register(agent_def, owner_id)` to obtain a unique `agent_id`.
3. Start the subprocess (see `task_delegation` feature for the executor).
4. Fire `AgentStartEvent` through the `EventBus` so extensions can observe it.
5. When the subprocess exits, call `registry.mark_completed(agent_id)` or `registry.mark_failed(agent_id, error)`.
6. Fire `AgentEndEvent` through `EventBus`.
7. The caller retrieves the final output as a `SingleResult`.

**Querying:**

- `registry.list_by_owner(session_id)` — list all children of the current session.
- `registry.active_count(session_id)` — how many children are still running.

**Bundled vs user-defined agents:**

- `get_bundled_agents()` — always available; loaded at startup.
- `load_agent_definitions(agents_dir)` — scans `~/.claude/agents/*.md` (or project-local `.claude/agents/`).

## What Was Implemented

| File | Purpose |
|------|---------|
| `types.py` | `AgentDefinition`, `AgentProgress`, `SingleResult`, `SubAgentRegistration` dataclasses |
| `registry.py` | `AgentRegistry` — register / get / list / mark_completed / mark_failed / active_count |
| `loader.py` | `load_agent_definitions()` (Markdown + frontmatter) + `get_bundled_agents()` |

## Usage Example

```python
from coding_agent.features.subagents import AgentRegistry, get_bundled_agents

registry = AgentRegistry()

agents = get_bundled_agents()
task_agent = next(a for a in agents if a.name == "task")

agent_id = registry.register(task_agent, owner_id="session-abc")
print(f"Registered agent {agent_id}")

# ... run subprocess ...

registry.mark_completed(agent_id)

reg = registry.get(agent_id)
print(reg.status)   # "completed"
print(registry.active_count("session-abc"))  # 0
```
