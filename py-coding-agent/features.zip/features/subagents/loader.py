"""
Agent definition loader.

Scans agent directories for Markdown files with YAML frontmatter and returns
structured AgentDefinition objects.  No external YAML library is required —
frontmatter is parsed with a simple regex-based key: value scanner.
"""
from __future__ import annotations

import os
import re
from typing import Any

from .types import AgentDefinition, AgentSource


# ---------------------------------------------------------------------------
# Frontmatter parser
# ---------------------------------------------------------------------------

_FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)
_KEY_VALUE_RE = re.compile(r"^(\w[\w-]*):\s*(.*)$")
_LIST_ITEM_RE = re.compile(r"^\s+-\s+(.+)$")


def _parse_frontmatter(text: str) -> tuple[dict[str, Any], str]:
    """
    Extract YAML-like frontmatter from *text*.

    Supports scalar values and simple bullet-list sequences.
    Returns ``(metadata_dict, body_text)``.
    """
    match = _FRONTMATTER_RE.match(text)
    if not match:
        return {}, text

    raw = match.group(1)
    body = text[match.end():]
    meta: dict[str, Any] = {}

    current_key: str | None = None
    current_list: list[str] | None = None

    for line in raw.splitlines():
        list_match = _LIST_ITEM_RE.match(line)
        kv_match = _KEY_VALUE_RE.match(line)

        if list_match and current_key is not None:
            if current_list is None:
                current_list = []
                meta[current_key] = current_list
            current_list.append(list_match.group(1).strip())
        elif kv_match:
            current_key = kv_match.group(1)
            current_list = None
            value = kv_match.group(2).strip()
            # Blank value means the next lines may be a list
            meta[current_key] = value if value else None
        # Lines that don't match either pattern are silently skipped.

    return meta, body


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def load_agent_definitions(agents_dir: str) -> list[AgentDefinition]:
    """
    Scan *agents_dir* for ``*.md`` files and parse each as an AgentDefinition.

    Files without a ``name`` key in their frontmatter are skipped.
    """
    definitions: list[AgentDefinition] = []

    if not os.path.isdir(agents_dir):
        return definitions

    for filename in sorted(os.listdir(agents_dir)):
        if not filename.endswith(".md"):
            continue

        file_path = os.path.join(agents_dir, filename)
        try:
            with open(file_path, encoding="utf-8") as fh:
                content = fh.read()
        except OSError:
            continue

        meta, body = _parse_frontmatter(content)

        name = meta.get("name")
        if not name:
            continue

        tools_raw = meta.get("tools")
        if isinstance(tools_raw, list):
            tools: list[str] | None = tools_raw
        elif isinstance(tools_raw, str) and tools_raw:
            tools = [t.strip() for t in tools_raw.split(",") if t.strip()]
        else:
            tools = None

        spawns_raw = meta.get("spawns")
        if spawns_raw == "*":
            spawns: list[str] | str | None = "*"
        elif isinstance(spawns_raw, list):
            spawns = spawns_raw
        elif isinstance(spawns_raw, str) and spawns_raw:
            spawns = [s.strip() for s in spawns_raw.split(",") if s.strip()]
        else:
            spawns = None

        model_raw = meta.get("model")
        if isinstance(model_raw, list):
            model: str | list[str] | None = model_raw
        elif isinstance(model_raw, str) and model_raw:
            model = model_raw
        else:
            model = None

        definitions.append(
            AgentDefinition(
                name=str(name),
                description=str(meta.get("description", "")).strip(),
                system_prompt=body.strip(),
                source="user",
                tools=tools,
                spawns=spawns,
                model=model,
                file_path=file_path,
            )
        )

    return definitions


def get_bundled_agents() -> list[AgentDefinition]:
    """
    Return the hardcoded list of built-in bundled agents.

    These agents are always available regardless of user configuration.
    """
    return [
        AgentDefinition(
            name="explore",
            description=(
                "Read-only exploration agent. Gathers information about a codebase "
                "or topic without making any changes."
            ),
            system_prompt=(
                "You are an exploration agent. Your sole job is to read and understand "
                "the codebase, files, and documentation. You MUST NOT create, edit, or "
                "delete any files. Summarise your findings clearly and concisely."
            ),
            source="bundled",
            tools=["read_file", "list_directory", "search", "glob"],
            spawns=None,
            model=None,
        ),
        AgentDefinition(
            name="plan",
            description=(
                "Planning agent. Produces a structured plan for a task without "
                "executing any actions."
            ),
            system_prompt=(
                "You are a planning agent. Given a task description, produce a "
                "detailed, step-by-step plan. Do NOT execute the plan — only write it. "
                "Use numbered steps, note dependencies, and highlight risks."
            ),
            source="bundled",
            tools=["read_file", "list_directory"],
            spawns=None,
            model=None,
        ),
        AgentDefinition(
            name="task",
            description=(
                "General-purpose task agent. Can read, write, and execute to "
                "complete an assigned task end-to-end."
            ),
            system_prompt=(
                "You are a general-purpose task agent. Complete the assigned task "
                "thoroughly and accurately. Use available tools as needed. Report "
                "progress and any blockers clearly."
            ),
            source="bundled",
            tools=None,   # all tools available
            spawns=None,
            model=None,
        ),
    ]
