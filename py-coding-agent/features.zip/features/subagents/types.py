"""
SubAgents type definitions.

Defines the core data structures for agent registration, progress tracking,
and result reporting for sub-agent execution.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

AgentSource = Literal["bundled", "user", "project"]


@dataclass
class AgentDefinition:
    """Definition of an agent that can be spawned as a sub-agent."""

    name: str
    description: str
    system_prompt: str
    source: AgentSource = "bundled"
    tools: list[str] | None = None
    spawns: list[str] | str | None = None  # list[str] | "*" | None
    model: str | list[str] | None = None
    file_path: str | None = None


@dataclass
class AgentProgress:
    """Live progress snapshot for a running sub-agent."""

    index: int
    id: str
    agent: str
    status: Literal["pending", "running", "completed", "failed", "aborted"]
    task: str
    last_intent: str = ""
    current_tool: str | None = None
    tool_count: int = 0
    tokens: int = 0
    cost: float = 0.0
    duration_ms: float = 0.0


@dataclass
class SingleResult:
    """Final result from a completed (or failed) sub-agent run."""

    index: int
    id: str
    agent: str
    task: str
    assignment: str
    exit_code: int
    output: str
    stderr: str = ""
    truncated: bool = False
    duration_ms: float = 0.0
    tokens: int = 0
    error: str | None = None
    aborted: bool = False


@dataclass
class SubAgentRegistration:
    """Runtime registration record created when a sub-agent is spawned."""

    agent_def: AgentDefinition
    owner_id: str
    started_at: float
    completed_at: float | None = None
    status: Literal["pending", "running", "completed", "failed", "aborted"] = "pending"
    error: str | None = None
    result: SingleResult | None = None
