"""
IRC — in-process agent-to-agent messaging.

Agents can send direct messages or broadcast to all peers.
Replies are optionally awaited (blocking DM) or fire-and-forget (broadcast).
"""

from .manager import IRCManager, IRCMessage, IRCResult, DeliveryRecord
from .tool import IRCTool

__all__ = ["IRCManager", "IRCMessage", "IRCResult", "DeliveryRecord", "IRCTool"]
