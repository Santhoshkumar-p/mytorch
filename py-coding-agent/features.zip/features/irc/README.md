# IRC — In-Process Agent Messaging

Provides `IRCTool` — an agent tool for sending messages between agents running in the same process.

## Concepts

- **Registry**: `IRCManager` maintains a per-agent inbox queue.
- **DM** (`to=<name>`): delivers to one agent; `await_reply=True` by default.
- **Broadcast** (`to="all"`): delivers to all peers except sender; fire-and-forget by default.
- **Reply handler**: attach `manager.set_handler(name, async_fn)` so DM senders can get a reply.

## Usage

```python
from coding_agent.features.irc import IRCManager, IRCTool

manager = IRCManager()
manager.register("agent-a")
manager.register("agent-b")

# Give each agent an IRCTool bound to the shared manager
tool_a = IRCTool(manager, "agent-a")
tool_b = IRCTool(manager, "agent-b")

# agent-a sends a DM to agent-b
result = await tool_a.execute({"op": "send", "to": "agent-b", "message": "hi"})
```

## Tool Schema

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `op` | `"send"` \| `"list"` | yes | Operation |
| `to` | string | for send | Target agent name or `"all"` |
| `message` | string | for send | Message content |
| `await_reply` | bool | no | Block for reply (default: true for DM) |
| `timeout` | number | no | Reply timeout seconds (default: 30) |
