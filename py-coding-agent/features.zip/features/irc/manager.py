"""
In-process agent-to-agent messaging registry.

Agents register themselves on start.  The IRCManager routes messages between
registered agents.  Each agent has an asyncio.Queue for incoming messages.

Thread-safety: all mutations go through asyncio, caller must be in the event loop.
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any


@dataclass
class IRCMessage:
    """A message sent from one agent to another (or broadcast)."""
    from_agent: str
    to_agent: str          # "all" for broadcast
    content: str
    timestamp: float = field(default_factory=time.time)


@dataclass
class DeliveryRecord:
    agent: str
    reply: str | None = None
    error: str | None = None


@dataclass
class IRCResult:
    delivered: list[str]           # agent names that received the message
    replies: list[DeliveryRecord]  # replies collected (await_reply=True)
    failed: list[str]              # agents that failed to receive
    not_found: list[str]           # names that were not registered
    peers: list[str]               # all currently registered agents


class IRCManager:
    """
    Central message broker for in-process agent communication.

    Usage::

        manager = IRCManager()
        manager.register("agent-a")
        manager.register("agent-b")

        result = await manager.send(
            from_agent="agent-a",
            to_agent="agent-b",
            content="hello",
            await_reply=True,
        )
    """

    def __init__(self) -> None:
        # name -> asyncio.Queue[IRCMessage]
        self._queues: dict[str, asyncio.Queue[IRCMessage]] = {}
        # name -> reply handler coroutine (optional)
        self._handlers: dict[str, Any] = {}

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def register(self, agent_name: str) -> None:
        """Register an agent so it can send and receive messages."""
        if agent_name not in self._queues:
            self._queues[agent_name] = asyncio.Queue()

    def unregister(self, agent_name: str) -> None:
        """Remove an agent from the registry."""
        self._queues.pop(agent_name, None)
        self._handlers.pop(agent_name, None)

    def set_handler(self, agent_name: str, handler: Any) -> None:
        """
        Attach an async reply handler for an agent.

        The handler is called with ``(IRCMessage) -> str | None``.
        """
        self._handlers[agent_name] = handler

    @property
    def peers(self) -> list[str]:
        return sorted(self._queues.keys())

    # ------------------------------------------------------------------
    # Messaging
    # ------------------------------------------------------------------

    async def send(
        self,
        from_agent: str,
        to_agent: str,
        content: str,
        *,
        await_reply: bool | None = None,
        timeout: float = 30.0,
    ) -> IRCResult:
        """
        Send a message from one agent to another or to all agents.

        :param from_agent:   Sender name (must be registered).
        :param to_agent:     Recipient name, or ``"all"`` for broadcast.
        :param content:      Message text.
        :param await_reply:  If True, block until a reply is received.
                             Defaults to True for DM, False for broadcast.
        :param timeout:      Max seconds to wait for replies.
        :returns:            :class:`IRCResult` with delivery details.
        """
        if await_reply is None:
            await_reply = to_agent != "all"

        peers_snapshot = self.peers

        if to_agent == "all":
            targets = [p for p in peers_snapshot if p != from_agent]
        else:
            targets = [to_agent]

        delivered: list[str] = []
        failed: list[str] = []
        not_found: list[str] = []
        replies: list[DeliveryRecord] = []

        for target in targets:
            if target not in self._queues:
                not_found.append(target)
                continue

            msg = IRCMessage(from_agent=from_agent, to_agent=target, content=content)

            try:
                await self._queues[target].put(msg)
                delivered.append(target)
            except Exception:
                failed.append(target)
                continue

            if await_reply:
                handler = self._handlers.get(target)
                if handler is not None:
                    try:
                        if asyncio.iscoroutinefunction(handler):
                            coro = handler(msg)
                        else:
                            coro = asyncio.to_thread(handler, msg)
                        reply_text = await asyncio.wait_for(coro, timeout=timeout)
                        replies.append(DeliveryRecord(agent=target, reply=str(reply_text) if reply_text else None))
                    except asyncio.TimeoutError:
                        replies.append(DeliveryRecord(agent=target, error="timeout"))
                    except Exception as exc:
                        replies.append(DeliveryRecord(agent=target, error=str(exc)))

        return IRCResult(
            delivered=delivered,
            replies=replies,
            failed=failed,
            not_found=not_found,
            peers=peers_snapshot,
        )

    async def receive(self, agent_name: str, timeout: float | None = None) -> IRCMessage | None:
        """
        Pop the next message for *agent_name* from its inbox.

        :param agent_name: Recipient.
        :param timeout:    Seconds to wait.  ``None`` = non-blocking.
        :returns:          :class:`IRCMessage` or ``None`` if queue empty / timeout.
        """
        queue = self._queues.get(agent_name)
        if queue is None:
            return None
        try:
            if timeout is None:
                return queue.get_nowait()
            return await asyncio.wait_for(queue.get(), timeout=timeout)
        except (asyncio.QueueEmpty, asyncio.TimeoutError):
            return None
