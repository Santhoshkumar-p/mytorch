"""
IRCTool — agent tool wrapper around IRCManager.

Registers as ``irc`` in the tool registry.  Agents call it to send messages
to peers or list available agents.

Parameters
----------
op : "send" | "list"
to : str, optional
    Target agent name or "all".  Required for op="send".
message : str, optional
    Message content.  Required for op="send".
await_reply : bool, optional
    Whether to block for a reply (default: True for DM, False for broadcast).
timeout : float, optional
    Max seconds to wait for replies (default: 30).
"""

from __future__ import annotations

import json
from typing import Any

from .manager import IRCManager


class IRCTool:
    """
    Agent tool for in-process inter-agent communication.

    Instantiate once per session and share the same :class:`IRCManager`
    across all agents that should be able to talk to each other.
    """

    name = "irc"
    description = (
        "Send a message to another agent or broadcast to all peers. "
        "Use op='list' to see available agents. "
        "Use op='send' with to=<agent_name> or to='all' for broadcast."
    )

    def __init__(self, manager: IRCManager, agent_name: str) -> None:
        self._manager = manager
        self._agent_name = agent_name

    async def execute(self, params: dict[str, Any]) -> str:
        op = params.get("op", "list")

        if op == "list":
            peers = self._manager.peers
            other = [p for p in peers if p != self._agent_name]
            return json.dumps({"peers": other})

        if op == "send":
            to = params.get("to")
            message = params.get("message", "")
            if not to:
                return json.dumps({"error": "Missing 'to' parameter"})
            await_reply: bool | None = params.get("await_reply")
            timeout = float(params.get("timeout", 30.0))

            result = await self._manager.send(
                from_agent=self._agent_name,
                to_agent=to,
                content=message,
                await_reply=await_reply,
                timeout=timeout,
            )
            return json.dumps({
                "delivered": result.delivered,
                "replies": [
                    {"agent": r.agent, "reply": r.reply, "error": r.error}
                    for r in result.replies
                ],
                "failed": result.failed,
                "not_found": result.not_found,
                "peers": result.peers,
            })

        return json.dumps({"error": f"Unknown op: {op!r}. Use 'send' or 'list'."})

    @property
    def schema(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "input_schema": {
                "type": "object",
                "properties": {
                    "op": {
                        "type": "string",
                        "enum": ["send", "list"],
                        "description": "Operation: 'send' a message or 'list' available peers",
                    },
                    "to": {
                        "type": "string",
                        "description": "Target agent name or 'all' for broadcast (required for op='send')",
                    },
                    "message": {
                        "type": "string",
                        "description": "Message content (required for op='send')",
                    },
                    "await_reply": {
                        "type": "boolean",
                        "description": "Block until a reply is received (default: true for DM, false for broadcast)",
                    },
                    "timeout": {
                        "type": "number",
                        "description": "Max seconds to wait for replies (default: 30)",
                    },
                },
                "required": ["op"],
            },
        }
