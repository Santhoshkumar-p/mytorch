# Browser Tools Feature

## Plan

Expose a `"browser"` tool backed by the `browser-harness` CLI so the agent
can open URLs, take screenshots, click, type, run JavaScript, and extract
text — all through the existing harness that is already on PATH.

## Integration Architecture

**Tool registration (startup):**

```python
from coding_agent.features.browser import BrowserTool

browser_tool = BrowserTool()
if browser_tool.is_available():
    tool_registry.register(browser_tool.get_tool_definition(), browser_tool.execute)
```

The `is_available()` check uses `shutil.which("browser-harness")`.  If the
binary is absent the tool is silently omitted so the agent starts cleanly
without it.

**BrowserSession lifetime:**

One `BrowserSession` instance is created per `BrowserTool` instance.
Attach the tool to `AgentSessionServices` to share the session across all
tool calls in the same agent session.

**Interaction pattern (from SKILL.md):**

1. `screenshot` — take a screenshot to understand the current page.
2. `click` — click at pixel coordinates read from the screenshot.
3. `screenshot` again — verify the action succeeded.
4. Fall back to `js` / `get_text` only when coordinate-based interaction
   is the wrong tool.

## What Was Implemented

| File | Purpose |
|------|---------|
| `types.py` | `BrowserAction`, `BrowserToolInput`, `BrowserToolResult` |
| `session.py` | `BrowserSession` — open, navigate, screenshot, click, type_text, run_js, get_text, close; `run_harness()` helper |
| `tool.py` | `BrowserTool` — Anthropic tool definition, `execute()` dispatcher, `get_tool_definition()` |

## Usage Example

```python
import asyncio
from coding_agent.features.browser import BrowserTool

tool = BrowserTool()

async def main():
    if not tool.is_available():
        print("browser-harness not found — skipping")
        return

    # Open a page
    result = await tool.execute({"action": "open", "url": "https://example.com"})
    print(result)

    # Take a screenshot
    result = await tool.execute({"action": "screenshot"})
    if "screenshot_b64:" in result:
        b64 = result.split("screenshot_b64:")[1]
        print(f"Got {len(b64)} bytes of base64 PNG")

    # Click a button at known coordinates
    await tool.execute({"action": "click", "x": 400, "y": 300})

    await tool.execute({"action": "close"})

asyncio.run(main())
```
