"""
Browser tools feature package.

Provides a browser automation tool backed by the browser-harness CLI.
The tool is automatically omitted at startup if browser-harness is not
installed.
"""
from __future__ import annotations

from .session import BrowserSession, run_harness
from .tool import BrowserTool
from .types import BrowserAction, BrowserToolInput, BrowserToolResult

__all__ = [
    "BrowserTool",
    "BrowserSession",
    "BrowserAction",
    "BrowserToolInput",
    "BrowserToolResult",
    "run_harness",
]
