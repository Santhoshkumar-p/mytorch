"""
Browser tool type definitions.

Describes the actions the browser tool supports and the shapes of its
input/output data.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

BrowserAction = Literal[
    "open",
    "close",
    "screenshot",
    "click",
    "type",
    "navigate",
    "js",
    "get_text",
]


@dataclass
class BrowserToolInput:
    """
    Structured input for a single browser tool invocation.

    Not all fields are used by every action — unused fields default to None.
    """

    action: BrowserAction
    url: str | None = None
    x: int | None = None
    y: int | None = None
    text: str | None = None
    js_code: str | None = None
    selector: str | None = None


@dataclass
class BrowserToolResult:
    """Result returned by a BrowserSession method."""

    success: bool
    output: str
    screenshot_b64: str | None = None
    error: str | None = None
