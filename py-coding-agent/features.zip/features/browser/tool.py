"""
BrowserTool — Anthropic tool definition and dispatcher for browser actions.

Wraps BrowserSession behind the standard tool interface used by the agent
loop.  Each call dispatches to the appropriate BrowserSession method based
on the ``action`` parameter.
"""
from __future__ import annotations

from .session import BrowserSession
from .types import BrowserToolInput, BrowserToolResult

_INPUT_SCHEMA: dict = {
    "type": "object",
    "required": ["action"],
    "properties": {
        "action": {
            "type": "string",
            "enum": ["open", "close", "screenshot", "click", "type", "navigate", "js", "get_text"],
            "description": "The browser action to perform.",
        },
        "url": {
            "type": "string",
            "description": "URL to open or navigate to (used with 'open' and 'navigate').",
        },
        "x": {
            "type": "integer",
            "description": "Viewport X coordinate for 'click'.",
        },
        "y": {
            "type": "integer",
            "description": "Viewport Y coordinate for 'click'.",
        },
        "text": {
            "type": "string",
            "description": "Text to type into the focused element (used with 'type').",
        },
        "js_code": {
            "type": "string",
            "description": "JavaScript expression to evaluate in the page (used with 'js').",
        },
        "selector": {
            "type": "string",
            "description": "CSS selector for element-scoped operations (used with 'get_text').",
        },
    },
}


class BrowserTool:
    """
    Agent-facing browser tool.

    Implements the tool interface expected by the agent loop:
    ``name``, ``description``, ``input_schema``, ``execute()``, and
    ``get_tool_definition()``.
    """

    name = "browser"
    description = (
        "Control a web browser. Actions: open, close, screenshot, click, "
        "type, navigate, js, get_text."
    )
    input_schema = _INPUT_SCHEMA

    def __init__(self) -> None:
        self._session = BrowserSession()

    def is_available(self) -> bool:
        """Return True if the browser-harness binary is on PATH."""
        return self._session.is_available()

    def get_tool_definition(self) -> dict:
        """Return the Anthropic tool definition dict for this tool."""
        return {
            "name": self.name,
            "description": self.description,
            "input_schema": self.input_schema,
        }

    async def execute(self, params: dict) -> str:
        """
        Dispatch *params* to the appropriate BrowserSession method.

        Returns a human-readable string result.  If a screenshot is captured,
        the base64 image is appended after a separator.
        """
        action = params.get("action", "")

        result: BrowserToolResult

        if action == "open":
            url = params.get("url") or ""
            result = await self._session.open(url)

        elif action == "navigate":
            url = params.get("url") or ""
            result = await self._session.navigate(url)

        elif action == "screenshot":
            result = await self._session.screenshot()

        elif action == "click":
            x = int(params.get("x") or 0)
            y = int(params.get("y") or 0)
            result = await self._session.click(x, y)

        elif action == "type":
            text = params.get("text") or ""
            result = await self._session.type_text(text)

        elif action == "js":
            code = params.get("js_code") or ""
            result = await self._session.run_js(code)

        elif action == "get_text":
            selector = params.get("selector")
            result = await self._session.get_text(selector)

        elif action == "close":
            result = await self._session.close()

        else:
            return f"Unknown browser action: {action!r}"

        lines: list[str] = []
        status = "OK" if result.success else "FAILED"
        lines.append(f"[browser:{action}] {status}")
        if result.output:
            lines.append(result.output)
        if result.error:
            lines.append(f"Error: {result.error}")
        if result.screenshot_b64:
            lines.append("---")
            lines.append(f"screenshot_b64:{result.screenshot_b64}")

        return "\n".join(lines)
