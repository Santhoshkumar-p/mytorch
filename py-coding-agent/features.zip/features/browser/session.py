"""
BrowserSession — thin wrapper over the browser-harness CLI.

Each public method builds a small Python snippet, passes it to the
``browser-harness`` CLI via a heredoc-style subprocess call, and parses the
output into a BrowserToolResult.

The browser-harness binary is expected to be on PATH (see SKILL.md).
"""
from __future__ import annotations

import asyncio
import base64
import shutil

from .types import BrowserToolResult

_HARNESS_BIN = "browser-harness"


async def run_harness(script: str) -> tuple[str, str]:
    """
    Run *script* through the browser-harness CLI.

    Returns ``(stdout, stderr)`` as decoded strings.
    """
    proc = await asyncio.create_subprocess_exec(
        _HARNESS_BIN,
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout_bytes, stderr_bytes = await proc.communicate(input=script.encode())
    return (
        stdout_bytes.decode("utf-8", errors="replace"),
        stderr_bytes.decode("utf-8", errors="replace"),
    )


class BrowserSession:
    """
    Async interface to a browser session managed by browser-harness.

    Uses coordinate-based interaction (click, screenshot) as the primary
    mode, consistent with the browser-harness SKILL.md design philosophy.
    """

    def is_available(self) -> bool:
        """Return True if the browser-harness binary is found on PATH."""
        return shutil.which(_HARNESS_BIN) is not None

    # ------------------------------------------------------------------
    # Navigation
    # ------------------------------------------------------------------

    async def open(self, url: str) -> BrowserToolResult:
        """Open *url* in a new tab and wait for the page to load."""
        script = (
            f"new_tab({url!r})\n"
            "wait_for_load()\n"
            "print(page_info())\n"
        )
        stdout, stderr = await run_harness(script)
        success = not stderr.strip() or "Error" not in stderr
        return BrowserToolResult(
            success=success,
            output=stdout.strip(),
            error=stderr.strip() or None,
        )

    async def navigate(self, url: str) -> BrowserToolResult:
        """Navigate the active tab to *url*."""
        script = (
            f"goto({url!r})\n"
            "wait_for_load()\n"
            "print(page_info())\n"
        )
        stdout, stderr = await run_harness(script)
        success = not stderr.strip() or "Error" not in stderr
        return BrowserToolResult(
            success=success,
            output=stdout.strip(),
            error=stderr.strip() or None,
        )

    # ------------------------------------------------------------------
    # Visual interaction
    # ------------------------------------------------------------------

    async def screenshot(self) -> BrowserToolResult:
        """
        Capture a screenshot of the active tab.

        The image is returned as a base64-encoded PNG in ``screenshot_b64``.
        The harness ``screenshot()`` function is expected to write a PNG to
        stdout when called with ``output='base64'``.
        """
        script = "print(screenshot(output='base64'))\n"
        stdout, stderr = await run_harness(script)
        b64 = stdout.strip()
        success = bool(b64) and not (stderr.strip() and "Error" in stderr)
        return BrowserToolResult(
            success=success,
            output="Screenshot captured." if success else "Screenshot failed.",
            screenshot_b64=b64 if success else None,
            error=stderr.strip() or None,
        )

    async def click(self, x: int, y: int) -> BrowserToolResult:
        """Click at viewport coordinates (*x*, *y*)."""
        script = (
            f"click({x}, {y})\n"
            "print('click ok')\n"
        )
        stdout, stderr = await run_harness(script)
        success = "click ok" in stdout
        return BrowserToolResult(
            success=success,
            output=stdout.strip(),
            error=stderr.strip() or None,
        )

    async def type_text(self, text: str) -> BrowserToolResult:
        """Type *text* into the currently focused element."""
        # Escape backslashes and quotes for safe embedding in the script.
        safe = text.replace("\\", "\\\\").replace("'", "\\'")
        script = (
            f"type_text('{safe}')\n"
            "print('type ok')\n"
        )
        stdout, stderr = await run_harness(script)
        success = "type ok" in stdout
        return BrowserToolResult(
            success=success,
            output=stdout.strip(),
            error=stderr.strip() or None,
        )

    # ------------------------------------------------------------------
    # JavaScript / text extraction
    # ------------------------------------------------------------------

    async def run_js(self, code: str) -> BrowserToolResult:
        """Evaluate *code* in the page context and return the result."""
        safe = code.replace("\\", "\\\\").replace("'", "\\'")
        script = (
            f"result = js('{safe}')\n"
            "print(result)\n"
        )
        stdout, stderr = await run_harness(script)
        success = not (stderr.strip() and "Error" in stderr)
        return BrowserToolResult(
            success=success,
            output=stdout.strip(),
            error=stderr.strip() or None,
        )

    async def get_text(self, selector: str | None = None) -> BrowserToolResult:
        """Return visible text from the page or a specific element."""
        if selector:
            safe = selector.replace("\\", "\\\\").replace("'", "\\'")
            script = f"print(js(\"document.querySelector('{safe}')?.innerText || ''\"))\n"
        else:
            script = "print(js(\"document.body.innerText\"))\n"
        stdout, stderr = await run_harness(script)
        success = not (stderr.strip() and "Error" in stderr)
        return BrowserToolResult(
            success=success,
            output=stdout.strip(),
            error=stderr.strip() or None,
        )

    async def close(self) -> BrowserToolResult:
        """Close the active tab."""
        script = "close_tab()\nprint('closed')\n"
        stdout, stderr = await run_harness(script)
        success = "closed" in stdout
        return BrowserToolResult(
            success=success,
            output=stdout.strip(),
            error=stderr.strip() or None,
        )
