# Feature Integration Plan

This document describes exactly how to wire all feature packages into the
existing `coding_agent` core.  It covers all 12 feature packages:

| # | Package | What it provides |
|---|---------|-----------------|
| 1 | `features/mcp` | MCP server connections + tool bridge |
| 2 | `features/extensions` | Extension loader + hook/event system |
| 3 | `features/subagents` | Sub-agent registry + YAML definitions |
| 4 | `features/browser` | `browser-harness` tool wrapper |
| 5 | `features/memory` | Persistent session memory injection |
| 6 | `features/background` | Async background job manager |
| 7 | `features/plan_mode` | Plan mode with approval checkpoint |
| 8 | `features/task_delegation` | Parallel/serial task fan-out |
| 9 | `features/swarm` | Multi-agent YAML pipeline orchestration |
| 10 | `features/irc` | In-process agent-to-agent messaging |
| 11 | `features/todo` | Phase-based task list tool |
| 12 | `features/ssh` | Remote SSH command execution |

---

## Guiding Principles

1. **Additive only** — never modify existing logic paths; only extend them.
2. **Optional by default** — every feature is disabled when not configured.
3. **Commit in layers** — each feature is a self-contained commit; later features
   may depend on earlier ones (see dependency graph below).
4. **No new required dependencies** — each feature either uses the stdlib or
   makes its third-party dependency optional with a clear `ImportError` at
   usage time (not at import time).

---

## Feature Dependency Graph

```
features/extensions  ←  features/mcp
                     ←  features/subagents
                     ←  features/swarm (extension.py)
                     ←  features/plan_mode
                     ←  features/memory

features/subagents   ←  features/irc       (shared AgentRegistry)
features/subagents   ←  features/task_delegation

features/background  ←  (standalone, useful for swarm status)

features/ssh         ←  (standalone)
features/todo        ←  (standalone)
features/browser     ←  (standalone, requires browser-harness CLI)
```

Integration order (fewest dependencies first):

1. `extensions` — base hook system  
2. `mcp` — connects to tool servers, depends on extensions for lifecycle hooks  
3. `memory` — injects into system prompt, hooks `before_agent_start`  
4. `plan_mode` — injects into system prompt, hooks tool calls  
5. `subagents` — registry for named agents  
6. `background` — standalone job manager  
7. `task_delegation` — uses subagent names  
8. `irc` — uses AgentRegistry from subagents  
9. `todo` — standalone tool  
10. `ssh` — standalone tool  
11. `browser` — standalone tool  
12. `swarm` — full pipeline, uses extensions for `/swarm` command  

---

## 1. `features/extensions` → Core Extension System

### What already exists

`coding_agent/core/extensions/` already has a thin extension system.
`features/extensions` is a **richer** port of the TypeScript original with:
- Shell hook runner (pre/post tool calls via `.hooks.json`)
- `HookAPI` / `ExtensionAPI` with `register_tool`, `register_command`
- Event types for every lifecycle moment

### Integration steps

**File: `core/agent_session.py`**

Replace (or augment) the existing `_extension_runner_ref` usage to also accept
the richer `features/extensions` runner:

```python
# At top of file — import both runners
from coding_agent.core.extensions.runner import ExtensionRunner as CoreExtensionRunner
# features runner is optional
try:
    from coding_agent.features.extensions.runner import ExtensionRunner as FeatureExtensionRunner
    from coding_agent.features.extensions.loader import ExtensionLoader
    from coding_agent.features.extensions.hooks.runner import ShellHookRunner
    _FEATURES_EXTENSIONS_AVAILABLE = True
except ImportError:
    _FEATURES_EXTENSIONS_AVAILABLE = False
```

**File: `core/agent_session_services.py`**

Add optional fields for the feature extension system:

```python
from dataclasses import dataclass, field
from typing import Any

@dataclass
class AgentSessionServices:
    cwd: str
    agent_dir: str
    settings_manager: SettingsManager
    resource_loader: ResourceLoader
    # --- new optional fields ---
    extension_runner: Any | None = None    # features/extensions ExtensionRunner
    shell_hook_runner: Any | None = None   # features/extensions ShellHookRunner
```

**File: `core/agent_session_services.py` — `create_agent_session_services()`**

```python
async def create_agent_session_services(
    cwd: str | None = None,
    agent_dir: str | None = None,
    settings_overrides: dict | None = None,
    extensions_dirs: list[str] | None = None,   # NEW
) -> AgentSessionServices:
    cwd = cwd or os.getcwd()
    agent_dir = agent_dir or str(Path.home() / ".coding-agent")
    sm = SettingsManager.create(cwd, agent_dir)
    if settings_overrides:
        sm.apply_overrides(settings_overrides)
    rl = ResourceLoader(cwd, agent_dir, sm)

    extension_runner = None
    shell_hook_runner = None
    try:
        from coding_agent.features.extensions.loader import ExtensionLoader
        from coding_agent.features.extensions.runner import ExtensionRunner
        from coding_agent.features.extensions.hooks.runner import ShellHookRunner

        dirs = extensions_dirs or [
            os.path.join(cwd, ".pi", "extensions"),
            os.path.join(agent_dir, "extensions"),
        ]
        existing_dirs = [d for d in dirs if os.path.isdir(d)]
        if existing_dirs:
            loader = ExtensionLoader(extensions_dirs=existing_dirs, cwd=cwd)
            load_result = loader.load_all()
            extension_runner = ExtensionRunner(extensions=load_result.extensions)
        shell_hook_runner = ShellHookRunner(cwd=cwd)
    except ImportError:
        pass

    return AgentSessionServices(
        cwd=cwd,
        agent_dir=agent_dir,
        settings_manager=sm,
        resource_loader=rl,
        extension_runner=extension_runner,
        shell_hook_runner=shell_hook_runner,
    )
```

**File: `core/agent_session.py` — `_run_tool()` (wherever tools are executed)**

Wrap each tool call with shell hook runners and extension event firing:

```python
async def _run_tool_with_hooks(self, tool_call_id, name, params, abort_event, on_update):
    services = self._services   # needs reference to services
    hook_runner = getattr(services, "shell_hook_runner", None)
    ext_runner  = getattr(services, "extension_runner", None)

    # 1. Pre-tool extension hook
    if ext_runner:
        from coding_agent.features.extensions.types import ToolCallEvent
        result = await ext_runner.fire_tool_call(ToolCallEvent(
            tool_name=name, params=params, tool_call_id=tool_call_id
        ))
        if result.block:
            return _blocked_result(name, result.reason)

    # 2. Shell pre-hook
    if hook_runner:
        sh_result = await hook_runner.run_pre_hook(name, params)
        if sh_result and sh_result.blocked:
            return _blocked_result(name, sh_result.reason)

    # 3. Actual tool execution
    tool_result = await self._run_tool(tool_call_id, name, params, abort_event, on_update)

    # 4. Shell post-hook
    if hook_runner:
        await hook_runner.run_post_hook(name, params, tool_result)

    # 5. Post-tool extension event
    if ext_runner:
        from coding_agent.features.extensions.types import ToolResultEvent
        tool_result = await ext_runner.fire_tool_result(ToolResultEvent(
            tool_name=name, params=params, result=tool_result, tool_call_id=tool_call_id
        ))

    return tool_result
```

**File: `core/slash_commands.py`**

The function `get_slash_commands()` already accepts `extension_runner`.
Pass `services.extension_runner` wherever `get_slash_commands()` is called
(look in `app.py` / TUI startup).

---

## 2. `features/mcp` → MCP Tool Bridge

### What it adds

Connects to MCP servers defined in `~/.config/pi/mcp.json` or `.pi/mcp.json`
and makes their tools available to the agent as additional tools in the
`custom_tools` list.

### Integration steps

**File: `core/agent_session_services.py`**

Add `mcp_manager: Any | None = None` to `AgentSessionServices`.

**File: `core/agent_session_services.py` — `create_agent_session_services()`**

```python
mcp_manager = None
try:
    from coding_agent.features.mcp.manager import MCPManager
    mcp_manager = MCPManager(cwd=cwd)
    await mcp_manager.discover_and_connect()
except ImportError:
    pass

return AgentSessionServices(
    ...,
    mcp_manager=mcp_manager,
)
```

**File: `core/tools/registry.py` — `build_tools()`**

```python
def build_tools(
    cwd: str,
    settings,
    active_names: list[str] | None = None,
    custom_tools: list | None = None,
    mcp_manager=None,          # NEW
) -> list:
    ...
    # After existing tools are built, append MCP tools
    if mcp_manager is not None:
        try:
            mcp_tools = mcp_manager.get_tools()
            tools.extend(mcp_tools)
        except Exception:
            pass
    ...
```

**File: wherever `build_tools()` is called** (agent_session.py / app.py):

Pass `services.mcp_manager` through.

**Cleanup on session end** — in `AgentSessionRuntime.dispose()`:

```python
async def dispose(self) -> None:
    ...
    if hasattr(self._services, "mcp_manager") and self._services.mcp_manager:
        await self._services.mcp_manager.disconnect_all()
```

---

## 3. `features/memory` → Persistent Memory Injection

### What it adds

Reads `.memory.md` from `agent_dir` and injects it into the system prompt
before every turn.

### Integration steps

**File: `core/agent_session_services.py`**

```python
memory_backend: Any | None = None   # add to AgentSessionServices
```

```python
# In create_agent_session_services():
try:
    from coding_agent.features.memory.local_backend import LocalMemoryBackend
    memory_backend = LocalMemoryBackend()
    await memory_backend.start(session_id="default", agent_dir=agent_dir)
except ImportError:
    pass
```

**File: `core/system_prompt.py` — `build_system_prompt()`**

Add `memory_content: str | None = None` to `BuildSystemPromptOptions`:

```python
@dataclass
class BuildSystemPromptOptions:
    ...
    memory_content: str | None = None     # NEW
```

In `build_system_prompt()`, inject memory just before the footer:

```python
if options.memory_content:
    sections.append(
        f"<!-- BEGIN AGENT MEMORY -->\n{options.memory_content}\n<!-- END AGENT MEMORY -->"
    )
```

**File: wherever `BuildSystemPromptOptions` is constructed** (agent_session.py):

```python
memory_content = None
if services.memory_backend:
    memory_content = services.memory_backend.build_developer_instructions(services.agent_dir)

opts = BuildSystemPromptOptions(
    ...,
    memory_content=memory_content,
)
```

---

## 4. `features/plan_mode` → Plan Mode with Approval

### What it adds

Wraps the agent in a plan mode where it produces a plan, waits for human
approval, then proceeds.  Injects a system prompt section; persists checkpoint.

### Integration steps

**File: `core/agent_session_services.py`**

```python
plan_mode_manager: Any | None = None   # add to AgentSessionServices
```

```python
# In create_agent_session_services():
try:
    from coding_agent.features.plan_mode.manager import PlanModeManager
    plan_mode_manager = PlanModeManager(agent_dir=agent_dir)
except ImportError:
    pass
```

**File: `core/system_prompt.py`**

```python
plan_mode_injection: str | None = None    # add to BuildSystemPromptOptions
```

In `build_system_prompt()`:

```python
if options.plan_mode_injection:
    sections.insert(1, options.plan_mode_injection)   # after base intro
```

**File: `core/slash_commands.py`**

Register `/plan approve` and `/plan reset` as built-in commands that call
`services.plan_mode_manager.approve_plan()` / `.reset()`.

**Activation** — expose `AgentSession.enable_plan_mode(True/False)` that
sets a flag; when True, `build_system_prompt()` picks up the plan injection:

```python
if self._plan_mode and services.plan_mode_manager:
    opts.plan_mode_injection = services.plan_mode_manager.get_system_prompt_injection()
```

---

## 5. `features/subagents` → Sub-Agent Registry

### What it adds

A registry of named agents (bundled + discovered from `.pi/agents/*.yaml`).
Provides `AgentRegistry` used by IRC, task delegation, and swarm.

### Integration steps

**File: `core/agent_session_services.py`**

```python
agent_registry: Any | None = None   # add to AgentSessionServices
```

```python
# In create_agent_session_services():
try:
    from coding_agent.features.subagents.registry import AgentRegistry
    from coding_agent.features.subagents.loader import load_agent_definitions, get_bundled_agents
    agent_registry = AgentRegistry()
    # Register bundled agents
    for defn in get_bundled_agents():
        agent_registry.register(defn, owner_id="system")
    # Load user-defined agents from .pi/agents/
    agents_dir = os.path.join(cwd, ".pi", "agents")
    if os.path.isdir(agents_dir):
        for defn in load_agent_definitions(agents_dir):
            agent_registry.register(defn, owner_id="user")
except ImportError:
    pass
```

No changes to other files needed for this feature — it becomes available
via `services.agent_registry`.

---

## 6. `features/background` → Background Job Manager

### What it adds

`AsyncJobManager` — tracks long-running asyncio tasks with status + result.
Useful for swarm runs, background sub-agent calls, etc.

### Integration steps

**File: `core/agent_session_services.py`**

```python
background_jobs: Any | None = None   # add to AgentSessionServices
```

```python
# In create_agent_session_services():
try:
    from coding_agent.features.background.manager import AsyncJobManager
    background_jobs = AsyncJobManager()
except ImportError:
    pass
```

**File: `core/slash_commands.py`** — Add `/jobs` slash command:

```python
("jobs", "List background job status", "show_jobs"),
```

The TUI handler calls `services.background_jobs.list_jobs()` and formats output.

---

## 7. `features/task_delegation` → Task Fan-Out

### What it adds

`TaskDelegator` — runs tasks as sub-processes calling `coding_agent.main`.

### Integration steps

**File: `core/agent_session_services.py`**

```python
task_delegator: Any | None = None
```

```python
# In create_agent_session_services():
try:
    from coding_agent.features.task_delegation.executor import TaskDelegator
    task_delegator = TaskDelegator(cwd=cwd, model=None)  # model resolved at call time
except ImportError:
    pass
```

**File: `core/tools/registry.py` — `build_tools()`**

Add optional `task_delegator` parameter.  When present, register a
`dispatch_agent` tool:

```python
if task_delegator is not None:
    tools.append(_make_dispatch_agent_tool(task_delegator))
```

```python
def _make_dispatch_agent_tool(delegator) -> dict:
    async def _exec(params):
        tasks = params.get("tasks", [])
        parallel = params.get("parallel", False)
        results = await delegator.run_tasks(tasks, parallel=parallel)
        lines = [f"[{r.label}] exit={r.exit_code}\n{r.output}" for r in results]
        return [{"type": "text", "text": "\n---\n".join(lines)}]
    return {
        "name": "dispatch_agent",
        "label": "Dispatch Agent",
        "description": "Delegate tasks to sub-agents running in separate processes",
        "parameters": {
            "type": "object",
            "properties": {
                "tasks": {
                    "type": "array",
                    "items": {"type": "object",
                              "properties": {"label": {"type": "string"},
                                             "task": {"type": "string"},
                                             "system_prompt": {"type": "string"}}},
                },
                "parallel": {"type": "boolean", "default": False},
            },
            "required": ["tasks"],
        },
        "_execute_raw": _exec,
    }
```

---

## 8. `features/irc` → Agent-to-Agent Messaging Tool

### What it adds

`IRCTool` — lets agents send messages to other agents in the same process.

### Integration steps

**File: `core/agent_session_services.py`**

```python
irc_manager: Any | None = None
```

```python
# In create_agent_session_services():
try:
    from coding_agent.features.irc.manager import IRCManager
    irc_manager = IRCManager()
except ImportError:
    pass
```

**File: `core/tools/registry.py` — `build_tools()`**

```python
if irc_manager is not None:
    from coding_agent.features.irc.tool import IRCTool
    agent_name = kwargs.get("agent_name", "default")
    irc_manager.register(agent_name)
    tools.append(_wrap_feature_tool(IRCTool(irc_manager, agent_name)))
```

**Helper** — add `_wrap_feature_tool(tool)` to registry.py to convert the
`tool.schema` / `tool.execute` protocol into the existing `_to_agent_tool`
format:

```python
def _wrap_feature_tool(tool) -> dict:
    """Convert a features tool (with .schema and .execute) to registry format."""
    schema = tool.schema
    async def _exec(params):
        result = await tool.execute(params)
        return [{"type": "text", "text": str(result)}]
    return {
        "name": schema["name"],
        "label": schema.get("label", schema["name"]),
        "description": schema["description"],
        "parameters": schema["input_schema"],
        "_execute_raw": _exec,
    }
```

> **Note**: `_wrap_feature_tool` is reusable for Todo, SSH, and Browser tools below.

---

## 9. `features/todo` → Task List Tool

### Integration steps

**File: `core/agent_session_services.py`**

```python
todo_manager: Any | None = None
```

```python
# In create_agent_session_services():
try:
    from coding_agent.features.todo.manager import TodoManager
    todo_manager = TodoManager()
    # Optionally load persisted state from agent_dir
    todo_path = os.path.join(agent_dir, "todo.md")
    if os.path.exists(todo_path):
        todo_manager.load_markdown(open(todo_path).read())
except ImportError:
    pass
```

**File: `core/tools/registry.py` — `build_tools()`**

```python
if todo_manager is not None:
    from coding_agent.features.todo.tool import TodoTool
    tools.append(_wrap_feature_tool(TodoTool(todo_manager)))
```

**Persistence** — in `AgentSessionRuntime.dispose()`:

```python
if services.todo_manager:
    todo_path = os.path.join(services.agent_dir, "todo.md")
    with open(todo_path, "w") as f:
        f.write(services.todo_manager.to_markdown())
```

---

## 10. `features/ssh` → SSH Remote Execution Tool

### Integration steps

**File: `core/agent_session_services.py`**

```python
ssh_registry: Any | None = None
```

```python
# In create_agent_session_services():
try:
    from coding_agent.features.ssh.registry import SSHHostRegistry
    ssh_registry = SSHHostRegistry()
    ssh_registry.load_ssh_config()   # ~/.ssh/config
    yaml_path = os.path.join(cwd, ".pi", "ssh-hosts.yaml")
    if os.path.exists(yaml_path):
        ssh_registry.load_yaml(yaml_path)
except ImportError:
    pass
```

**File: `core/tools/registry.py` — `build_tools()`**

```python
if ssh_registry is not None and len(ssh_registry) > 0:
    from coding_agent.features.ssh.tool import SSHTool
    tools.append(_wrap_feature_tool(SSHTool(ssh_registry)))
```

The `SSHTool` only registers when at least one host is discovered,
so it silently disappears for users without SSH hosts configured.

---

## 11. `features/browser` → Browser Tool

### Integration steps

**File: `core/tools/registry.py` — `build_tools()`**

```python
# Browser tool requires no session-level state — check availability at build time
try:
    from coding_agent.features.browser.session import BrowserSession
    if BrowserSession.is_available():
        tools.append(_make_browser_tool())
except ImportError:
    pass
```

```python
def _make_browser_tool() -> dict:
    from coding_agent.features.browser.session import BrowserSession
    session = BrowserSession()
    async def _exec(params):
        script = params.get("script", "")
        result = await session.run_harness(script)
        return [{"type": "text", "text": result}]
    return {
        "name": "browser",
        "label": "Browser",
        "description": "Execute browser-harness Python scripts in the user's Chrome browser",
        "parameters": {
            "type": "object",
            "properties": {
                "script": {"type": "string", "description": "Python script using browser-harness helpers"},
            },
            "required": ["script"],
        },
        "_execute_raw": _exec,
    }
```

---

## 12. `features/swarm` → Multi-Agent Pipeline (`/swarm`)

### What it adds

`/swarm run pipeline.yaml` and `/swarm status <name>` slash commands.
No new tools; the swarm runs as a self-contained process tree.

### Integration steps

**File: `core/agent_session_services.py`**

No new fields needed — swarm runs entirely through the extension slash command.

**Extension file** — create `.pi/extensions/swarm_ext.py` in the user's project
(or install it globally):

```python
from coding_agent.features.swarm.extension import setup
```

The `ExtensionLoader` will discover and load it, registering `/swarm` via the
extension runner already wired in step 1.

**Alternatively** — register it programmatically in `create_agent_session_services()`:

```python
if extension_runner is not None:
    try:
        from coding_agent.features.swarm.extension import setup
        from coding_agent.features.extensions.api import HookAPI
        hook_api = HookAPI(extension_runner)
        setup(hook_api)
    except ImportError:
        pass
```

**Slash command** — add to `core/slash_commands.py` `_BUILTIN` list so it
appears in TUI autocomplete even before extensions load:

```python
("swarm", "Run or inspect a multi-agent pipeline  /swarm run <file.yaml>", "swarm"),
```

---

## Putting It All Together

### Minimal wiring (~50 lines)

The minimum integration — MCP tools + Todo + SSH — requires only changes to
two files:

1. **`core/agent_session_services.py`** — add optional fields + init logic in
   `create_agent_session_services()`
2. **`core/tools/registry.py`** — add `_wrap_feature_tool()` helper and call it
   for each feature tool, guarded by `if feature_is_available and feature_object`

### Recommended `create_agent_session_services()` signature

```python
async def create_agent_session_services(
    cwd: str | None = None,
    agent_dir: str | None = None,
    settings_overrides: dict | None = None,
    # Feature flags — all default to True (auto-enabled when available)
    enable_mcp: bool = True,
    enable_extensions: bool = True,
    enable_memory: bool = True,
    enable_ssh: bool = True,
    enable_todo: bool = True,
    enable_browser: bool = True,
    enable_subagents: bool = True,
    enable_background: bool = True,
    enable_irc: bool = False,       # opt-in: only useful in multi-agent scenarios
    extensions_dirs: list[str] | None = None,
) -> AgentSessionServices:
```

Each flag can also be read from `settings_manager` / env vars for full
runtime control.

### Recommended `build_tools()` signature

```python
def build_tools(
    cwd: str,
    settings,
    active_names: list[str] | None = None,
    custom_tools: list | None = None,
    # Feature objects from AgentSessionServices
    mcp_manager=None,
    ssh_registry=None,
    todo_manager=None,
    task_delegator=None,
    irc_manager=None,
    agent_name: str = "default",
) -> list:
```

---

## Testing Each Feature in Isolation

Each feature can be tested without the full agent stack:

```python
# Test MCP
from coding_agent.features.mcp.manager import MCPManager
mgr = MCPManager(cwd=".")
result = await mgr.connect_servers({"my-server": config})
print([t.name for t in mgr.get_tools()])

# Test Todo
from coding_agent.features.todo import TodoManager, TodoTool
mgr = TodoManager()
tool = TodoTool(mgr)
print(await tool.execute({"op": "init", "phases": [{"name": "A", "tasks": ["t1"]}]}))

# Test SSH
from coding_agent.features.ssh import SSHHostRegistry, SSHTool
registry = SSHHostRegistry()
registry.load_ssh_config()
tool = SSHTool(registry)
print(await tool.execute({"host": "myserver", "command": "hostname"}))

# Test Swarm
from coding_agent.features.swarm import run_swarm_file
result, state = await run_swarm_file("pipeline.yaml", cwd=".")
print(result.status)
```

---

## Commit Sequence

Suggested git commits, each independently reviewable and revertable:

```
feat(features): add extension system (loader, hook runner, api)
feat(features): add MCP integration (transports, manager, tool bridge)
feat(features): add memory backend (local .memory.md injection)
feat(features): add plan mode manager (approval checkpoint)
feat(features): add sub-agent registry and YAML loader
feat(features): add background job manager
feat(features): add task delegation executor
feat(features): add IRC in-process agent messaging
feat(features): add todo phase-based task list tool
feat(features): add SSH remote command execution tool
feat(features): add browser harness tool wrapper
feat(features): add swarm multi-agent pipeline orchestration
feat(core): wire feature tools into AgentSessionServices + build_tools
feat(core): wire extension hooks into tool call lifecycle
feat(core): wire memory + plan_mode into system prompt builder
```
