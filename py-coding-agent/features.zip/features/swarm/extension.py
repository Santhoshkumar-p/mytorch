"""
Swarm slash-command extension.

Registers the ``/swarm`` command so users can run and inspect swarm pipelines
directly from the agent chat interface.  Wire this into the extension system
via the standard :class:`~coding_agent.features.extensions.loader.ExtensionLoader`.

Commands
--------
``/swarm run <path/to/pipeline.yaml>``
    Parse, validate, and execute a swarm pipeline.  Progress is printed
    incrementally.  A Markdown summary is injected into the conversation
    so the LLM sees what happened.

``/swarm status <name>``
    Load and display the persisted state of a named swarm pipeline from
    the current working directory.

``/swarm help``
    Print usage information.

Extension entry point
---------------------
The module exports a ``setup(pi)`` function compatible with the extension
loader::

    # .pi/extensions/swarm_ext.py
    from coding_agent.features.swarm.extension import setup
"""

from __future__ import annotations

import asyncio
import os


# ---------------------------------------------------------------------------
# Extension entry point
# ---------------------------------------------------------------------------

def setup(pi: object) -> None:
    """
    Register the ``/swarm`` slash command.

    Called automatically by :class:`~coding_agent.features.extensions.loader.ExtensionLoader`
    when this module is discovered.

    :param pi: :class:`~coding_agent.features.extensions.api.HookAPI` or
               :class:`~coding_agent.features.extensions.api.ExtensionAPI` instance.
    """
    # pi.register_command uses a duck-typed API regardless of whether the
    # caller is using HookAPI or ExtensionAPI.
    pi.register_command(  # type: ignore[attr-defined]
        "swarm",
        description="Run or inspect a multi-agent swarm pipeline",
        handler=_swarm_handler,
    )


# ---------------------------------------------------------------------------
# Command handler
# ---------------------------------------------------------------------------

async def _swarm_handler(args: str, ctx: object) -> None:
    """Dispatch /swarm subcommands."""
    parts = args.strip().split(maxsplit=1)
    subcommand = parts[0] if parts else "help"
    rest = parts[1] if len(parts) > 1 else ""

    if subcommand == "run":
        await _handle_run(rest.strip(), ctx)
    elif subcommand == "status":
        await _handle_status(rest.strip(), ctx)
    else:
        _handle_help(ctx)


# ---------------------------------------------------------------------------
# /swarm run
# ---------------------------------------------------------------------------

async def _handle_run(yaml_path: str, ctx: object) -> None:
    """Execute a swarm pipeline from a YAML file."""
    from .runner import run_swarm_file
    from .render import render_swarm_progress

    if not yaml_path:
        _notify(ctx, "Usage: /swarm run <path/to/pipeline.yaml>", kind="error")
        return

    cwd: str = getattr(ctx, "cwd", os.getcwd())
    resolved = yaml_path if os.path.isabs(yaml_path) else os.path.join(cwd, yaml_path)

    if not os.path.exists(resolved):
        _notify(ctx, f"File not found: {resolved}", kind="error")
        return

    def _on_progress(progress: object) -> None:
        # Print progress lines to stdout (visible in print mode / logs)
        from .state import SwarmState  # avoid top-level circular
        if hasattr(progress, "agents"):
            lines = render_swarm_progress(_progress_to_state(progress))
            print("\n".join(lines))

    try:
        result, state = await run_swarm_file(
            yaml_path=resolved,
            cwd=cwd,
            on_progress=_on_progress,
        )
    except (ValueError, RuntimeError, FileNotFoundError, ImportError) as exc:
        _notify(ctx, f"Swarm error: {exc}", kind="error")
        return

    # Build final summary
    from .render import render_swarm_summary
    workspace = getattr(state, "name", "")
    summary_md = render_swarm_summary(state, cwd, result.errors)

    # Inject summary into conversation (if send_message is available)
    if hasattr(pi := _get_pi(ctx), "send_message"):
        pi.send_message(
            {
                "customType": "swarm-result",
                "content": [{"type": "text", "text": summary_md}],
                "display": True,
                "details": {
                    "swarmName": state.name,
                    "status": result.status,
                    "iterations": result.iterations,
                    "errorCount": len(result.errors),
                },
            },
            {"triggerTurn": False},
        )
    else:
        # Fallback: print summary
        print(summary_md)

    kind = "info" if result.status == "completed" else "error"
    msg = (
        f"Swarm '{state.name}' {result.status} | "
        f"{result.iterations}/{state.target_count} iterations"
    )
    if result.errors:
        msg += f" | {len(result.errors)} error(s)"
    _notify(ctx, msg, kind=kind)


# ---------------------------------------------------------------------------
# /swarm status
# ---------------------------------------------------------------------------

async def _handle_status(name: str, ctx: object) -> None:
    """Display the persisted status of a named swarm."""
    from .runner import load_swarm_status
    from .render import render_swarm_progress

    if not name:
        _notify(
            ctx,
            "Usage: /swarm status <name>  "
            "(reads .swarm_<name>/state/pipeline.json from cwd)",
            kind="info",
        )
        return

    cwd: str = getattr(ctx, "cwd", os.getcwd())
    state = load_swarm_status(name, cwd)
    if state is None:
        _notify(ctx, f"No state found for swarm '{name}' in {cwd}", kind="error")
        return

    lines = render_swarm_progress(state)
    _notify(ctx, "\n".join(lines), kind="info")


# ---------------------------------------------------------------------------
# /swarm help
# ---------------------------------------------------------------------------

def _handle_help(ctx: object) -> None:
    msg = "\n".join([
        "Swarm — multi-agent pipeline orchestrator",
        "",
        "  /swarm run <file.yaml>     Execute a pipeline",
        "  /swarm status <name>       Show persisted pipeline state",
        "  /swarm help                Show this help",
    ])
    _notify(ctx, msg, kind="info")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _notify(ctx: object, message: str, *, kind: str = "info") -> None:
    """Send a notification through the context UI if available, else print."""
    ui = getattr(ctx, "ui", None)
    if ui is not None and hasattr(ui, "notify"):
        ui.notify(message, kind)
    else:
        prefix = {"error": "ERROR", "info": "INFO"}.get(kind, kind.upper())
        print(f"[swarm/{prefix}] {message}")


def _get_pi(ctx: object) -> object:
    """Extract the ExtensionAPI from context (stored as _pi by the runner)."""
    return getattr(ctx, "_pi", None) or ctx


def _progress_to_state(progress: object) -> object:
    """
    Convert a PipelineProgress to a minimal SwarmState-like object for rendering.

    This avoids importing SwarmState at module level to prevent circular deps.
    """
    from .state import AgentState, SwarmState

    agents = {}
    for name, status in (getattr(progress, "agents", None) or {}).items():
        agents[name] = AgentState(name=name, status=status)  # type: ignore[arg-type]

    state = SwarmState(name="")
    state.iteration = getattr(progress, "iteration", 0)
    state.target_count = getattr(progress, "target_count", 1)
    state.agents = agents
    return state
