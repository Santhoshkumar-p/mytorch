"""
Swarm agent execution.

Spawns individual swarm agents as subprocesses using the existing
``coding_agent.main`` CLI, capturing their output and updating the
state tracker.

Each agent gets:
- A system prompt built from its ``role`` + optional ``extra_context``
- Its ``task`` as the user prompt (passed via ``--task``)
- The swarm workspace as its working directory
- An optional model override (per-agent or swarm-level)
"""

from __future__ import annotations

import asyncio
import os
import sys
import time
from dataclasses import dataclass, field
from typing import Callable

from .schema import SwarmAgent, SwarmDefinition
from .state import StateTracker


# ---------------------------------------------------------------------------
# Result type
# ---------------------------------------------------------------------------

@dataclass
class AgentResult:
    """Result of a single swarm agent execution."""

    agent_name: str
    index: int
    exit_code: int
    output: str
    stderr: str
    duration_ms: float
    error: str | None = None
    aborted: bool = False


# ---------------------------------------------------------------------------
# Options
# ---------------------------------------------------------------------------

@dataclass
class SwarmExecutorOptions:
    """Options passed to :func:`execute_swarm_agent`."""

    workspace: str
    swarm_name: str
    iteration: int
    state_tracker: StateTracker
    model_override: str | None = None
    signal: asyncio.Event | None = None          # set to abort
    on_progress: Callable[[str, str], None] | None = None   # (agent_name, status)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

async def execute_swarm_agent(
    agent: SwarmAgent,
    index: int,
    options: SwarmExecutorOptions,
) -> AgentResult:
    """
    Execute a single swarm agent as a subprocess.

    The subprocess runs ``python -m coding_agent.main`` with:
    - ``--system-prompt`` built from role + extra_context
    - ``--task`` set to the agent's task text
    - ``--cwd`` set to the swarm workspace
    - ``--model`` if a model override is specified

    Returns an :class:`AgentResult`.
    """
    tracker = options.state_tracker
    tracker.update_agent(
        agent.name,
        status="running",
        iteration=options.iteration,
        started_at=time.time(),
    )
    tracker.append_log(agent.name, f"Starting iteration {options.iteration}")
    options.on_progress and options.on_progress(agent.name, "running")

    system_prompt = _build_system_prompt(agent)
    model = agent.model or options.model_override

    cmd = _build_command(
        task=agent.task,
        system_prompt=system_prompt,
        cwd=options.workspace,
        model=model,
    )

    start = time.time()
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            cwd=options.workspace,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        # Stream stdout/stderr while optionally checking for abort
        stdout_chunks: list[bytes] = []
        stderr_chunks: list[bytes] = []

        async def _read_stdout() -> None:
            assert proc.stdout is not None
            async for line in proc.stdout:
                stdout_chunks.append(line)

        async def _read_stderr() -> None:
            assert proc.stderr is not None
            async for line in proc.stderr:
                stderr_chunks.append(line)

        await asyncio.gather(_read_stdout(), _read_stderr())
        await proc.wait()

        duration_ms = (time.time() - start) * 1000
        output = b"".join(stdout_chunks).decode("utf-8", errors="replace")
        stderr = b"".join(stderr_chunks).decode("utf-8", errors="replace")
        exit_code = proc.returncode or 0

        status = "completed" if exit_code == 0 else "failed"
        error = None if exit_code == 0 else f"exit code {exit_code}"

        tracker.update_agent(
            agent.name,
            status=status,
            completed_at=time.time(),
            error=error,
        )
        tracker.append_log(
            agent.name,
            f"Iteration {options.iteration} {status}"
            + (f": {error}" if error else ""),
        )
        options.on_progress and options.on_progress(agent.name, status)

        return AgentResult(
            agent_name=agent.name,
            index=index,
            exit_code=exit_code,
            output=output,
            stderr=stderr,
            duration_ms=duration_ms,
            error=error,
        )

    except Exception as exc:
        duration_ms = (time.time() - start) * 1000
        error_msg = str(exc)
        tracker.update_agent(
            agent.name,
            status="failed",
            completed_at=time.time(),
            error=error_msg,
        )
        tracker.append_log(agent.name, f"Iteration {options.iteration} error: {error_msg}")
        options.on_progress and options.on_progress(agent.name, "failed")

        return AgentResult(
            agent_name=agent.name,
            index=index,
            exit_code=1,
            output="",
            stderr=error_msg,
            duration_ms=duration_ms,
            error=error_msg,
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _build_system_prompt(agent: SwarmAgent) -> str:
    parts = [f"You are a {agent.role}."]
    if agent.extra_context:
        parts.append(agent.extra_context)
    return "\n\n".join(parts)


def _build_command(
    task: str,
    system_prompt: str,
    cwd: str,
    model: str | None,
) -> list[str]:
    """Build the subprocess command for a swarm agent."""
    cmd = [
        sys.executable,
        "-m", "coding_agent.main",
        "--print",           # non-interactive print mode
        "--task", task,
        "--system-prompt", system_prompt,
        "--cwd", cwd,
    ]
    if model:
        cmd += ["--model", model]
    return cmd
