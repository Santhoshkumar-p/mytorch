"""
Top-level swarm orchestration entry point.

:func:`run_swarm_file` is the main public function.  It:

1. Reads and parses the YAML file.
2. Validates the definition (semantic checks).
3. Builds the dependency graph and execution waves.
4. Detects cycles and raises if found.
5. Resolves the workspace path.
6. Initialises the :class:`StateTracker`.
7. Runs the pipeline via :class:`PipelineController`.
8. Returns the :class:`PipelineResult` and the final :class:`SwarmState`.

All lower-level modules (schema, dag, state, pipeline) are intentionally kept
thin so they can be tested independently.

Usage::

    import asyncio
    from coding_agent.features.swarm import run_swarm_file

    result, state = asyncio.run(
        run_swarm_file("/path/to/pipeline.yaml", cwd="/my/project")
    )
    print(result.status)          # "completed" | "failed" | "aborted"
    print(result.errors)          # list of error strings
"""

from __future__ import annotations

import os
from typing import Callable

from .dag import build_dependency_graph, build_execution_waves, detect_cycles
from .pipeline import OnProgress, PipelineController, PipelineResult
from .render import render_swarm_progress, render_swarm_summary
from .schema import SwarmDefinition, parse_swarm_yaml, validate_swarm_definition
from .state import StateTracker, SwarmState


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

async def run_swarm_file(
    yaml_path: str,
    *,
    cwd: str | None = None,
    on_progress: OnProgress | None = None,
    model_override: str | None = None,
) -> tuple[PipelineResult, SwarmState]:
    """
    Parse, validate, and execute a swarm YAML pipeline file.

    :param yaml_path:      Path to the ``.yaml`` swarm definition
                           (absolute, or relative to *cwd*).
    :param cwd:            Working directory used to resolve relative paths
                           (defaults to ``os.getcwd()``).
    :param on_progress:    Optional progress callback fired after each wave.
    :param model_override: Global model override (per-agent model wins).
    :returns:              ``(PipelineResult, final SwarmState)`` tuple.
    :raises ValueError:    On YAML parse errors or validation failures.
    :raises RuntimeError:  If a cycle is detected in the dependency graph.
    :raises FileNotFoundError: If the YAML file does not exist.
    """
    base = cwd or os.getcwd()
    resolved_path = os.path.join(base, yaml_path) if not os.path.isabs(yaml_path) else yaml_path

    # 1. Read YAML
    with open(resolved_path, encoding="utf-8") as fh:
        content = fh.read()

    # 2. Parse
    definition = parse_swarm_yaml(content)

    # 3. Validate
    errors = validate_swarm_definition(definition)
    if errors:
        raise ValueError(
            f"Swarm definition '{definition.name}' has validation errors:\n"
            + "\n".join(f"  - {e}" for e in errors)
        )

    # 4. DAG + cycle detection
    deps = build_dependency_graph(definition)
    cycle_nodes = detect_cycles(deps)
    if cycle_nodes:
        raise RuntimeError(
            f"Cycle detected in agent dependencies: [{', '.join(cycle_nodes)}]"
        )
    waves = build_execution_waves(deps)

    # 5. Workspace resolution (relative to YAML file location)
    yaml_dir = os.path.dirname(resolved_path)
    workspace = (
        definition.workspace
        if os.path.isabs(definition.workspace)
        else os.path.normpath(os.path.join(yaml_dir, definition.workspace))
    )
    os.makedirs(workspace, exist_ok=True)

    # 6. State tracker
    tracker = StateTracker(workspace, definition.name)
    tracker.init(list(definition.agents.keys()), definition.target_count, definition.mode)

    agent_list = ", ".join(definition.agents.keys())
    wave_desc = "; ".join(
        f"wave {i + 1}: [{', '.join(w)}]" for i, w in enumerate(waves)
    )
    tracker.append_orchestrator_log(
        f"Loaded: {definition.name} | agents: {agent_list} | {wave_desc}"
    )

    # 7. Run pipeline
    controller = PipelineController(definition, waves, tracker)
    result = await controller.run(
        workspace=workspace,
        on_progress=on_progress,
        model_override=model_override or definition.model,
    )

    return result, tracker.state


def load_swarm_status(name: str, workspace: str) -> SwarmState | None:
    """
    Load persisted swarm state from disk without running the pipeline.

    Useful for the ``/swarm status`` command.

    :param name:      Swarm name (used to locate ``.swarm_<name>/``).
    :param workspace: Directory containing the ``.swarm_<name>/`` folder.
    :returns:         :class:`SwarmState` or ``None`` if not found.
    """
    tracker = StateTracker(workspace, name)
    return tracker.load()


def render_status(state: SwarmState) -> str:
    """Return a plain-text progress report for a :class:`SwarmState`."""
    return "\n".join(render_swarm_progress(state))


def render_summary(state: SwarmState, workspace: str, errors: list[str]) -> str:
    """Return a Markdown summary suitable for injection into the LLM conversation."""
    return render_swarm_summary(state, workspace, errors)
