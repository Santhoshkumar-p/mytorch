"""
Filesystem state tracker for swarm pipeline execution.

Persists pipeline and per-agent state to ``.swarm_<name>/`` inside the
workspace directory.  The JSON state file makes pipelines *resumable*: a
crashed or interrupted run can be inspected and replayed from its last
checkpoint.

Directory layout::

    <workspace>/
      .swarm_<name>/
        state/
          pipeline.json   ← full SwarmState snapshot (overwritten on every change)
        logs/
          orchestrator.log
          <agent-name>.log
        context/          ← optional artefact directory for inter-agent files
"""

from __future__ import annotations

import json
import os
import time
from dataclasses import asdict, dataclass, field
from typing import Literal

# ---------------------------------------------------------------------------
# State types
# ---------------------------------------------------------------------------

PipelineStatus = Literal["idle", "running", "completed", "failed", "aborted"]
AgentStatus = Literal["pending", "waiting", "running", "completed", "failed"]


@dataclass
class AgentState:
    """Mutable runtime state for a single swarm agent."""

    name: str
    status: AgentStatus = "pending"
    iteration: int = 0
    wave: int = 0
    started_at: float | None = None
    completed_at: float | None = None
    error: str | None = None


@dataclass
class SwarmState:
    """Top-level swarm pipeline state, persisted to disk on every mutation."""

    name: str
    status: PipelineStatus = "idle"
    mode: str = "sequential"
    iteration: int = 0
    target_count: int = 1
    agents: dict[str, AgentState] = field(default_factory=dict)
    started_at: float = field(default_factory=time.time)
    completed_at: float | None = None


# ---------------------------------------------------------------------------
# State tracker
# ---------------------------------------------------------------------------

class StateTracker:
    """
    Manages on-disk state for a running swarm pipeline.

    Each public mutation method immediately persists the full state to
    ``state/pipeline.json`` so the run can be inspected live and resumed
    after a crash.
    """

    def __init__(self, workspace_dir: str, name: str) -> None:
        self._swarm_dir = os.path.join(workspace_dir, f".swarm_{name}")
        self._state = SwarmState(name=name)

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def swarm_dir(self) -> str:
        """Absolute path to the ``.swarm_<name>/`` directory."""
        return self._swarm_dir

    @property
    def state(self) -> SwarmState:
        """Current pipeline state (read-only snapshot)."""
        return self._state

    # ------------------------------------------------------------------
    # Initialisation
    # ------------------------------------------------------------------

    def init(
        self,
        agent_names: list[str],
        target_count: int,
        mode: str,
    ) -> None:
        """
        Create the state directory tree and initialise per-agent state.

        Call once before starting a pipeline run.
        """
        os.makedirs(os.path.join(self._swarm_dir, "state"), exist_ok=True)
        os.makedirs(os.path.join(self._swarm_dir, "logs"), exist_ok=True)
        os.makedirs(os.path.join(self._swarm_dir, "context"), exist_ok=True)

        self._state.target_count = target_count
        self._state.mode = mode
        self._state.status = "running"
        self._state.started_at = time.time()

        for name in agent_names:
            self._state.agents[name] = AgentState(name=name)

        self._persist()

    # ------------------------------------------------------------------
    # Mutation
    # ------------------------------------------------------------------

    def update_agent(self, name: str, **kwargs: object) -> None:
        """Update fields on a named agent's state and persist."""
        agent = self._state.agents.get(name)
        if agent is None:
            return
        for key, value in kwargs.items():
            setattr(agent, key, value)
        self._persist()

    def update_pipeline(self, **kwargs: object) -> None:
        """Update top-level pipeline fields and persist."""
        for key, value in kwargs.items():
            setattr(self._state, key, value)
        self._persist()

    # ------------------------------------------------------------------
    # Logging
    # ------------------------------------------------------------------

    def append_log(self, agent_name: str, message: str) -> None:
        """Append a timestamped line to an agent's log file."""
        log_path = os.path.join(self._swarm_dir, "logs", f"{agent_name}.log")
        timestamp = time.strftime("%Y-%m-%dT%H:%M:%S")
        with open(log_path, "a", encoding="utf-8") as fh:
            fh.write(f"[{timestamp}] {message}\n")

    def append_orchestrator_log(self, message: str) -> None:
        """Append a timestamped line to the orchestrator log file."""
        log_path = os.path.join(self._swarm_dir, "logs", "orchestrator.log")
        timestamp = time.strftime("%Y-%m-%dT%H:%M:%S")
        with open(log_path, "a", encoding="utf-8") as fh:
            fh.write(f"[{timestamp}] {message}\n")

    # ------------------------------------------------------------------
    # Persistence / resume
    # ------------------------------------------------------------------

    def load(self) -> SwarmState | None:
        """
        Load state from disk.

        Returns the loaded :class:`SwarmState` or ``None`` if no state file
        exists yet.
        """
        state_path = os.path.join(self._swarm_dir, "state", "pipeline.json")
        try:
            with open(state_path, encoding="utf-8") as fh:
                data = json.load(fh)
            agents = {
                k: AgentState(**v)
                for k, v in data.pop("agents", {}).items()
            }
            self._state = SwarmState(agents=agents, **data)
            return self._state
        except (FileNotFoundError, json.JSONDecodeError, TypeError):
            return None

    def _persist(self) -> None:
        """Write full state snapshot to disk (atomic-ish via rename)."""
        state_path = os.path.join(self._swarm_dir, "state", "pipeline.json")
        tmp_path = state_path + ".tmp"

        # Serialise: convert AgentState objects to dicts
        data = asdict(self._state)

        with open(tmp_path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2)

        os.replace(tmp_path, state_path)
