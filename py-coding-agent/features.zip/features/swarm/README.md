# Swarm Extension

Python port of the TypeScript swarm extension from
`packages/oh-my-pi/packages/swarm-extension/`.

---

## Plan

Port the multi-agent swarm pipeline orchestration system to a self-contained,
liftable Python package that:

- Reads YAML pipeline definitions with a `swarm:` top-level key.
- Builds a dependency DAG from `waits_for` / `reports_to` relationships.
- Detects dependency cycles before execution starts.
- Computes **execution waves** — groups of agents that have no dependencies on
  each other and can run in parallel within a wave.
- Runs waves sequentially, agents within each wave concurrently.
- Repeats the full DAG execution N times for pipeline mode.
- Persists state to disk on every mutation (resumable, inspectable).
- Integrates with the extension slash-command system as `/swarm`.

---

## Integration Architecture

### Option A — Standalone (no extension system)

```python
import asyncio
from coding_agent.features.swarm import run_swarm_file

result, state = asyncio.run(
    run_swarm_file("pipeline.yaml", cwd="/my/project")
)
print(result.status)   # "completed" | "failed"
print(result.errors)   # list[str]
```

### Option B — Extension slash command

Create a file in your extensions directory (e.g. `.pi/extensions/swarm_ext.py`):

```python
from coding_agent.features.swarm.extension import setup
# The loader calls setup(pi) automatically.
```

Then load it via `ExtensionLoader`:

```python
from coding_agent.features.extensions import ExtensionLoader, ExtensionRunner

loader = ExtensionLoader(extensions_dirs=[".pi/extensions"], cwd=".")
result = loader.load_all()
runner = ExtensionRunner(extensions=result.extensions)
```

Users can then run `/swarm run pipeline.yaml` from the chat interface.

### Option C — Wiring into AgentSessionServices

Add a `swarm_runner` field to `AgentSessionServices`, and register the
`/swarm` command in the session's slash-command registry at startup:

```python
# coding_agent/core/agent_session_services.py
from coding_agent.features.swarm.extension import setup as swarm_setup

@dataclass
class AgentSessionServices:
    ...
    def register_swarm_commands(self, slash_cmd_registry):
        # creates a minimal pi-like object and calls setup(pi)
        swarm_setup(slash_cmd_registry.get_hook_api())
```

---

## What Was Implemented

| File | Purpose |
|---|---|
| `schema.py` | `parse_swarm_yaml()` — reads YAML via PyYAML, normalises to `SwarmDefinition` + `SwarmAgent` dataclasses. `validate_swarm_definition()` — semantic checks (unknown refs, self-loops, target_count constraints). |
| `dag.py` | `build_dependency_graph()` — merges `waits_for`, `reports_to`, implicit chain. `detect_cycles()` — Kahn's algorithm; returns cycle participants or None. `build_execution_waves()` — topological sort producing `list[list[str]]`. |
| `state.py` | `StateTracker` — owns `.swarm_<name>/state/pipeline.json`, logs dirs, context dir. Atomic write via `os.replace`. `load()` — deserialises from disk for `/swarm status`. |
| `render.py` | `render_swarm_progress()` — list of text lines (icon + name + status + duration). `render_swarm_summary()` — Markdown summary for LLM context injection. |
| `executor.py` | `execute_swarm_agent()` — async subprocess runner; builds `coding_agent.main --print --task … --system-prompt …` command; streams stdout/stderr; updates state tracker. |
| `pipeline.py` | `PipelineController` — wave-by-wave execution with `asyncio.gather` per wave; iteration loop; progress callbacks; captures per-agent results and errors. |
| `runner.py` | `run_swarm_file()` — top-level orchestration: parse → validate → DAG → run → return `(PipelineResult, SwarmState)`. `load_swarm_status()` — read persisted state without running. |
| `extension.py` | `setup(pi)` — extension entry point registering `/swarm run` and `/swarm status` slash commands. |
| `__init__.py` | Re-exports all public symbols. |

---

## YAML Format

```yaml
swarm:
  name: my-pipeline            # required; letters/digits/.-_ only
  workspace: ./workspace       # required; relative to this YAML file
  mode: pipeline               # pipeline | parallel | sequential  (default: sequential)
  target_count: 3              # iterations (pipeline mode only, default: 1)
  model: claude-sonnet-4       # optional default model for all agents

  agents:
    researcher:
      role: Research specialist
      task: |
        Search the web and gather current data about quantum computing
        advances in 2024. Write findings to context/research.md.
      extra_context: Focus on peer-reviewed sources and preprints.
      model: claude-opus-4     # per-agent override

    writer:
      role: Technical writer
      task: |
        Read context/research.md and write a clear 500-word summary
        suitable for a general audience. Save to context/summary.md.
      waits_for: [researcher]  # explicit dependency

    reviewer:
      role: Editor
      task: |
        Review context/summary.md for clarity and accuracy.
        Annotate any issues inline.
      reports_to: [writer]     # writer implicitly waits for reviewer
```

### Execution modes

| Mode | Behaviour |
|---|---|
| `sequential` | Agents run one-by-one in YAML order (implicit chain). |
| `parallel` | All agents run concurrently in a single wave (no deps). |
| `pipeline` | DAG waves repeat `target_count` times (e.g. iterative refinement). |

### Dependency resolution

1. **`waits_for: [A, B]`** — this agent starts only after A and B finish.
2. **`reports_to: [C]`** — agent C waits for this agent to finish.
3. **Implicit chain** (pipeline/sequential, no explicit deps) — agents are
   chained in YAML declaration order.

---

## Usage Example

```python
import asyncio
from coding_agent.features.swarm import run_swarm_file, render_status

async def main():
    result, state = await run_swarm_file(
        "pipeline.yaml",
        cwd="/my/project",
        on_progress=lambda p: print(f"Wave {p.current_wave}: {p.agents}"),
    )

    print(render_status(state))      # text progress table
    print(f"Status:  {result.status}")
    print(f"Errors:  {result.errors}")

asyncio.run(main())
```

### PyYAML dependency

Swarm YAML parsing requires [PyYAML](https://pypi.org/project/PyYAML/):

```bash
pip install pyyaml
```

A clear `ImportError` is raised at parse time (not import time) if PyYAML is
absent, so the rest of the codebase is unaffected.
