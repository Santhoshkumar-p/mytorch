"""
Swarm YAML schema — parse and validate swarm pipeline definitions.

YAML format::

    swarm:
      name: my-pipeline
      workspace: ./workspace
      mode: pipeline       # pipeline | parallel | sequential
      target_count: 3      # iterations (pipeline mode only)
      model: claude-opus-4 # optional default model override
      agents:
        researcher:
          role: Research specialist
          task: Search the web and gather data about X
          extra_context: Focus on peer-reviewed sources.
          model: claude-sonnet-4  # per-agent model override
        writer:
          role: Technical writer
          task: Write a clear summary of the researcher's findings
          waits_for: [researcher]
        reviewer:
          role: Code reviewer
          task: Review the writer's output for accuracy
          reports_to: [writer]   # writer waits for reviewer to finish

Dependencies
------------
``waits_for``  — agent A explicitly waits for the listed agents to finish.
``reports_to`` — agent A reports to agent B, so B waits for A.

In pipeline/sequential mode with no explicit deps, agents are chained in
YAML declaration order automatically.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Literal

# ---------------------------------------------------------------------------
# Normalised types
# ---------------------------------------------------------------------------

SwarmMode = Literal["pipeline", "parallel", "sequential"]

_VALID_MODES: frozenset[str] = frozenset({"pipeline", "parallel", "sequential"})
_VALID_NAME_RE = re.compile(r"^[a-zA-Z0-9._-]+$")


@dataclass
class SwarmAgent:
    """Normalised agent definition inside a swarm."""

    name: str
    role: str
    task: str
    extra_context: str | None = None
    reports_to: list[str] = field(default_factory=list)
    waits_for: list[str] = field(default_factory=list)
    model: str | None = None


@dataclass
class SwarmDefinition:
    """Fully-parsed and normalised swarm pipeline definition."""

    name: str
    workspace: str
    mode: SwarmMode
    target_count: int
    agents: dict[str, SwarmAgent]   # name → agent (insertion-ordered)
    agent_order: list[str]          # YAML declaration order
    model: str | None = None


# ---------------------------------------------------------------------------
# YAML parsing — optional PyYAML, fallback to stdlib json for .json files
# ---------------------------------------------------------------------------

def _load_yaml(content: str) -> object:
    """
    Parse YAML content.

    Tries ``yaml`` (PyYAML) first; raises ``ImportError`` with a clear message
    if unavailable so callers can surface a helpful error.
    """
    try:
        import yaml  # type: ignore[import]
        return yaml.safe_load(content)
    except ImportError:
        raise ImportError(
            "PyYAML is required for swarm YAML parsing. "
            "Install it with: pip install pyyaml"
        ) from None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def parse_swarm_yaml(content: str) -> SwarmDefinition:
    """
    Parse a swarm YAML string into a :class:`SwarmDefinition`.

    :raises ValueError: on structural/schema errors.
    :raises ImportError: if PyYAML is not installed.
    """
    raw = _load_yaml(content)
    if not isinstance(raw, dict) or "swarm" not in raw:
        raise ValueError("YAML must have a top-level 'swarm' key")

    swarm = raw["swarm"]
    if not isinstance(swarm, dict):
        raise ValueError("'swarm' must be a mapping")

    # --- name ---
    name = swarm.get("name")
    if not name or not isinstance(name, str):
        raise ValueError("swarm.name is required and must be a string")
    if not _VALID_NAME_RE.match(name):
        raise ValueError(
            "swarm.name may only contain letters, numbers, dot, underscore, and dash"
        )

    # --- workspace ---
    workspace = swarm.get("workspace")
    if not workspace or not isinstance(workspace, str):
        raise ValueError("swarm.workspace is required and must be a string")

    # --- mode ---
    mode_raw = swarm.get("mode", "sequential")
    if mode_raw not in _VALID_MODES:
        raise ValueError(
            f"Invalid mode '{mode_raw}'. Must be one of: {', '.join(sorted(_VALID_MODES))}"
        )
    mode: SwarmMode = mode_raw  # type: ignore[assignment]

    # --- target_count ---
    target_count = swarm.get("target_count", 1)
    if not isinstance(target_count, int) or target_count < 1:
        raise ValueError("swarm.target_count must be a positive integer")

    # --- model ---
    model_raw = swarm.get("model")
    model: str | None = str(model_raw).strip() if model_raw is not None else None

    # --- agents ---
    raw_agents = swarm.get("agents")
    if not isinstance(raw_agents, dict) or len(raw_agents) == 0:
        raise ValueError("swarm.agents must contain at least one agent")

    agent_order: list[str] = []
    agents: dict[str, SwarmAgent] = {}

    for agent_name, cfg in raw_agents.items():
        if not isinstance(cfg, dict):
            raise ValueError(f"Agent '{agent_name}': config must be a mapping")

        role = cfg.get("role")
        if not role or not isinstance(role, str):
            raise ValueError(f"Agent '{agent_name}': 'role' is required")

        task = cfg.get("task")
        if not task or not isinstance(task, str):
            raise ValueError(f"Agent '{agent_name}': 'task' is required")

        extra_ctx_raw = cfg.get("extra_context")
        extra_context: str | None = str(extra_ctx_raw).strip() if extra_ctx_raw else None

        reports_to = cfg.get("reports_to") or []
        waits_for = cfg.get("waits_for") or []
        if isinstance(reports_to, str):
            reports_to = [reports_to]
        if isinstance(waits_for, str):
            waits_for = [waits_for]

        agent_model_raw = cfg.get("model")
        agent_model: str | None = str(agent_model_raw).strip() if agent_model_raw else None

        agent_order.append(agent_name)
        agents[agent_name] = SwarmAgent(
            name=agent_name,
            role=role,
            task=task.strip(),
            extra_context=extra_context,
            reports_to=list(reports_to),
            waits_for=list(waits_for),
            model=agent_model,
        )

    return SwarmDefinition(
        name=name,
        workspace=workspace,
        mode=mode,
        target_count=target_count,
        model=model,
        agents=agents,
        agent_order=agent_order,
    )


def validate_swarm_definition(definition: SwarmDefinition) -> list[str]:
    """
    Semantic validation of a parsed :class:`SwarmDefinition`.

    Returns a list of error strings (empty = valid).
    """
    errors: list[str] = []
    agent_names = set(definition.agents.keys())

    if definition.model is not None and len(definition.model) == 0:
        errors.append("swarm.model must not be empty when provided")

    for name, agent in definition.agents.items():
        for dep in agent.waits_for:
            if dep not in agent_names:
                errors.append(f"Agent '{name}' waits_for unknown agent '{dep}'")
            elif dep == name:
                errors.append(f"Agent '{name}' cannot wait for itself")

        for target in agent.reports_to:
            if target not in agent_names:
                errors.append(f"Agent '{name}' reports_to unknown agent '{target}'")
            elif target == name:
                errors.append(f"Agent '{name}' cannot report to itself")

        if agent.model is not None and len(agent.model) == 0:
            errors.append(f"Agent '{name}' model must not be empty when provided")

    if definition.target_count < 1:
        errors.append("target_count must be at least 1")

    if definition.mode != "pipeline" and definition.target_count != 1:
        errors.append("target_count > 1 is only supported in pipeline mode")

    return errors
