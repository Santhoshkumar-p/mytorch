"""
Pipeline controller for swarm execution.

Orchestrates wave-by-wave agent execution across one or more iterations:

- Agents **within the same wave** run in parallel (``asyncio.gather``).
- Waves run **sequentially** — wave N+1 only starts after every agent in wave N
  has completed (or failed with a captured error).
- In **pipeline mode** the full DAG execution repeats for ``target_count``
  iterations.
- In **parallel mode** all agents run in a single wave regardless of
  ``waits_for`` / ``reports_to`` (the DAG is flattened).
- In **sequential mode** agents run one-by-one in YAML declaration order.

Progress callbacks fire after each wave and after the overall pipeline
finishes, so callers can update a TUI widget or log incrementally.
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Callable

from .executor import AgentResult, SwarmExecutorOptions, execute_swarm_agent
from .schema import SwarmDefinition
from .state import StateTracker


# ---------------------------------------------------------------------------
# Public types
# ---------------------------------------------------------------------------

@dataclass
class PipelineProgress:
    """Snapshot of progress emitted after each wave."""

    iteration: int
    target_count: int
    current_wave: int
    total_waves: int
    agents: dict[str, str]   # name → status string


@dataclass
class PipelineResult:
    """Final outcome of a pipeline run."""

    status: str                              # "completed" | "failed" | "aborted"
    iterations: int
    agent_results: dict[str, list[AgentResult]]   # agent name → per-iteration results
    errors: list[str] = field(default_factory=list)


OnProgress = Callable[[PipelineProgress], None]


# ---------------------------------------------------------------------------
# Controller
# ---------------------------------------------------------------------------

class PipelineController:
    """
    Executes a :class:`SwarmDefinition` wave-by-wave.

    Instantiate once per run; call :meth:`run` to execute.
    """

    def __init__(
        self,
        definition: SwarmDefinition,
        waves: list[list[str]],
        state_tracker: StateTracker,
    ) -> None:
        self._def = definition
        self._waves = waves
        self._tracker = state_tracker

    async def run(
        self,
        workspace: str,
        *,
        on_progress: OnProgress | None = None,
        model_override: str | None = None,
    ) -> PipelineResult:
        """
        Execute the full pipeline.

        :param workspace:      Absolute path to the swarm workspace.
        :param on_progress:    Optional callback fired after each wave.
        :param model_override: Default model for agents with no per-agent model.
        :returns:              :class:`PipelineResult` with per-agent results.
        """
        all_results: dict[str, list[AgentResult]] = {
            name: [] for name in self._def.agents
        }
        errors: list[str] = []

        self._tracker.append_orchestrator_log(
            f"Pipeline '{self._def.name}' starting: "
            f"mode={self._def.mode} "
            f"iterations={self._def.target_count} "
            f"waves={len(self._waves)} "
            f"agents={len(self._def.agents)}"
        )

        try:
            for iteration in range(self._def.target_count):
                self._tracker.update_pipeline(iteration=iteration)
                self._tracker.append_orchestrator_log(
                    f"--- Iteration {iteration + 1}/{self._def.target_count} ---"
                )

                iteration_results = await self._run_iteration(
                    iteration=iteration,
                    workspace=workspace,
                    on_progress=on_progress,
                    model_override=model_override,
                )

                for agent_name, result in iteration_results.items():
                    all_results[agent_name].append(result)
                    if result.exit_code != 0:
                        errors.append(
                            f"{agent_name} (iteration {iteration + 1}): "
                            f"{result.error or f'exit code {result.exit_code}'}"
                        )

            final_status = "completed" if not errors else "failed"
            self._tracker.update_pipeline(status=final_status, completed_at=time.time())
            self._tracker.append_orchestrator_log(
                f"Pipeline {final_status} ({len(errors)} error(s))"
            )
            return PipelineResult(
                status=final_status,
                iterations=self._def.target_count,
                agent_results=all_results,
                errors=errors,
            )

        except Exception as exc:
            error_msg = str(exc)
            self._tracker.update_pipeline(status="failed", completed_at=time.time())
            self._tracker.append_orchestrator_log(f"Pipeline fatal error: {error_msg}")
            errors.append(error_msg)
            return PipelineResult(
                status="failed",
                iterations=0,
                agent_results=all_results,
                errors=errors,
            )

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    async def _run_iteration(
        self,
        iteration: int,
        workspace: str,
        on_progress: OnProgress | None,
        model_override: str | None,
    ) -> dict[str, AgentResult]:
        """Execute one full pass through the wave list."""
        results: dict[str, AgentResult] = {}
        agent_index = 0

        for wave_idx, wave in enumerate(self._waves):
            self._tracker.append_orchestrator_log(
                f"Wave {wave_idx + 1}/{len(self._waves)}: [{', '.join(wave)}]"
            )

            # Mark agents in this wave as waiting
            for agent_name in wave:
                self._tracker.update_agent(agent_name, status="waiting",
                                           iteration=iteration, wave=wave_idx)

            _emit(on_progress, self._tracker, iteration, wave_idx, len(self._waves))

            # Execute agents in this wave concurrently
            tasks = []
            for agent_name in wave:
                agent = self._def.agents[agent_name]
                current_index = agent_index
                agent_index += 1

                opts = SwarmExecutorOptions(
                    workspace=workspace,
                    swarm_name=self._def.name,
                    iteration=iteration,
                    state_tracker=self._tracker,
                    model_override=agent.model or model_override or self._def.model,
                    on_progress=lambda n, s: _emit(
                        on_progress, self._tracker, iteration, wave_idx, len(self._waves)
                    ),
                )
                tasks.append(
                    _run_agent_safe(agent, current_index, opts, self._def)
                )

            wave_results = await asyncio.gather(*tasks)

            for result in wave_results:
                results[result.agent_name] = result

            _emit(on_progress, self._tracker, iteration, wave_idx, len(self._waves))

        return results


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

async def _run_agent_safe(
    agent: object,
    index: int,
    opts: SwarmExecutorOptions,
    definition: SwarmDefinition,
) -> AgentResult:
    """Run a single agent, converting exceptions to failed AgentResult."""
    from .schema import SwarmAgent  # local to avoid circular at module level
    assert isinstance(agent, SwarmAgent)
    try:
        return await execute_swarm_agent(agent, index, opts)
    except Exception as exc:
        return AgentResult(
            agent_name=agent.name,
            index=index,
            exit_code=1,
            output="",
            stderr=str(exc),
            duration_ms=0,
            error=str(exc),
        )


def _emit(
    callback: OnProgress | None,
    tracker: StateTracker,
    iteration: int,
    current_wave: int,
    total_waves: int,
) -> None:
    if callback is None:
        return
    snapshot = {name: a.status for name, a in tracker.state.agents.items()}
    callback(
        PipelineProgress(
            iteration=iteration,
            target_count=tracker.state.target_count,
            current_wave=current_wave,
            total_waves=total_waves,
            agents=snapshot,
        )
    )
