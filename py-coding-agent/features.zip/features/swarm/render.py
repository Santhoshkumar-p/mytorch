"""
Text-based progress rendering for swarm pipeline status.

Produces a list of plain-text lines suitable for printing to a terminal,
injecting into a TUI widget, or appending to the conversation as a
status message.
"""

from __future__ import annotations

import time

from .state import AgentState, SwarmState

_STATUS_LABELS: dict[str, str] = {
    "completed": "[done]",
    "running":   "[ >> ]",
    "failed":    "[FAIL]",
    "pending":   "[    ]",
    "waiting":   "[wait]",
    "idle":      "[idle]",
    "aborted":   "[stop]",
}


def render_swarm_progress(state: SwarmState) -> list[str]:
    """
    Render a swarm state snapshot as a list of human-readable lines.

    Example output::

        Swarm: my-pipeline [RUNNING]
        Mode: pipeline | Iteration: 2/5

          [done]  researcher: completed (12.3s)
          [ >> ]  writer: running (4.1s...)
          [    ]  reviewer: pending

          2/3 done | 1 running | elapsed: 16.4s
    """
    lines: list[str] = []

    status_label = state.status.upper()
    lines.append(f"Swarm: {state.name} [{status_label}]")
    lines.append(f"Mode: {state.mode} | Iteration: {state.iteration + 1}/{state.target_count}")
    lines.append("")

    agents: list[AgentState] = list(state.agents.values())
    if not agents:
        lines.append("  (no agents)")
        return lines

    for agent in agents:
        icon = _STATUS_LABELS.get(agent.status, "[????]")
        duration_str = _format_agent_duration(agent)
        error_suffix = f" — {agent.error[:60]}" if agent.error else ""
        lines.append(f"  {icon} {agent.name}: {agent.status}{duration_str}{error_suffix}")

    completed = sum(1 for a in agents if a.status == "completed")
    failed = sum(1 for a in agents if a.status == "failed")
    running = sum(1 for a in agents if a.status == "running")

    lines.append("")
    parts = [f"{completed}/{len(agents)} done"]
    if running:
        parts.append(f"{running} running")
    if failed:
        parts.append(f"{failed} failed")
    elapsed = time.time() - state.started_at
    parts.append(f"elapsed: {_format_duration(elapsed)}")
    lines.append(f"  {' | '.join(parts)}")

    return lines


def render_swarm_summary(
    state: SwarmState,
    workspace: str,
    errors: list[str],
) -> str:
    """
    Render a markdown summary of a completed pipeline run.

    Suitable for injection into the LLM conversation context.
    """
    lines: list[str] = [
        f"## Swarm Pipeline: {state.name}",
        "",
        f"- **Status**: {state.status}",
        f"- **Mode**: {state.mode}",
        f"- **Iterations**: {state.iteration}/{state.target_count}",
        f"- **Workspace**: {workspace}",
        "",
        "### Agent Results",
        "",
    ]

    for name, agent in state.agents.items():
        duration = ""
        if agent.started_at and agent.completed_at:
            duration = f" ({_format_duration(agent.completed_at - agent.started_at)})"
        error_note = f" — {agent.error}" if agent.error else ""
        lines.append(f"- **{name}**: {agent.status}{duration}{error_note}")

    if errors:
        lines += ["", "### Errors", ""]
        for error in errors:
            lines.append(f"- {error}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _format_agent_duration(agent: AgentState) -> str:
    if agent.started_at and agent.completed_at:
        return f" ({_format_duration(agent.completed_at - agent.started_at)})"
    if agent.started_at and agent.status in ("running", "waiting"):
        return f" ({_format_duration(time.time() - agent.started_at)}...)"
    return ""


def _format_duration(seconds: float) -> str:
    """Format a duration in seconds as a human-readable string."""
    if seconds < 60:
        return f"{seconds:.1f}s"
    minutes = int(seconds // 60)
    secs = seconds % 60
    if minutes < 60:
        return f"{minutes}m{secs:.0f}s"
    hours = minutes // 60
    mins = minutes % 60
    return f"{hours}h{mins}m"
