"""
Swarm Extension — Multi-agent pipeline orchestration from YAML definitions.

A *swarm* is a set of named agents, each with a role and a task, that
coordinate through explicit dependency declarations.  The swarm engine:

- Parses a YAML definition file.
- Builds a dependency DAG from ``waits_for`` / ``reports_to`` relationships.
- Detects cycles and raises early.
- Computes *execution waves* — groups of agents that can run concurrently.
- Executes waves sequentially, running agents within each wave in parallel.
- Repeats all waves for *N* iterations (pipeline mode).
- Tracks state on disk so runs are inspectable and resumable.

Quick start::

    import asyncio
    from coding_agent.features.swarm import run_swarm_file

    result, state = asyncio.run(
        run_swarm_file("my-pipeline.yaml", cwd="/path/to/project")
    )
    print(result.status)   # "completed" | "failed"

Integration with the extension system::

    from coding_agent.features.swarm import swarm_slash_command
    # Register /swarm as a slash command through the ExtensionLoader.

YAML format
-----------
See ``schema.py`` for the full YAML specification and field docs.
"""

from .dag import build_dependency_graph, build_execution_waves, detect_cycles
from .executor import AgentResult, SwarmExecutorOptions, execute_swarm_agent
from .pipeline import PipelineController, PipelineProgress, PipelineResult
from .render import render_swarm_progress, render_swarm_summary
from .runner import load_swarm_status, render_status, render_summary, run_swarm_file
from .schema import (
    SwarmAgent,
    SwarmDefinition,
    parse_swarm_yaml,
    validate_swarm_definition,
)
from .state import AgentState, AgentStatus, PipelineStatus, StateTracker, SwarmState

__all__ = [
    # Schema
    "SwarmAgent",
    "SwarmDefinition",
    "parse_swarm_yaml",
    "validate_swarm_definition",
    # DAG
    "build_dependency_graph",
    "detect_cycles",
    "build_execution_waves",
    # State
    "AgentState",
    "AgentStatus",
    "PipelineStatus",
    "SwarmState",
    "StateTracker",
    # Executor
    "AgentResult",
    "SwarmExecutorOptions",
    "execute_swarm_agent",
    # Pipeline
    "PipelineController",
    "PipelineProgress",
    "PipelineResult",
    # Render
    "render_swarm_progress",
    "render_swarm_summary",
    # Runner (top-level)
    "run_swarm_file",
    "load_swarm_status",
    "render_status",
    "render_summary",
]
