"""
Directed Acyclic Graph helpers for swarm agent dependency resolution.

Builds a dependency map from ``waits_for`` / ``reports_to`` relationships,
detects cycles using Kahn's algorithm, and produces execution *waves* via
topological sort.  Agents within the same wave have no inter-dependencies
and can safely execute in parallel.

Key functions
-------------
build_dependency_graph  — agent → set of agents it must wait for
detect_cycles           — returns cycle participants or None if acyclic
build_execution_waves   — returns list[list[str]] (each inner list = one wave)
"""

from __future__ import annotations

from .schema import SwarmDefinition


def build_dependency_graph(definition: SwarmDefinition) -> dict[str, set[str]]:
    """
    Build a dependency map: agent name → set of agents it depends on (must
    finish before this agent starts).

    Sources of dependencies
    -----------------------
    1. Explicit ``waits_for`` — A waits for B means A depends on B.
    2. Implicit from ``reports_to`` — A reports_to B means B depends on A
       (B cannot start until A delivers its report).
    3. Pipeline/sequential mode with no explicit deps — agents are chained in
       YAML declaration order (A → B → C).
    """
    deps: dict[str, set[str]] = {name: set() for name in definition.agents}

    # Explicit waits_for
    for name, agent in definition.agents.items():
        for dep in agent.waits_for:
            if dep in deps:
                deps[name].add(dep)

    # reports_to: the *target* waits for the reporter
    for name, agent in definition.agents.items():
        for target in agent.reports_to:
            if target in deps:
                deps[target].add(name)

    # Implicit pipeline/sequential chain (only when no explicit deps at all)
    if (
        definition.mode in ("pipeline", "sequential")
        and not _has_any_deps(deps)
        and len(definition.agent_order) > 1
    ):
        for i in range(1, len(definition.agent_order)):
            prev = definition.agent_order[i - 1]
            curr = definition.agent_order[i]
            deps[curr].add(prev)

    return deps


def _has_any_deps(deps: dict[str, set[str]]) -> bool:
    return any(len(s) > 0 for s in deps.values())


def detect_cycles(deps: dict[str, set[str]]) -> list[str] | None:
    """
    Detect cycles in the dependency graph using Kahn's algorithm.

    Returns a list of agent names involved in a cycle, or ``None`` if
    the graph is acyclic.
    """
    # in-degree: how many agents does each node depend on?
    in_degree: dict[str, int] = {node: len(node_deps) for node, node_deps in deps.items()}

    # forward edges: dependency → its dependents
    forward: dict[str, list[str]] = {node: [] for node in deps}
    for node, node_deps in deps.items():
        for dep in node_deps:
            forward[dep].append(node)

    queue = [node for node, degree in in_degree.items() if degree == 0]
    sorted_nodes: list[str] = []

    while queue:
        node = queue.pop(0)
        sorted_nodes.append(node)
        for dependent in forward[node]:
            in_degree[dependent] -= 1
            if in_degree[dependent] == 0:
                queue.append(dependent)

    if len(sorted_nodes) < len(deps):
        # Nodes not in sorted_nodes are part of a cycle
        return [n for n in deps if n not in sorted_nodes]

    return None


def build_execution_waves(deps: dict[str, set[str]]) -> list[list[str]]:
    """
    Produce execution waves via topological sort.

    Each wave contains agents whose dependencies all appear in earlier waves.
    Agents within a wave may execute concurrently.

    :raises RuntimeError: if a deadlock is detected (should not happen after
        cycle detection passes).
    """
    waves: list[list[str]] = []
    completed: set[str] = set()
    remaining: set[str] = set(deps.keys())

    while remaining:
        wave: list[str] = []

        for node in remaining:
            node_deps = deps[node]
            if all(dep in completed for dep in node_deps):
                wave.append(node)

        if not wave:
            raise RuntimeError(
                f"Deadlock: agents [{', '.join(sorted(remaining))}] cannot make progress. "
                "This indicates a bug in cycle detection."
            )

        wave.sort()  # deterministic ordering within a wave

        for node in wave:
            remaining.discard(node)
            completed.add(node)

        waves.append(wave)

    return waves
