"""
Todo — phase-based task list with Markdown persistence.

Agents use the todo tool to track work across a session.  Tasks are organized
into named phases; each task has a status (pending, in_progress, completed,
abandoned) and optional notes.

The list serializes to/from Markdown so it can be read and written by both
humans and the LLM conversation context.
"""

from .types import TodoItem, TodoPhase, TodoStatus
from .markdown import phases_to_markdown, markdown_to_phases
from .manager import TodoManager
from .tool import TodoTool

__all__ = [
    "TodoItem",
    "TodoPhase",
    "TodoStatus",
    "phases_to_markdown",
    "markdown_to_phases",
    "TodoManager",
    "TodoTool",
]
