"""
TodoTool — agent tool wrapper around TodoManager.

Supports ops: init, start, done, drop, rm, append, note, status.
"""

from __future__ import annotations

import json
from typing import Any

from .manager import TodoManager


class TodoTool:
    """
    Agent tool for managing a phase-based task list.

    Instantiate one per agent session with a shared (or per-agent) TodoManager.
    """

    name = "todo_write"
    description = (
        "Manage a phase-based task list. "
        "Use op='init' to create/replace the list, op='start'/'done'/'drop' to "
        "update task status, op='append' to add tasks, op='note' to annotate, "
        "and op='status' to read the current list."
    )

    def __init__(self, manager: TodoManager) -> None:
        self._manager = manager

    async def execute(self, params: dict[str, Any]) -> str:
        op = params.get("op")
        try:
            if op == "status":
                return self._manager.format_summary() or "(no tasks)"

            if op == "init":
                phases = params.get("phases", [])
                self._manager.init(phases)
                return f"Initialized {len(phases)} phase(s).\n\n{self._manager.to_markdown()}"

            if op == "start":
                self._manager.start(params["phase"], int(params["index"]))
                return self._manager.format_summary()

            if op == "done":
                self._manager.done(params["phase"], int(params["index"]))
                return self._manager.format_summary()

            if op == "drop":
                self._manager.drop(params["phase"], int(params["index"]))
                return self._manager.format_summary()

            if op == "rm":
                self._manager.rm(params["phase"], int(params["index"]))
                return self._manager.format_summary()

            if op == "append":
                self._manager.append(params["phase"], params["task"])
                return self._manager.format_summary()

            if op == "note":
                self._manager.note(params["phase"], int(params["index"]), params["text"])
                return self._manager.format_summary()

            return json.dumps({"error": f"Unknown op: {op!r}"})

        except (KeyError, IndexError) as exc:
            return json.dumps({"error": str(exc)})

    @property
    def schema(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "input_schema": {
                "type": "object",
                "properties": {
                    "op": {
                        "type": "string",
                        "enum": ["init", "start", "done", "drop", "rm", "append", "note", "status"],
                        "description": "Operation to perform",
                    },
                    "phases": {
                        "type": "array",
                        "description": "Phase definitions for op='init'",
                        "items": {
                            "type": "object",
                            "properties": {
                                "name": {"type": "string"},
                                "tasks": {"type": "array", "items": {"type": "string"}},
                            },
                            "required": ["name"],
                        },
                    },
                    "phase": {
                        "type": "string",
                        "description": "Phase name (for start/done/drop/rm/append/note)",
                    },
                    "index": {
                        "type": "integer",
                        "description": "0-based task index within the phase (for start/done/drop/rm/note)",
                    },
                    "task": {
                        "type": "string",
                        "description": "Task content string (for op='append')",
                    },
                    "text": {
                        "type": "string",
                        "description": "Note text (for op='note')",
                    },
                },
                "required": ["op"],
            },
        }
