# Todo — Phase-Based Task List

Provides `TodoTool` — an agent tool for managing a structured task list with Markdown persistence.

## Concepts

- **Phases**: Named groups of tasks (e.g. "Setup", "Implementation", "Testing").
- **Statuses**: `pending` `[ ]`, `in_progress` `[/]`, `completed` `[x]`, `abandoned` `[-]`.
- **Normalization**: At most one task is `in_progress`; the first `pending` task auto-starts when no task is active.
- **Markdown**: Serialize/deserialize via `phases_to_markdown` / `markdown_to_phases` for LLM injection.

## Usage

```python
from coding_agent.features.todo import TodoManager, TodoTool

manager = TodoManager()
tool = TodoTool(manager)

# Initialize the list
await tool.execute({"op": "init", "phases": [
    {"name": "Setup", "tasks": ["Install deps", "Write config"]},
    {"name": "Build", "tasks": ["Compile", "Test"]},
]})

# Mark task 0 of Setup as done
await tool.execute({"op": "done", "phase": "Setup", "index": 0})

# Read current state
print(await tool.execute({"op": "status"}))

# Get Markdown (for system prompt injection)
print(manager.to_markdown())
```

## Tool Schema (op values)

| op | Required params | Effect |
|----|----------------|--------|
| `init` | `phases` | Replace entire task list |
| `start` | `phase`, `index` | Mark task in_progress (demotes others) |
| `done` | `phase`, `index` | Mark task completed |
| `drop` | `phase`, `index` | Mark task abandoned |
| `rm` | `phase`, `index` | Delete task |
| `append` | `phase`, `task` | Add new pending task to phase |
| `note` | `phase`, `index`, `text` | Attach note to task |
| `status` | — | Return summary of all phases |
