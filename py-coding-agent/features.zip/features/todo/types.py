"""Todo data types."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

TodoStatus = Literal["pending", "in_progress", "completed", "abandoned"]


@dataclass
class TodoItem:
    """A single task within a phase."""

    content: str
    status: TodoStatus = "pending"
    notes: list[str] = field(default_factory=list)

    def is_done(self) -> bool:
        return self.status in ("completed", "abandoned")


@dataclass
class TodoPhase:
    """A named group of tasks."""

    name: str
    tasks: list[TodoItem] = field(default_factory=list)

    def pending_count(self) -> int:
        return sum(1 for t in self.tasks if t.status == "pending")

    def in_progress_count(self) -> int:
        return sum(1 for t in self.tasks if t.status == "in_progress")

    def completed_count(self) -> int:
        return sum(1 for t in self.tasks if t.status == "completed")
