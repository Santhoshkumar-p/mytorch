"""
Markdown serialization for Todo phases.

Format
------
Each phase is a level-2 heading::

    ## Phase Name

Tasks use GitHub-style checkboxes with custom markers::

    - [ ] pending task
    - [/] in-progress task
    - [x] completed task
    - [-] abandoned task

Notes are indented bullet lines under their task::

    - [ ] some task
      - note text here

"""

from __future__ import annotations

import re

from .types import TodoItem, TodoPhase, TodoStatus


_STATUS_TO_MARKER: dict[TodoStatus, str] = {
    "pending":    "[ ]",
    "in_progress": "[/]",
    "completed":  "[x]",
    "abandoned":  "[-]",
}

_MARKER_TO_STATUS: dict[str, TodoStatus] = {v: k for k, v in _STATUS_TO_MARKER.items()}

_TASK_RE = re.compile(r"^- (\[[ /x\-]\]) (.+)$")
_NOTE_RE = re.compile(r"^  - (.+)$")
_HEADING_RE = re.compile(r"^## (.+)$")


def phases_to_markdown(phases: list[TodoPhase]) -> str:
    """Serialize *phases* to a Markdown string."""
    lines: list[str] = []
    for phase in phases:
        lines.append(f"## {phase.name}")
        lines.append("")
        for item in phase.tasks:
            marker = _STATUS_TO_MARKER.get(item.status, "[ ]")
            lines.append(f"- {marker} {item.content}")
            for note in item.notes:
                lines.append(f"  - {note}")
        lines.append("")
    return "\n".join(lines).strip()


def markdown_to_phases(text: str) -> list[TodoPhase]:
    """Deserialize Markdown *text* back to a list of :class:`TodoPhase`."""
    phases: list[TodoPhase] = []
    current_phase: TodoPhase | None = None
    current_item: TodoItem | None = None

    for raw_line in text.splitlines():
        line = raw_line.rstrip()

        heading_m = _HEADING_RE.match(line)
        if heading_m:
            current_phase = TodoPhase(name=heading_m.group(1).strip())
            phases.append(current_phase)
            current_item = None
            continue

        task_m = _TASK_RE.match(line)
        if task_m:
            marker = task_m.group(1)
            content = task_m.group(2).strip()
            status = _MARKER_TO_STATUS.get(marker, "pending")
            current_item = TodoItem(content=content, status=status)
            if current_phase is not None:
                current_phase.tasks.append(current_item)
            continue

        note_m = _NOTE_RE.match(line)
        if note_m and current_item is not None:
            current_item.notes.append(note_m.group(1).strip())
            continue

    return phases
