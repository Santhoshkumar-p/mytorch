"""
TodoManager — manages the task list for a session.

Supports all ops: init, start, done, drop, rm, append, note.
State is kept in-memory; callers can persist via :meth:`to_markdown` /
:meth:`load_markdown`.
"""

from __future__ import annotations

from .markdown import markdown_to_phases, phases_to_markdown
from .types import TodoItem, TodoPhase, TodoStatus


class TodoManager:
    """
    In-memory todo list manager.

    ::

        mgr = TodoManager()
        mgr.init([{"name": "Setup", "tasks": ["Install deps", "Configure env"]}])
        mgr.start(phase="Setup", index=0)
        mgr.done(phase="Setup", index=0)
        print(mgr.to_markdown())
    """

    def __init__(self) -> None:
        self._phases: list[TodoPhase] = []

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------

    def to_markdown(self) -> str:
        return phases_to_markdown(self._phases)

    def load_markdown(self, text: str) -> None:
        self._phases = markdown_to_phases(text)

    @property
    def phases(self) -> list[TodoPhase]:
        return list(self._phases)

    # ------------------------------------------------------------------
    # Ops
    # ------------------------------------------------------------------

    def init(self, phases: list[dict]) -> None:
        """
        Replace the entire task list.

        *phases* is a list of dicts with ``name`` and ``tasks`` (list of str
        or dicts with ``content`` and optional ``status``).
        """
        self._phases = []
        for p in phases:
            phase = TodoPhase(name=p["name"])
            for t in p.get("tasks", []):
                if isinstance(t, str):
                    phase.tasks.append(TodoItem(content=t))
                else:
                    phase.tasks.append(
                        TodoItem(
                            content=t["content"],
                            status=t.get("status", "pending"),
                            notes=list(t.get("notes", [])),
                        )
                    )
            self._phases.append(phase)
        self._normalize_in_progress()

    def start(self, phase: str, index: int) -> None:
        """Mark a task as in_progress (demoting any current in_progress)."""
        item = self._get_item(phase, index)
        # demote any current in_progress items across all phases
        for ph in self._phases:
            for t in ph.tasks:
                if t.status == "in_progress":
                    t.status = "pending"
        item.status = "in_progress"

    def done(self, phase: str, index: int) -> None:
        """Mark a task as completed."""
        self._get_item(phase, index).status = "completed"
        self._normalize_in_progress()

    def drop(self, phase: str, index: int) -> None:
        """Mark a task as abandoned."""
        self._get_item(phase, index).status = "abandoned"
        self._normalize_in_progress()

    def rm(self, phase: str, index: int) -> None:
        """Delete a task entirely."""
        ph = self._get_phase(phase)
        if index < 0 or index >= len(ph.tasks):
            raise IndexError(f"Task index {index} out of range for phase '{phase}'")
        ph.tasks.pop(index)

    def append(self, phase: str, task: str) -> None:
        """Add a new pending task to a phase."""
        self._get_phase(phase).tasks.append(TodoItem(content=task))

    def note(self, phase: str, index: int, text: str) -> None:
        """Attach a note to a task."""
        self._get_item(phase, index).notes.append(text)

    # ------------------------------------------------------------------
    # Summary
    # ------------------------------------------------------------------

    def format_summary(self) -> str:
        """Return a compact text summary of all phases."""
        lines: list[str] = []
        for ph in self._phases:
            total = len(ph.tasks)
            done = ph.completed_count()
            ip = ph.in_progress_count()
            pend = ph.pending_count()
            lines.append(f"[{ph.name}] total={total} done={done} in_progress={ip} pending={pend}")
            for i, t in enumerate(ph.tasks):
                marker = {"pending": " ", "in_progress": "/", "completed": "x", "abandoned": "-"}.get(t.status, " ")
                lines.append(f"  {i}. [{marker}] {t.content}")
                for note in t.notes:
                    lines.append(f"       note: {note}")
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _get_phase(self, name: str) -> TodoPhase:
        for ph in self._phases:
            if ph.name == name:
                return ph
        raise KeyError(f"Phase not found: {name!r}")

    def _get_item(self, phase: str, index: int) -> TodoItem:
        ph = self._get_phase(phase)
        if index < 0 or index >= len(ph.tasks):
            raise IndexError(f"Task index {index} out of range for phase '{phase}'")
        return ph.tasks[index]

    def _normalize_in_progress(self) -> None:
        """Ensure at most one task is in_progress; auto-start first pending if none."""
        in_progress = [
            (ph, t)
            for ph in self._phases
            for t in ph.tasks
            if t.status == "in_progress"
        ]
        if len(in_progress) > 1:
            # keep first, demote rest
            for _, t in in_progress[1:]:
                t.status = "pending"
        elif len(in_progress) == 0:
            # auto-start first pending
            for ph in self._phases:
                for t in ph.tasks:
                    if t.status == "pending":
                        t.status = "in_progress"
                        return
