"""
Optional feature modules for the coding agent.

Each sub-package is self-contained and can be imported independently.
None of these modules are loaded automatically — callers must import
the specific feature they need.

Available features
------------------
mcp              — MCP server integration (stdio / HTTP transports, tool bridge)
extensions       — Extension + hook system with custom tools and commands
subagents        — Sub-agent registry and agent definitions
browser          — Browser tool (backed by browser-harness helper)
memory           — Memory backend abstraction (local / off)
background       — Async background-job manager
plan_mode        — Plan-mode state + approved-plan checkpoint
task_delegation  — Task delegation with parallel / sequential execution
"""
